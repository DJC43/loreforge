import { ImagePlus, Loader2, Trash2, Upload } from "lucide-react";
import { useRef } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { fileToPortraitDataUrl } from "@/lib/portrait";

export function PortraitField({
  src,
  name,
  busy,
  onChange,
  onGenerate,
}: {
  src?: string;
  name?: string;
  busy?: boolean;
  onChange: (dataUrl?: string) => void;
  onGenerate: () => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);

  async function onFile(file: File) {
    try {
      const dataUrl = await fileToPortraitDataUrl(file);
      onChange(dataUrl);
      toast.success("Portrait uploaded");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed");
    }
  }

  return (
    <div className="flex flex-col gap-4 sm:flex-row sm:items-start">
      <button
        type="button"
        onClick={() => fileRef.current?.click()}
        disabled={busy}
        aria-label={src ? `Replace portrait of ${name || "this NPC"}` : "Upload a portrait"}
        className="size-64 shrink-0 overflow-hidden rounded-xl bg-muted shadow-[var(--shadow-border)] transition-opacity disabled:opacity-60"
      >
        {src ? (
          <img
            src={src}
            alt={name ? `Portrait of ${name}` : ""}
            className="size-full object-cover outline outline-1 -outline-offset-1 outline-white/10"
          />
        ) : (
          <span className="flex size-full flex-col items-center justify-center gap-2 px-4 text-center text-sm text-muted-foreground">
            <ImagePlus className="size-8 opacity-60" />
            Upload or generate
          </span>
        )}
      </button>
      <div className="flex min-w-0 flex-1 flex-col gap-3 pt-1">
        <div>
          <p className="text-sm font-medium">Portrait</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Square crop. Upload a still, or let Grok paint one from appearance and role. Face
            should read at a glance.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={onGenerate} disabled={busy}>
            {busy ? <Loader2 className="animate-spin" /> : <ImagePlus />}
            {src ? "Regenerate" : "Generate"}
          </Button>
          <Button variant="outline" onClick={() => fileRef.current?.click()} disabled={busy}>
            <Upload />
            Upload
          </Button>
          {src ? (
            <Button
              variant="ghost"
              onClick={() => onChange(undefined)}
              aria-label="Remove portrait"
              disabled={busy}
            >
              <Trash2 />
              Remove
            </Button>
          ) : null}
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void onFile(f);
            e.target.value = "";
          }}
        />
      </div>
    </div>
  );
}
