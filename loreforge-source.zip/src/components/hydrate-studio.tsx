import { useEffect } from "react";
import { inferNestedLinks } from "@/lib/nest";
import { createDemoLibrary, createDemoProject } from "@/lib/seed";
import { useStudio } from "@/lib/store";

export function HydrateStudio() {
  const setHydrated = useStudio((s) => s.setHydrated);
  useEffect(() => {
    const finish = () => {
      const current = useStudio.getState();
      const npcLibrary = inferNestedLinks(current.npcLibrary ?? []);
      const projects = (current.projects ?? []).map((p) => ({
        ...p,
        cards: inferNestedLinks(p.cards),
      }));
      const patch: Partial<typeof current> = {
        hasHydrated: true,
        npcLibrary,
        projects,
      };
      if (!projects.length) patch.projects = [createDemoProject()];
      if (!npcLibrary.length) patch.npcLibrary = createDemoLibrary();
      if (!current.elementLibrary) patch.elementLibrary = [];
      useStudio.setState(patch);
      setHydrated();
    };
    const unsub = useStudio.persist.onFinishHydration(finish);
    if (useStudio.persist.hasHydrated()) finish();
    return unsub;
  }, [setHydrated]);
  return null;
}
