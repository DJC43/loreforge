import { useEffect } from "react";
import { createDemoLibrary, createDemoProject } from "@/lib/seed";
import { useStudio } from "@/lib/store";

export function HydrateStudio() {
  const setHydrated = useStudio((s) => s.setHydrated);
  useEffect(() => {
    const finish = () => {
      const current = useStudio.getState();
      const patch: Partial<typeof current> = { hasHydrated: true };
      if (!current.projects.length) patch.projects = [createDemoProject()];
      if (!current.npcLibrary?.length) patch.npcLibrary = createDemoLibrary();
      if (!current.elementLibrary) patch.elementLibrary = [];
      if (patch.projects || patch.npcLibrary || patch.elementLibrary) {
        useStudio.setState({ ...patch, hasHydrated: true });
        return;
      }
      setHydrated();
    };
    const unsub = useStudio.persist.onFinishHydration(finish);
    if (useStudio.persist.hasHydrated()) finish();
    return unsub;
  }, [setHydrated]);
  return null;
}
