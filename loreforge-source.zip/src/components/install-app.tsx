import { MonitorDown } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

function isStandalone() {
  if (typeof window === "undefined") return false;
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    window.matchMedia("(display-mode: window-controls-overlay)").matches ||
    Boolean((navigator as { standalone?: boolean }).standalone)
  );
}

export function InstallApp() {
  const [open, setOpen] = useState(false);
  const [standalone, setStandalone] = useState(false);
  const [promptEvent, setPromptEvent] = useState<InstallPromptEvent | null>(null);

  useEffect(() => {
    setStandalone(isStandalone());
    const onPrompt = (event: Event) => {
      event.preventDefault();
      setPromptEvent(event as InstallPromptEvent);
    };
    const onInstalled = () => {
      setPromptEvent(null);
      setStandalone(true);
      setOpen(false);
      toast.success("Loreforge is on your desktop");
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  if (standalone) return null;

  return (
    <>
      <Button
        variant="ghost"
        size="icon"
        className="sm:hidden"
        aria-label="Install Loreforge"
        onClick={() => setOpen(true)}
      >
        <MonitorDown />
      </Button>
      <Button variant="ghost" className="hidden sm:inline-flex" onClick={() => setOpen(true)}>
        <MonitorDown />
        Install
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add to desktop</DialogTitle>
            <DialogDescription>
              Loreforge opens in its own window, with the forge icon on your dock or home
              screen.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
          <div className="flex items-center gap-3 rounded-xl bg-secondary p-3">
            <img
              src="/icon-192.png"
              alt=""
              width={64}
              height={64}
              className="size-16 rounded-xl"
            />
            <div>
              <p className="text-sm font-medium">Loreforge</p>
              <p className="text-xs text-muted-foreground">AI Dungeon studio</p>
            </div>
          </div>
          {promptEvent ? (
            <Button
              className="w-full"
              onClick={() => {
                void promptEvent.prompt().then(async () => {
                  const choice = await promptEvent.userChoice;
                  if (choice.outcome === "accepted") {
                    setPromptEvent(null);
                    setOpen(false);
                  }
                });
              }}
            >
              <MonitorDown />
              Install Loreforge
            </Button>
          ) : (
            <ol className="list-decimal space-y-2 pl-5 text-sm text-muted-foreground">
              <li>
                <span className="text-foreground">Chrome or Edge</span> — use the install icon in
                the address bar, or the browser menu, then Install Loreforge.
              </li>
              <li>
                <span className="text-foreground">Safari on Mac</span> — File, then Add to Dock.
              </li>
              <li>
                <span className="text-foreground">iPhone or iPad</span> — Share, then Add to Home
                Screen.
              </li>
            </ol>
          )}
          <Button
            variant="outline"
            className="w-full"
            onClick={() => {
              const a = document.createElement("a");
              a.href = "/icon-512.png";
              a.download = "Loreforge.png";
              a.click();
              toast.success("Icon downloaded");
            }}
          >
            Download icon
          </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
