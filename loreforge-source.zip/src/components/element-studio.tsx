import { GitBranch, Library, Loader2, Lock, LockOpen, Plus, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { CopyButton } from "@/components/copy-button";
import { FieldBlock } from "@/components/field-block";
import { GrokFill } from "@/components/grok-fill";
import { PortraitField } from "@/components/portrait-field";
import { SectionIntro } from "@/components/project-frame";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { generateCardBatch, generateCover, generateNpc } from "@/lib/ai";
import { composeNpcEntry, estimateTokens, keysFromName, toAidStoryCards } from "@/lib/aid";
import { NEST_ROLES, NPC_FIELDS, nestRoleHint, nestRoleLabel } from "@/lib/catalog";
import { projectContext } from "@/lib/context";
import { portraitPrompt } from "@/lib/portrait";
import { useStudio } from "@/lib/store";
import { CARD_TYPES, emptyNpc, type CardType, type NpcFields, type StoryCard } from "@/lib/types";
import { cn } from "@/lib/utils";

export function ElementStudio({
  projectId,
  types,
  kicker,
  title,
  lede,
  allowLibrary = false,
  allowPortrait = false,
}: {
  projectId: string;
  types: CardType[];
  kicker: string;
  title: string;
  lede: string;
  allowLibrary?: boolean;
  allowPortrait?: boolean;
}) {
  const project = useStudio((s) => s.projects.find((p) => p.id === projectId));
  const upsert = useStudio((s) => s.upsertCard);
  const addBlank = useStudio((s) => s.addBlankCard);
  const remove = useStudio((s) => s.removeCard);
  const saveToLibrary = useStudio((s) => s.saveCardToLibrary);
  const npcLibrary = useStudio((s) => s.npcLibrary);
  const elementLibrary = useStudio((s) => s.elementLibrary);
  const addFromNpcLibrary = useStudio((s) => s.addLibraryNpcToProject);
  const addFromElementLibrary = useStudio((s) => s.addLibraryElementToProject);
  const groupProjectCards = useStudio((s) => s.groupProjectCards);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [brief, setBrief] = useState("");
  const [busy, setBusy] = useState<"one" | "batch" | "portrait" | null>(null);
  const [showLibrary, setShowLibrary] = useState(false);

  const allCards = project?.cards ?? [];
  const cards = useMemo(() => visibleCards(allCards, types), [allCards, types]);
  const selected = cards.find((c) => c.id === (selectedId ?? cards[0]?.id)) ?? null;
  const defaultType = types[0] ?? "other";
  const ctx = project ? projectContext(project) : "";
  const isNpcTab = defaultType === "character";
  const catalogue = isNpcTab
    ? npcLibrary
        .filter((n) => !n.parentId || !npcLibrary.some((p) => p.id === n.parentId))
        .map((n) => ({
          id: n.id,
          title: n.title,
          description: n.description || n.npc.role,
          portrait: n.portraitDataUrl,
          nested: npcLibrary.filter((c) => c.parentId === n.id).length,
          already: cards.some((c) => c.libraryId === n.id),
        }))
    : elementLibrary
        .filter((e) => types.includes(e.type))
        .map((e) => ({
          id: e.id,
          title: e.title,
          description: e.description || e.type,
          portrait: undefined as string | undefined,
          nested: 0,
          already: cards.some((c) => c.libraryId === e.id),
        }));

  if (!project) return null;

  async function makeOne() {
    if (!brief.trim()) {
      toast.error("Give Grok a brief first.");
      return;
    }
    setBusy("one");
    try {
      if (defaultType === "character") {
        const res = await generateNpc({ data: { brief: brief.trim(), context: ctx } });
        if (!res.ok) {
          toast.error(res.error);
          return;
        }
        const d = res.data;
        const card: StoryCard = {
          id: crypto.randomUUID(),
          title: d.title,
          type: "character",
          keys: d.keys || d.title,
          value: d.value,
          description: d.description || "",
          useForCharacterCreation: false,
          scenarioSpecific: true,
          locked: false,
          includeInExport: true,
          npc: { ...emptyNpc(), ...d.npc },
        };
        upsert(projectId, card);
        setSelectedId(card.id);
        setBrief("");
        toast.success(`Wrote ${card.title}`);
      } else {
        const res = await generateCardBatch({
          data: { context: ctx, focus: brief.trim(), typeHint: defaultType },
        });
        if (!res.ok) {
          toast.error(res.error);
          return;
        }
        const first = res.cards[0];
        if (!first) {
          toast.error("No card returned");
          return;
        }
        const card: StoryCard = {
          id: crypto.randomUUID(),
          title: first.title,
          type: types.includes(first.type as CardType) ? (first.type as CardType) : defaultType,
          keys: first.keys || first.title,
          value: first.value,
          description: first.description || "",
          useForCharacterCreation: Boolean(first.useForCharacterCreation),
          scenarioSpecific: true,
          locked: false,
          includeInExport: true,
        };
        upsert(projectId, card);
        setSelectedId(card.id);
        setBrief("");
        toast.success(`Wrote ${card.title}`);
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Generation failed");
    } finally {
      setBusy(null);
    }
  }

  async function batch() {
    setBusy("batch");
    try {
      const res = await generateCardBatch({
        data: { context: ctx, focus: brief.trim() || undefined, typeHint: defaultType },
      });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      let last: string | null = null;
      for (const d of res.cards) {
        const type = types.includes(d.type as CardType) ? (d.type as CardType) : defaultType;
        const card: StoryCard = {
          id: crypto.randomUUID(),
          title: d.title,
          type,
          keys: d.keys || d.title,
          value: d.value,
          description: d.description || "",
          useForCharacterCreation: Boolean(d.useForCharacterCreation),
          scenarioSpecific: true,
          locked: false,
          includeInExport: true,
          npc: type === "character" ? { ...emptyNpc(), ...d.npc } : undefined,
        };
        upsert(projectId, card);
        last = card.id;
      }
      if (last) setSelectedId(last);
      toast.success(`Added ${res.cards.length}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Batch failed");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div>
      <SectionIntro
        kicker={kicker}
        title={title}
        lede={lede}
        actions={
          <>
            <Button
              variant="outline"
              onClick={() => {
                const c = addBlank(projectId, defaultType);
                setSelectedId(c.id);
              }}
            >
              <Plus />
              Blank
            </Button>
            {allowLibrary ? (
              <Button variant="outline" onClick={() => setShowLibrary((v) => !v)}>
                <Library />
                Catalogue
              </Button>
            ) : null}
            <CopyButton
              text={JSON.stringify(toAidStoryCards(cards), null, 2)}
              label="Copy JSON"
              success="JSON copied"
            />
          </>
        }
      />

      {allowLibrary && showLibrary ? (
        <div className="mb-6 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
          <p className="text-xs font-medium text-muted-foreground">
            {isNpcTab ? "NPC library" : "Saved for future use"}
          </p>
          {catalogue.length === 0 ? (
            <p className="mt-2 text-sm text-muted-foreground">
              Nothing saved yet. Write a card, then Save for future use.
            </p>
          ) : (
            <ul className="mt-3 grid gap-2 sm:grid-cols-2">
              {catalogue.map((n) => (
                <li key={n.id} className="flex items-center gap-3 rounded-lg bg-secondary p-2">
                  {isNpcTab ? (
                    <div className="aspect-[9/16] w-16 shrink-0 overflow-hidden rounded-md bg-muted">
                      {n.portrait ? (
                        <img src={n.portrait} alt="" className="size-full object-cover object-top" />
                      ) : null}
                    </div>
                  ) : null}
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{n.title}</p>
                    <p className="line-clamp-1 text-[11px] text-muted-foreground">
                      {n.nested ? `${n.nested} nested · ` : ""}
                      {n.description}
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={n.already}
                    onClick={() => {
                      const card = isNpcTab
                        ? addFromNpcLibrary(projectId, n.id, false)
                        : addFromElementLibrary(projectId, n.id, false);
                      if (card) {
                        setSelectedId(card.id);
                        toast.success(`Added ${n.title}`);
                      }
                    }}
                  >
                    {n.already ? "In scenario" : "Add"}
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </div>
      ) : null}

      <div className="mb-6 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
        <Label htmlFor="el-brief">Generate with Grok</Label>
        <Textarea
          id="el-brief"
          value={brief}
          onChange={(e) => setBrief(e.target.value)}
          placeholder="A brief for Grok…"
          className="mt-2 min-h-20"
        />
        <div className="mt-3 flex flex-wrap gap-2">
          <Button onClick={() => void makeOne()} disabled={busy !== null}>
            {busy === "one" ? <Loader2 className="animate-spin" /> : null}
            Write one
          </Button>
          <Button variant="outline" onClick={() => void batch()} disabled={busy !== null}>
            {busy === "batch" ? <Loader2 className="animate-spin" /> : null}
            Write five
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              groupProjectCards(projectId);
              toast.success("Grouped suffix cards under matching names");
            }}
          >
            Group by name
          </Button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,300px)_minmax(0,1fr)]">
        <ul className="max-h-[70vh] space-y-0.5 overflow-auto rounded-xl bg-card p-2 shadow-[var(--shadow-border)]">
          {cards.length === 0 ? (
            <li className="px-3 py-8 text-center text-sm text-muted-foreground">Nothing here yet.</li>
          ) : (
            treeRows(allCards, types).map((row) => (
              <li
                key={row.card.id}
                className={cn(row.depth > 0 && "border-l border-border")}
                style={{ marginLeft: row.depth * 16, paddingLeft: row.depth ? 8 : 0 }}
              >
                <button
                  type="button"
                  onClick={() => setSelectedId(row.card.id)}
                  className={cn(
                    "flex w-full items-start gap-2.5 rounded-lg px-3 py-2.5 text-left",
                    selected?.id === row.card.id ? "bg-secondary" : "hover:bg-muted",
                  )}
                >
                  {row.depth > 0 ? (
                    <GitBranch className="mt-1 size-3.5 shrink-0 text-steel" />
                  ) : row.card.type === "character" || row.card.portraitDataUrl ? (
                    <span className="mt-0.5 aspect-[9/16] w-14 shrink-0 overflow-hidden rounded-md bg-muted">
                      {row.card.portraitDataUrl ? (
                        <img
                          src={row.card.portraitDataUrl}
                          alt=""
                          className="size-full object-cover object-top"
                        />
                      ) : null}
                    </span>
                  ) : null}
                  <span className="min-w-0 flex-1">
                    <span className="flex w-full items-center gap-2 text-sm font-medium">
                      {row.card.locked ? <Lock className="size-3 shrink-0" /> : null}
                      <span className="min-w-0 truncate">{row.card.title}</span>
                    </span>
                    <span className="mt-0.5 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
                      {row.depth > 0 ? (
                        <Badge variant="steel">{nestRoleLabel(row.card.nestRole)}</Badge>
                      ) : (
                        <span className="capitalize">{row.card.type}</span>
                      )}
                      <span className="font-mono tabular-nums">{estimateTokens(row.card.value)} tok</span>
                      {row.childCount ? (
                        <span>
                          {row.childCount} nested
                        </span>
                      ) : null}
                      {row.card.scenarioSpecific ? (
                        <Badge variant="outline">scenario</Badge>
                      ) : (
                        <Badge variant="steel">reusable</Badge>
                      )}
                      {row.card.useForCharacterCreation ? <Badge variant="steel">CC</Badge> : null}
                      {row.card.includeInExport === false ? (
                        <Badge variant="outline">skip export</Badge>
                      ) : row.depth > 0 ? (
                        <Badge variant="outline">export</Badge>
                      ) : null}
                    </span>
                  </span>
                </button>
              </li>
            ))
          )}
        </ul>
        {selected ? (
          <CardEditor
            key={selected.id}
            card={selected}
            allCards={allCards}
            context={ctx}
            types={types}
            allowLibrary={allowLibrary}
            allowPortrait={allowPortrait && selected.type === "character"}
            busyPortrait={busy === "portrait"}
            onOpen={(id) => setSelectedId(id)}
            onAddNested={(role) => {
              const c = addBlank(projectId, "other", { parentId: selected.id, nestRole: role });
              setSelectedId(c.id);
              toast.success(`Nested ${nestRoleLabel(role).toLowerCase()} under ${selected.title}`);
            }}
            onPortrait={async () => {
              const id = selected.id;
              setBusy("portrait");
              try {
                const latest =
                  useStudio.getState().projects.find((p) => p.id === projectId)?.cards.find((c) => c.id === id) ??
                  selected;
                const appearance = latest.npc?.appearance || latest.value;
                const role = latest.npc?.role || latest.description;
                const res = await generateCover({
                  data: { prompt: portraitPrompt(latest.title, role, appearance), aspect: "9:16" },
                });
                if (!res.ok) {
                  toast.error(res.error);
                  return;
                }
                const after =
                  useStudio.getState().projects.find((p) => p.id === projectId)?.cards.find((c) => c.id === id) ??
                  latest;
                upsert(projectId, { ...after, portraitDataUrl: res.dataUrl });
                toast.success("Portrait painted");
              } catch (err) {
                toast.error(err instanceof Error ? err.message : "Portrait failed");
              } finally {
                setBusy(null);
              }
            }}
            onChange={(card) => upsert(projectId, card)}
            onSaveLibrary={() => {
              const entry = saveToLibrary(projectId, selected.id);
              if (entry) toast.success(`Saved ${entry.title} for future use`);
            }}
            onDelete={() => {
              remove(projectId, selected.id);
              setSelectedId(null);
            }}
          />
        ) : (
          <div className="rounded-xl bg-card p-8 text-sm text-muted-foreground shadow-[var(--shadow-border)]">
            Select or create a card.
          </div>
        )}
      </div>
    </div>
  );
}

function CardEditor({
  card,
  allCards,
  onChange,
  onDelete,
  onSaveLibrary,
  onPortrait,
  onAddNested,
  onOpen,
  context,
  types,
  allowLibrary,
  allowPortrait,
  busyPortrait,
}: {
  card: StoryCard;
  allCards: StoryCard[];
  onChange: (c: StoryCard) => void;
  onDelete: () => void;
  onSaveLibrary: () => void;
  onPortrait: () => void;
  onAddNested: (role: string) => void;
  onOpen: (id: string) => void;
  context: string;
  types: CardType[];
  allowLibrary: boolean;
  allowPortrait: boolean;
  busyPortrait: boolean;
}) {
  const npc = card.npc ?? emptyNpc();
  const isChar = card.type === "character";
  const typeOptions = types.length > 1 || card.parentId ? CARD_TYPES : types.length ? types : CARD_TYPES;
  const blocked = blockedParentIds(allCards, card.id);
  const parentOptions = allCards.filter((c) => !blocked.has(c.id));
  const parent = allCards.find((c) => c.id === card.parentId);
  const children = allCards.filter((c) => c.parentId === card.id);

  function setNpc(patch: Partial<NpcFields>) {
    const next = { ...npc, ...patch };
    const value = composeNpcEntry(card.title, next);
    const keys = card.keys.trim() ? card.keys : keysFromName(card.title, next.aliases);
    onChange({ ...card, npc: next, value, keys });
  }

  return (
    <div className="space-y-4 rounded-xl bg-card p-4 shadow-[var(--shadow-border)] md:p-5">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="grid min-w-0 flex-1 gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label htmlFor="ctitle">Title</Label>
              <GrokFill
                field="card title"
                value={card.title}
                onChange={(title) =>
                  onChange({
                    ...card,
                    title,
                    keys: card.keys.trim() ? card.keys : keysFromName(title, npc.aliases),
                  })
                }
                context={context}
              />
            </div>
            <Input
              id="ctitle"
              value={card.title}
              disabled={card.locked}
              onChange={(e) => {
                const title = e.target.value;
                const nextNpc = card.npc;
                const value = nextNpc ? composeNpcEntry(title, nextNpc) : card.value;
                onChange({
                  ...card,
                  title,
                  value,
                  keys: card.keys.trim() ? card.keys : keysFromName(title, nextNpc?.aliases ?? ""),
                });
              }}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ctype">Type</Label>
            <select
              id="ctype"
              value={card.type}
              disabled={card.locked}
              onChange={(e) => onChange({ ...card, type: e.target.value as CardType })}
              className="flex h-11 w-full rounded-md border border-input bg-card px-3 text-sm"
            >
              {typeOptions.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="flex gap-1">
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label={card.locked ? "Unlock" : "Lock"}
            onClick={() => onChange({ ...card, locked: !card.locked })}
          >
            {card.locked ? <Lock /> : <LockOpen />}
          </Button>
          <Button variant="ghost" size="icon-sm" aria-label="Delete card" onClick={onDelete}>
            <Trash2 />
          </Button>
        </div>
      </div>

      {allowPortrait ? (
        <PortraitField
          src={card.portraitDataUrl}
          name={card.title}
          busy={busyPortrait}
          onGenerate={onPortrait}
          onChange={(portraitDataUrl) => onChange({ ...card, portraitDataUrl })}
        />
      ) : null}

      <div className="space-y-3 rounded-lg bg-secondary p-3">
        <div>
          <p className="text-sm font-medium">Nested cards</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Nesting is studio-only. The JSON is a flat list of distinct story cards — check
            Include in export on a nested backstory or motivation to send it.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {NEST_ROLES.map((r) => (
            <Button
              key={r.id}
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onAddNested(r.id)}
            >
              <Plus />
              {r.label}
            </Button>
          ))}
        </div>
        {children.length ? (
          <ul className="space-y-1">
            {children.map((child) => (
              <li key={child.id} className="flex items-center gap-1">
                <label
                  className="flex size-11 shrink-0 items-center justify-center"
                  title={child.includeInExport === false ? "Skip this card in export" : "Include as its own story card"}
                >
                  <input
                    type="checkbox"
                    checked={child.includeInExport !== false}
                    disabled={child.locked}
                    onChange={(e) => onChange({ ...child, includeInExport: e.target.checked })}
                    className="size-4 accent-steel"
                    aria-label={`Include ${child.title} in export`}
                  />
                </label>
                <button
                  type="button"
                  onClick={() => onOpen(child.id)}
                  className="flex min-w-0 flex-1 items-center gap-2 rounded-md bg-card px-3 py-2 text-left text-sm hover:bg-muted"
                >
                  <GitBranch className="size-3.5 shrink-0 text-steel" />
                  <span className="min-w-0 flex-1 truncate">{child.title}</span>
                  <Badge variant="steel">{nestRoleLabel(child.nestRole)}</Badge>
                </button>
              </li>
            ))}
          </ul>
        ) : null}
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label htmlFor="parent">Nest under</Label>
            <select
              id="parent"
              value={card.parentId ?? ""}
              disabled={card.locked}
              onChange={(e) =>
                onChange({
                  ...card,
                  parentId: e.target.value || undefined,
                  nestRole: e.target.value ? card.nestRole || "backstory" : undefined,
                })
              }
              className="flex h-11 w-full rounded-md border border-input bg-card px-3 text-sm"
            >
              <option value="">Top level</option>
              {parentOptions.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="nest-role">Nested as</Label>
            <select
              id="nest-role"
              value={card.nestRole || "backstory"}
              disabled={card.locked || !card.parentId}
              onChange={(e) => onChange({ ...card, nestRole: e.target.value })}
              className="flex h-11 w-full rounded-md border border-input bg-card px-3 text-sm"
            >
              {NEST_ROLES.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.label}
                </option>
              ))}
            </select>
          </div>
        </div>
        {parent ? (
          <p className="text-xs text-muted-foreground">
            Nested under{" "}
            <button
              type="button"
              className="text-steel underline-offset-4 hover:underline"
              onClick={() => onOpen(parent.id)}
            >
              {parent.title}
            </button>{" "}
            as {nestRoleLabel(card.nestRole).toLowerCase()}. {nestRoleHint(card.nestRole)}
          </p>
        ) : null}
      </div>

      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <Label htmlFor="ckeys">Triggers</Label>
          <GrokFill
            field="story card triggers"
            value={card.keys}
            onChange={(keys) => onChange({ ...card, keys })}
            context={`${context}\nTitle: ${card.title}`}
            instruction="Comma-separated names and aliases only."
          />
        </div>
        <Input
          id="ckeys"
          value={card.keys}
          disabled={card.locked}
          onChange={(e) => onChange({ ...card, keys: e.target.value })}
          placeholder="Name, alias, title"
        />
      </div>

      <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-center">
        <label className="flex h-11 items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={card.includeInExport !== false}
            disabled={card.locked}
            onChange={(e) => onChange({ ...card, includeInExport: e.target.checked })}
            className="size-4 accent-steel"
          />
          Include in export
        </label>
        <label className="flex h-11 items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={card.scenarioSpecific}
            onChange={(e) => onChange({ ...card, scenarioSpecific: e.target.checked })}
            className="size-4 accent-steel"
          />
          Scenario specific
        </label>
        <label className="flex h-11 items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={card.useForCharacterCreation}
            onChange={(e) => onChange({ ...card, useForCharacterCreation: e.target.checked })}
            className="size-4 accent-steel"
          />
          Use in Character Creator
        </label>
        {allowLibrary ? (
          <Button variant="outline" size="sm" onClick={onSaveLibrary}>
            <Library />
            {card.libraryId ? "Save copy to library" : "Save for future use"}
          </Button>
        ) : null}
      </div>
      <p className="text-xs text-muted-foreground">
        Scenario-specific cards live only in this project. Saving for future use copies them into the
        catalogue — you can do both. Nested cards are never nested in the JSON; uncheck Include in
        export to leave one out.
      </p>

      {isChar ? (
        <div className="grid gap-3 sm:grid-cols-2">
          {NPC_FIELDS.map(([key, label]) => (
            <div key={key} className={cn("space-y-1.5", key === "appearance" && "sm:col-span-2")}>
              <div className="flex items-center justify-between">
                <Label htmlFor={key}>{label}</Label>
                <GrokFill
                  field={`NPC ${label.toLowerCase()}`}
                  value={npc[key]}
                  onChange={(v) => setNpc({ [key]: v })}
                  context={`${context}\nNPC: ${card.title}`}
                />
              </div>
              <Textarea
                id={key}
                value={npc[key]}
                disabled={card.locked}
                onChange={(e) => setNpc({ [key]: e.target.value })}
                className="min-h-16"
              />
            </div>
          ))}
        </div>
      ) : null}

      <FieldBlock
        label="Entry (what the AI sees)"
        hint={
          parent
            ? `Nested ${nestRoleLabel(card.nestRole).toLowerCase()} for ${parent.title}. Plain prose, name first.`
            : "Plain prose, name first, no blank lines. Title is ignored by the model."
        }
        field="storyCardEntry"
        value={card.value}
        onChange={(value) => onChange({ ...card, value })}
        context={context}
        minH="min-h-36"
        warnAt={1000}
      />
      <div className="space-y-1.5">
        <div className="flex items-center justify-between">
          <Label htmlFor="cdesc">Player-facing description</Label>
          <GrokFill
            field="player-facing description"
            value={card.description}
            onChange={(description) => onChange({ ...card, description })}
            context={`${context}\nTitle: ${card.title}\nEntry: ${card.value}`}
            instruction="One short sentence."
          />
        </div>
        <Textarea
          id="cdesc"
          value={card.description}
          disabled={card.locked}
          onChange={(e) => onChange({ ...card, description: e.target.value })}
          className="min-h-20"
          placeholder="Shown in Character Creator and for your own notes."
        />
      </div>
    </div>
  );
}

function visibleCards(all: StoryCard[], types: CardType[]): StoryCard[] {
  const ids = new Set(all.map((c) => c.id));
  const roots = all.filter((c) => types.includes(c.type) && (!c.parentId || !ids.has(c.parentId)));
  const out: StoryCard[] = [];
  const walk = (parentId: string) => {
    for (const c of all) {
      if (c.parentId === parentId) {
        out.push(c);
        walk(c.id);
      }
    }
  };
  for (const r of roots) {
    out.push(r);
    walk(r.id);
  }
  return out;
}

function treeRows(all: StoryCard[], types: CardType[]) {
  const ids = new Set(all.map((c) => c.id));
  const roots = all.filter((c) => types.includes(c.type) && (!c.parentId || !ids.has(c.parentId)));
  const rows: { card: StoryCard; depth: number; childCount: number }[] = [];
  const childCount = (id: string) => all.filter((c) => c.parentId === id).length;
  const walk = (node: StoryCard, depth: number) => {
    rows.push({ card: node, depth, childCount: childCount(node.id) });
    for (const c of all) {
      if (c.parentId === node.id) walk(c, depth + 1);
    }
  };
  for (const r of roots) walk(r, 0);
  return rows;
}

function blockedParentIds(all: StoryCard[], id: string) {
  const blocked = new Set<string>([id]);
  let grew = true;
  while (grew) {
    grew = false;
    for (const c of all) {
      if (c.parentId && blocked.has(c.parentId) && !blocked.has(c.id)) {
        blocked.add(c.id);
        grew = true;
      }
    }
  }
  return blocked;
}
