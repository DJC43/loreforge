import { Link, useNavigate, useParams, useRouterState } from "@tanstack/react-router";
import { Download, MoreHorizontal, Trash2, Users } from "lucide-react";
import { toast } from "sonner";
import { InstallApp } from "@/components/install-app";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { downloadText, projectPastePack, slugify, toAidStoryCards } from "@/lib/aid";
import { toDungeonAdventure, toNpcExport } from "@/lib/dungeon";
import { useStudio } from "@/lib/store";

export function AppChrome() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const inProject = pathname.startsWith("/project/");
  const params = useParams({ strict: false }) as { id?: string };
  const project = useStudio((s) => s.projects.find((p) => p.id === params.id));
  const deleteProject = useStudio((s) => s.deleteProject);
  const library = useStudio((s) => s.npcLibrary);
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/90 backdrop-blur-sm">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-4">
        <Link to="/" className="flex items-baseline gap-2">
          <span className="font-display text-lg tracking-tight">Loreforge</span>
          <span className="hidden text-[11px] tracking-[0.14em] text-muted-foreground uppercase sm:inline">
            AI Dungeon studio
          </span>
        </Link>
        <div className="flex min-w-0 items-center gap-2">
          <InstallApp />
          <Link
            to="/library"
            className="inline-flex h-11 items-center gap-1.5 rounded-md px-3 text-sm text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            <Users className="size-4" />
            <span className="hidden sm:inline">NPC library</span>
          </Link>
          {inProject && project ? (
            <>
              <span className="hidden truncate text-sm text-muted-foreground md:inline">
                {project.title}
              </span>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon-sm" aria-label="Project actions">
                    <MoreHorizontal />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem
                    onSelect={() => {
                      downloadText(
                        `${slugify(project.title)}-adventure.json`,
                        JSON.stringify(toDungeonAdventure(project), null, 2),
                        "application/json",
                      );
                      toast.success("Dungeon Extension v2 adventure downloaded");
                    }}
                  >
                    <Download className="size-4" />
                    Adventure JSON (Dungeon v2)
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={() => {
                      const npcs = project.cards.filter(
                        (c) => c.type === "character" && c.includeInExport !== false && !c.parentId,
                      );
                      downloadText(
                        `${slugify(project.title)}-npcs.json`,
                        JSON.stringify(
                          toNpcExport(
                            npcs.map((c) => ({
                              id: c.id,
                              title: c.title,
                              keys: c.keys,
                              value: c.value,
                              description: c.description,
                              npc: c.npc ?? {
                                aliases: "",
                                role: "",
                                appearance: "",
                                personality: "",
                                speech: "",
                                motivations: "",
                                relationships: "",
                                secrets: "",
                                abilities: "",
                                quirks: "",
                              },
                              portraitDataUrl: c.portraitDataUrl,
                              selected: true,
                              createdAt: project.updatedAt,
                            })),
                          ),
                          null,
                          2,
                        ),
                        "application/json",
                      );
                      toast.success("NPC JSON downloaded");
                    }}
                  >
                    <Download className="size-4" />
                    Selected NPCs JSON
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={() => {
                      const checked = library.filter((n) => n.selected);
                      const list = checked.length ? checked : library;
                      downloadText(
                        "loreforge-npc-library.json",
                        JSON.stringify(toNpcExport(list), null, 2),
                        "application/json",
                      );
                      toast.success("Library JSON downloaded");
                    }}
                  >
                    <Download className="size-4" />
                    NPC library JSON
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={() => {
                      downloadText(
                        `${slugify(project.title)}-aid.txt`,
                        projectPastePack(project),
                      );
                      toast.success("Paste pack downloaded");
                    }}
                  >
                    <Download className="size-4" />
                    Download paste pack
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={() => {
                      downloadText(
                        `${slugify(project.title)}-cards.json`,
                        JSON.stringify(toAidStoryCards(project.cards), null, 2),
                        "application/json",
                      );
                      toast.success("Story cards JSON downloaded");
                    }}
                  >
                    <Download className="size-4" />
                    Download cards JSON
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={() => {
                      downloadText(
                        `${slugify(project.title)}.loreforge.json`,
                        JSON.stringify(project, null, 2),
                        "application/json",
                      );
                    }}
                  >
                    <Download className="size-4" />
                    Download project
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    className="text-destructive"
                    onSelect={() => {
                      deleteProject(project.id);
                      toast.success("Project deleted");
                      void navigate({ to: "/" });
                    }}
                  >
                    <Trash2 className="size-4" />
                    Delete project
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : null}
        </div>
      </div>
    </header>
  );
}
