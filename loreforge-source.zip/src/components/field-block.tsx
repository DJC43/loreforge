import { Loader2, PenLine } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { CopyButton } from "@/components/copy-button";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { rewriteField } from "@/lib/ai";
import { detectPlaceholders, estimateTokens } from "@/lib/aid";
import { cn } from "@/lib/utils";

const PRESETS = [
  { id: "draft", label: "First draft" },
  { id: "tighten", label: "Tighten" },
  { id: "expand", label: "Expand" },
  { id: "vivid", label: "More sensory" },
  { id: "aid", label: "AID-native" },
];

export function FieldBlock({
  label,
  hint,
  value,
  onChange,
  field,
  context,
  minH = "min-h-32",
  warnAt,
}: {
  label: string;
  hint?: string;
  value: string;
  onChange: (v: string) => void;
  field: string;
  context?: string;
  minH?: string;
  warnAt?: number;
}) {
  const [busy, setBusy] = useState(false);
  const tokens = estimateTokens(value);
  const placeholders = detectPlaceholders(value);
  const over = warnAt ? value.length > warnAt : false;

  async function run(instruction: string) {
    setBusy(true);
    try {
      const res = await rewriteField({ data: { field, instruction, text: value, context } });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      onChange(res.text);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Rewrite failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Label htmlFor={field}>{label}</Label>
        <div className="flex items-center gap-1">
          <span
            className={cn(
              "font-mono text-[11px] tabular-nums text-muted-foreground",
              over && "text-destructive",
            )}
          >
            {value.length}c · {tokens} tok
            {warnAt ? ` / ${warnAt}c` : ""}
          </span>
          <CopyButton text={value} label="Copy" success={`${label} copied`} />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button type="button" variant="ghost" size="sm" disabled={busy}>
                {busy ? <Loader2 className="animate-spin" /> : <PenLine />}
                Write
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {PRESETS.map((p) => (
                <DropdownMenuItem key={p.id} onSelect={() => void run(p.label)}>
                  {p.label}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      {hint ? <p className="text-xs text-muted-foreground">{hint}</p> : null}
      <Textarea
        id={field}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={minH}
      />
      {placeholders.length ? (
        <p className="text-xs text-steel">
          Placeholders: {placeholders.map((p) => `\${${p}}`).join(" · ")}
        </p>
      ) : null}
    </div>
  );
}
