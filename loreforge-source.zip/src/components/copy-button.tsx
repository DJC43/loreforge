import { Check, Copy } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export async function copyText(text: string, success = "Copied") {
  await navigator.clipboard.writeText(text);
  toast.success(success);
}

export function CopyButton({
  text,
  label = "Copy",
  success,
}: {
  text: string;
  label?: string;
  success?: string;
}) {
  const [done, setDone] = useState(false);
  return (
    <Button
      type="button"
      variant="ghost"
      size="sm"
      onClick={async () => {
        await copyText(text, success ?? `${label}d`);
        setDone(true);
        setTimeout(() => setDone(false), 1200);
      }}
    >
      {done ? <Check /> : <Copy />}
      {label}
    </Button>
  );
}
