import { cn } from "@/lib/utils";

export function ChipMulti({
  values,
  selected,
  onToggle,
}: {
  values: readonly string[];
  selected: string[];
  onToggle: (v: string) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {values.map((v) => {
        const on = selected.some((s) => s.toLowerCase() === v.toLowerCase());
        return (
          <button
            key={v}
            type="button"
            aria-pressed={on}
            onClick={() => onToggle(v)}
            className={cn(
              "h-11 rounded-full px-4 text-sm",
              on ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
            )}
          >
            {v}
          </button>
        );
      })}
    </div>
  );
}

export function ChipSingle({
  values,
  current,
  onPick,
}: {
  values: readonly string[];
  current: string;
  onPick: (v: string) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {values.map((v) => (
        <button
          key={v}
          type="button"
          aria-pressed={current === v}
          onClick={() => onPick(v)}
          className={cn(
            "h-11 rounded-full px-4 text-sm",
            current === v ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground",
          )}
        >
          {v}
        </button>
      ))}
    </div>
  );
}
