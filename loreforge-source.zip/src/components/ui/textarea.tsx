import * as React from "react";
import { cn } from "@/lib/utils";

const Textarea = React.forwardRef<
  HTMLTextAreaElement,
  React.ComponentProps<"textarea">
>(({ className, ...props }, ref) => (
  <textarea
    ref={ref}
    className={cn(
      "flex min-h-28 w-full rounded-md border border-input bg-card px-3 py-2.5 text-sm leading-relaxed text-foreground shadow-[var(--shadow-border)] placeholder:text-muted-foreground/80 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60 disabled:cursor-not-allowed disabled:opacity-50",
      className,
    )}
    suppressHydrationWarning
    {...props}
  />
));
Textarea.displayName = "Textarea";

export { Textarea };
