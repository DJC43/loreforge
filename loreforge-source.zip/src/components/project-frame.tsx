import { Link, Outlet, useParams, useRouterState } from "@tanstack/react-router";
import {
  BookOpen,
  Compass,
  Image as ImageIcon,
  Landmark,
  Lightbulb,
  MapPin,
  Shapes,
  Users,
} from "lucide-react";
import type { ReactNode } from "react";
import { cn } from "@/lib/utils";
import { useStudio } from "@/lib/store";

const NAV: {
  to:
    | "/project/$id"
    | "/project/$id/brainstorm"
    | "/project/$id/npcs"
    | "/project/$id/factions"
    | "/project/$id/locations"
    | "/project/$id/elements"
    | "/project/$id/scenario"
    | "/project/$id/covers";
  label: string;
  icon: typeof Compass;
  exact?: boolean;
  group?: string;
}[] = [
  { to: "/project/$id/brainstorm", label: "Idea", icon: Lightbulb, group: "Studio" },
  { to: "/project/$id", label: "Overview", icon: Compass, exact: true, group: "Studio" },
  { to: "/project/$id/npcs", label: "NPCs", icon: Users, group: "World" },
  { to: "/project/$id/factions", label: "Factions", icon: Landmark, group: "World" },
  { to: "/project/$id/locations", label: "Locations", icon: MapPin, group: "World" },
  { to: "/project/$id/elements", label: "Other", icon: Shapes, group: "World" },
  { to: "/project/$id/scenario", label: "Plot", icon: BookOpen, group: "Craft" },
  { to: "/project/$id/covers", label: "Covers", icon: ImageIcon, group: "Craft" },
];

export function ProjectFrame() {
  const { id } = useParams({ from: "/project/$id" });
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hasHydrated = useStudio((s) => s.hasHydrated);
  const project = useStudio((s) => s.projects.find((p) => p.id === id));

  if (!hasHydrated && !project) {
    return <div className="mx-auto h-[60vh] max-w-6xl animate-pulse rounded-xl bg-card" />;
  }

  if (!project) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-lg flex-col items-center justify-center gap-3 px-6 text-center">
        <h1 className="font-display text-3xl">No such project</h1>
        <p className="text-sm text-muted-foreground">It may have been deleted from this browser.</p>
        <Link to="/" className="text-sm text-steel underline-offset-4 hover:underline">
          Back to library
        </Link>
      </div>
    );
  }

  function isActive(item: (typeof NAV)[number]) {
    const href = item.to.replace("$id", id);
    return item.exact ? pathname === href || pathname === `${href}/` : pathname.startsWith(href);
  }

  const groups = ["Studio", "World", "Craft"];

  return (
    <div className="mx-auto flex w-full max-w-6xl gap-0 md:gap-8">
      <aside className="hidden w-48 shrink-0 py-8 md:block">
        <div className="sticky top-20 space-y-5">
          {groups.map((group) => (
            <div key={group}>
              <p className="mb-1 px-3 text-[10px] font-medium tracking-[0.16em] text-muted-foreground uppercase">
                {group}
              </p>
              <div className="space-y-1">
                {NAV.filter((n) => n.group === group).map((item) => {
                  const active = isActive(item);
                  const Icon = item.icon;
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      params={{ id }}
                      className={cn(
                        "flex h-11 items-center gap-2 rounded-md px-3 text-sm transition-colors",
                        active
                          ? "bg-secondary text-foreground"
                          : "text-muted-foreground hover:bg-muted hover:text-foreground",
                      )}
                    >
                      <Icon className="size-4" />
                      {item.label}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </aside>
      <div className="min-w-0 flex-1 px-4 py-4 pb-8 md:px-0 md:py-8">
        <nav className="sticky top-14 z-20 -mx-4 mb-6 border-b border-border bg-background/95 px-4 backdrop-blur-sm md:hidden">
          <ul className="flex gap-1 overflow-x-auto py-2">
            {NAV.map((item) => {
              const active = isActive(item);
              const Icon = item.icon;
              return (
                <li key={item.to} className="shrink-0">
                  <Link
                    to={item.to}
                    params={{ id }}
                    className={cn(
                      "flex h-11 items-center gap-1.5 rounded-full px-3 text-xs",
                      active ? "bg-secondary text-foreground" : "text-muted-foreground",
                    )}
                  >
                    <Icon className="size-3.5" />
                    {item.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
        <Outlet />
      </div>
    </div>
  );
}

export function SectionIntro({
  kicker,
  title,
  lede,
  actions,
}: {
  kicker?: string;
  title: string;
  lede?: string;
  actions?: ReactNode;
}) {
  return (
    <header className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="space-y-1">
        {kicker ? (
          <p className="text-[11px] font-medium tracking-[0.16em] text-steel uppercase">{kicker}</p>
        ) : null}
        <h1 className="font-display text-3xl font-medium tracking-tight md:text-4xl">{title}</h1>
        {lede ? <p className="max-w-xl text-sm text-muted-foreground">{lede}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap gap-2">{actions}</div> : null}
    </header>
  );
}
