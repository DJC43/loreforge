import { Loader2, Sparkles } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { rewriteField } from "@/lib/ai";

export function GrokFill({
  field,
  value,
  onChange,
  context,
  instruction,
  label,
}: {
  field: string;
  value: string;
  onChange: (v: string) => void;
  context?: string;
  instruction?: string;
  label?: string;
}) {
  const [busy, setBusy] = useState(false);
  const empty = !value.trim();

  async function run() {
    setBusy(true);
    try {
      const res = await rewriteField({
        data: {
          field,
          instruction: instruction ?? (empty ? "First draft" : "Regenerate a fresh alternative"),
          text: value,
          context,
        },
      });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      onChange(res.text);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Write failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Button type="button" variant="ghost" size="sm" onClick={() => void run()} disabled={busy}>
      {busy ? <Loader2 className="animate-spin" /> : <Sparkles />}
      {label ?? (empty ? "Fill" : "Regen")}
    </Button>
  );
}
