import { COVER_MEDIUMS } from "./catalog";
import type { CoverDraft, NpcFields, Project, StoryCard } from "./types";

/** Rough GPT-style estimate: ~4 characters per token. */
export function estimateTokens(text: string) {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  return Math.max(1, Math.ceil(trimmed.length / 4));
}

export function detectPlaceholders(text: string): string[] {
  const found = new Set<string>();
  const re = /\$\{([^}]+)\}/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    const q = m[1]?.trim();
    if (q) found.add(q);
  }
  return [...found];
}

export function collectPlaceholders(project: Project): string[] {
  const blobs = [
    project.scenario.prompt,
    project.scenario.plotEssentials,
    project.scenario.authorsNote,
    project.scenario.publicDescription,
    ...project.cards.flatMap((c) => [c.value, c.keys, c.title, c.description]),
  ];
  const all = new Set<string>();
  for (const blob of blobs) {
    for (const p of detectPlaceholders(blob)) all.add(p);
  }
  return [...all];
}

export function composeNpcEntry(name: string, npc: NpcFields): string {
  const parts: string[] = [];
  const n = name.trim();
  const role = npc.role.trim();
  if (n && role) parts.push(`${n} is ${role}.`);
  else if (n) parts.push(`${n}.`);
  const push = (raw: string) => {
    const t = raw.trim();
    if (!t) return;
    parts.push(/[.!?]$/.test(t) ? t : `${t}.`);
  };
  push(npc.appearance);
  push(npc.personality);
  if (npc.speech.trim()) {
    const s = npc.speech.trim();
    push(s.toLowerCase().startsWith("speak") ? s : `Speaks ${s}`);
  }
  push(npc.motivations);
  push(npc.relationships);
  if (npc.secrets.trim()) push(`Secret: ${npc.secrets.trim()}`);
  push(npc.abilities);
  if (npc.quirks.trim()) push(`Quirk: ${npc.quirks.trim()}`);
  return parts.join(" ").replace(/\s+/g, " ").trim();
}

export function keysFromName(name: string, aliases = "") {
  const bits = [name, ...aliases.split(/[,;/]/)]
    .map((s) => s.trim())
    .filter(Boolean);
  const unique: string[] = [];
  for (const b of bits) {
    if (!unique.some((u) => u.toLowerCase() === b.toLowerCase())) unique.push(b);
  }
  return unique.join(", ");
}

export function isIncludedInExport(card: StoryCard) {
  return card.includeInExport !== false;
}

export function exportableCards(cards: StoryCard[]) {
  return cards.filter(isIncludedInExport);
}

export function storyCardTree(all: StoryCard[]) {
  const ids = new Set(all.map((c) => c.id));
  const roots = all.filter((c) => !c.parentId || !ids.has(c.parentId));
  const rows: { card: StoryCard; depth: number }[] = [];
  const walk = (node: StoryCard, depth: number) => {
    rows.push({ card: node, depth });
    for (const c of all) {
      if (c.parentId === node.id) walk(c, depth + 1);
    }
  };
  for (const r of roots) walk(r, 0);
  return rows;
}

export function toAidStoryCards(cards: StoryCard[]) {
  return exportableCards(cards).map((c) => ({
    keys: c.keys,
    value: c.value,
    type: c.type === "other" ? "" : c.type,
    title: c.title,
    description: c.description,
    useForCharacterCreation: c.useForCharacterCreation,
  }));
}

export function alwaysOnTokens(project: Project) {
  const s = project.scenario;
  return (
    estimateTokens(s.prompt) +
    estimateTokens(s.plotEssentials) +
    estimateTokens(s.authorsNote) +
    estimateTokens(s.aiInstructions) +
    estimateTokens(s.storySummary)
  );
}

export function cardsTokens(project: Project) {
  return exportableCards(project.cards).reduce((n, c) => n + estimateTokens(c.value), 0);
}

export function projectPastePack(project: Project): string {
  const s = project.scenario;
  const cards = JSON.stringify(toAidStoryCards(project.cards), null, 2);
  const choices =
    s.openingType === "multipleChoice" && s.choices.length
      ? s.choices
          .map((c, i) => `### Choice ${i + 1}: ${c.label}\n${c.prompt}`)
          .join("\n\n")
      : "";
  return [
    `# ${project.title}`,
    project.logline ? `> ${project.logline}` : "",
    `Genre: ${project.genres.join(", ") || "—"} · Tone: ${project.tones.join(", ") || "—"} · Rating: ${project.rating}`,
    project.tags.length ? `Tags: ${project.tags.join(", ")}` : "",
    "",
    "## Public description",
    s.publicDescription || "(empty)",
    "",
    `## Opening type: ${s.openingType}`,
    "",
    "## Starting prompt",
    s.prompt || "(empty)",
    choices ? `\n## Multiple-choice openings\n\n${choices}` : "",
    "",
    "## Plot essentials",
    s.plotEssentials || "(empty)",
    "",
    "## Author's note",
    s.authorsNote || "(empty)",
    "",
    "## AI instructions",
    s.aiInstructions || "(empty)",
    "",
    "## Story summary (seed)",
    s.storySummary || "(empty)",
    s.thirdPersonName ? `\n## Third person name\n${s.thirdPersonName}` : "",
    "",
    "## Story cards (AI Dungeon JSON)",
    cards,
  ]
    .filter((line) => line !== "")
    .join("\n");
}

export function downloadText(filename: string, contents: string, mime = "text/plain") {
  const blob = new Blob([contents], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function downloadDataUrl(filename: string, dataUrl: string) {
  const a = document.createElement("a");
  a.href = dataUrl;
  a.download = filename;
  a.click();
}

export function slugify(title: string) {
  return (
    title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "")
      .slice(0, 48) || "loreforge"
  );
}

export function mediumBlend(draft: CoverDraft) {
  const picked = COVER_MEDIUMS.map((m) => ({
    ...m,
    weight: draft.mediums[m.id] ?? 0,
  })).filter((m) => m.weight > 0);
  if (!picked.length) {
    return {
      summary: "photorealistic cinematic still",
      parts: COVER_MEDIUMS.filter((m) => m.id === "realistic" || m.id === "cinema"),
    };
  }
  const total = picked.reduce((n, m) => n + m.weight, 0) || 1;
  const summary = picked
    .sort((a, b) => b.weight - a.weight)
    .map((m) => `${Math.round((m.weight / total) * 100)}% ${m.label.toLowerCase()} (${m.text})`)
    .join(", ");
  return { summary, parts: picked };
}

export function composeCoverPrompt(project: Project): string {
  const d = project.coverDraft;
  const blend = mediumBlend(d);
  const bits = [
    d.subject.trim() || `A cover illustration for "${project.title}"`,
    d.composition.trim(),
    d.lighting.trim(),
    d.mood.trim(),
    d.extra.trim(),
    project.logline,
    `Medium blend: ${blend.summary}.`,
    "No text, letters, titles, signatures, or watermarks.",
    "Place the main subject in the center of the frame so a square crop still reads.",
    "Finished, publishable cover art.",
  ].filter(Boolean);
  return bits.join(" ");
}

export function toggleList(list: string[], value: string): string[] {
  const has = list.some((v) => v.toLowerCase() === value.toLowerCase());
  if (has) return list.filter((v) => v.toLowerCase() !== value.toLowerCase());
  return [...list, value];
}

export function emptyScenarioFields(project: Project): string[] {
  const s = project.scenario;
  const blanks: string[] = [];
  if (!s.publicDescription.trim()) blanks.push("publicDescription");
  if (!s.prompt.trim()) blanks.push("prompt");
  if (!s.plotEssentials.trim()) blanks.push("plotEssentials");
  if (!s.authorsNote.trim()) blanks.push("authorsNote");
  if (!s.aiInstructions.trim()) blanks.push("aiInstructions");
  if (!s.storySummary.trim()) blanks.push("storySummary");
  if (s.openingType === "multipleChoice" && s.choices.filter((c) => c.prompt.trim()).length < 2) {
    blanks.push("choices");
  }
  return blanks;
}
