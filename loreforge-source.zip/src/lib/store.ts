import { create } from "zustand";
import { persist } from "zustand/middleware";
import { createDemoLibrary, createDemoProject, withDemoNests } from "./seed";
import { normalizeLibraryElement, normalizeLibraryNpc, normalizeProject } from "./migrate";
import { cardToLibraryElement, cardToLibraryNpc } from "./dungeon";
import { CARD_TYPES, emptyCard, emptyNpc, emptyProject, type CardType, type CoverArt, type CoverDraft, type IdeaItem, type LibraryElement, type LibraryNpc, type OpenQuestion, type Project, type StoryCard } from "./types";
import { nestDraft } from "./catalog";
import { newId } from "./utils";

type StudioState = {
  projects: Project[];
  npcLibrary: LibraryNpc[];
  elementLibrary: LibraryElement[];
  hasHydrated: boolean;
  setHydrated: () => void;
  createProject: (partial?: Partial<Project>) => Project;
  duplicateProject: (id: string) => Project | null;
  deleteProject: (id: string) => void;
  importProject: (data: unknown) => Project;
  getProject: (id: string) => Project | undefined;
  updateProject: (id: string, patch: Partial<Project>) => void;
  patchScenario: (id: string, patch: Partial<Project["scenario"]>) => void;
  patchBrainstorm: (id: string, patch: Partial<Project["brainstorm"]>) => void;
  patchCoverDraft: (id: string, patch: Partial<CoverDraft>) => void;
  upsertCard: (projectId: string, card: StoryCard) => void;
  addBlankCard: (projectId: string, type?: StoryCard["type"], nest?: { parentId: string; nestRole?: string }) => StoryCard;
  removeCard: (projectId: string, cardId: string) => void;
  addCover: (projectId: string, cover: CoverArt) => void;
  removeCover: (projectId: string, coverId: string) => void;
  setCover: (projectId: string, coverId?: string) => void;
  lockCover: (projectId: string, coverId: string, locked: boolean) => void;
  appendChat: (projectId: string, role: "user" | "assistant", content: string) => void;
  setNotes: (projectId: string, notes: string) => void;
  addIdeaItem: (projectId: string, text: string, status?: IdeaItem["status"]) => void;
  patchIdeaItem: (projectId: string, itemId: string, patch: Partial<IdeaItem>) => void;
  removeIdeaItem: (projectId: string, itemId: string) => void;
  addQuestion: (projectId: string, question: string) => void;
  patchQuestion: (projectId: string, qId: string, patch: Partial<OpenQuestion>) => void;
  removeQuestion: (projectId: string, qId: string) => void;
  applyForge: (
    projectId: string,
    data: {
      title?: string;
      logline?: string;
      genre?: string;
      genres?: string[];
      tone?: string;
      tones?: string[];
      tags?: string[];
      publicDescription?: string;
      prompt?: string;
      plotEssentials?: string;
      authorsNote?: string;
      aiInstructions?: string;
      storySummary?: string;
      choices?: Array<{ label: string; prompt: string }>;
      cards?: Array<{
        title: string;
        type?: string;
        keys?: string;
        value: string;
        description?: string;
        useForCharacterCreation?: boolean;
        npc?: StoryCard["npc"];
      }>;
    },
  ) => void;
  addNpcToLibrary: (npc: Omit<LibraryNpc, "id" | "selected" | "createdAt"> | LibraryNpc) => LibraryNpc;
  updateLibraryNpc: (id: string, patch: Partial<LibraryNpc>) => void;
  removeLibraryNpc: (id: string) => void;
  toggleLibrarySelected: (id: string, selected?: boolean) => void;
  clearLibrarySelection: () => void;
  importLibraryNpcs: (list: unknown[]) => number;
  saveCardToLibrary: (projectId: string, cardId: string) => LibraryNpc | LibraryElement | null;
  addLibraryNpcToProject: (projectId: string, libraryId: string, scenarioSpecific?: boolean) => StoryCard | null;
  addElementToLibrary: (
    el: Omit<LibraryElement, "id" | "selected" | "createdAt"> | LibraryElement,
  ) => LibraryElement;
  updateLibraryElement: (id: string, patch: Partial<LibraryElement>) => void;
  removeLibraryElement: (id: string) => void;
  addLibraryElementToProject: (
    projectId: string,
    libraryId: string,
    scenarioSpecific?: boolean,
  ) => StoryCard | null;
};

function touch(p: Project): Project {
  return { ...p, updatedAt: Date.now() };
}

function mapProject(projects: Project[], id: string, fn: (p: Project) => Project): Project[] {
  return projects.map((p) => (p.id === id ? touch(fn(p)) : p));
}

function dropCardAndDescendants(cards: StoryCard[], id: string): StoryCard[] {
  const drop = new Set<string>([id]);
  let grew = true;
  while (grew) {
    grew = false;
    for (const c of cards) {
      if (c.parentId && drop.has(c.parentId) && !drop.has(c.id)) {
        drop.add(c.id);
        grew = true;
      }
    }
  }
  return cards.filter((c) => !drop.has(c.id));
}

export const useStudio = create<StudioState>()(
  persist(
    (set, get) => ({
      projects: [createDemoProject()],
      npcLibrary: createDemoLibrary(),
      elementLibrary: [],
      hasHydrated: false,
      setHydrated: () => set({ hasHydrated: true }),
      createProject: (partial) => {
        const project = emptyProject(partial);
        set((s) => ({ projects: [project, ...s.projects] }));
        return project;
      },
      duplicateProject: (id) => {
        const src = get().projects.find((p) => p.id === id);
        if (!src) return null;
        const copy: Project = {
          ...structuredClone(src),
          id: newId(),
          title: `${src.title} (copy)`,
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        set((s) => ({ projects: [copy, ...s.projects] }));
        return copy;
      },
      deleteProject: (id) =>
        set((s) => ({ projects: s.projects.filter((p) => p.id !== id) })),
      importProject: (data) => {
        const project = normalizeProject({
          ...(typeof data === "object" && data ? data : {}),
          id: newId(),
          createdAt: Date.now(),
          updatedAt: Date.now(),
        });
        set((s) => ({ projects: [project, ...s.projects] }));
        return project;
      },
      getProject: (id) => get().projects.find((p) => p.id === id),
      updateProject: (id, patch) =>
        set((s) => ({
          projects: s.projects.map((p) => (p.id === id ? touch({ ...p, ...patch }) : p)),
        })),
      patchScenario: (id, patch) =>
        set((s) => ({
          projects: mapProject(s.projects, id, (p) => ({
            ...p,
            scenario: { ...p.scenario, ...patch },
          })),
        })),
      patchBrainstorm: (id, patch) =>
        set((s) => ({
          projects: mapProject(s.projects, id, (p) => ({
            ...p,
            brainstorm: { ...p.brainstorm, ...patch },
            logline:
              patch.idea !== undefined && (p.brainstorm.ideaLocked || patch.ideaLocked)
                ? patch.idea
                : p.logline,
          })),
        })),
      patchCoverDraft: (id, patch) =>
        set((s) => ({
          projects: mapProject(s.projects, id, (p) => ({
            ...p,
            coverDraft: { ...p.coverDraft, ...patch },
          })),
        })),
      upsertCard: (projectId, card) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => {
            const idx = p.cards.findIndex((c) => c.id === card.id);
            const cards =
              idx === -1 ? [...p.cards, card] : p.cards.map((c) => (c.id === card.id ? card : c));
            return { ...p, cards };
          }),
        })),
      addBlankCard: (projectId, type = "character", nest) => {
        const parent = nest
          ? get().projects.find((p) => p.id === projectId)?.cards.find((c) => c.id === nest.parentId)
          : undefined;
        const role = nest?.nestRole;
        const card = emptyCard(type);
        if (nest?.parentId) card.parentId = nest.parentId;
        if (role) card.nestRole = role;
        if (parent) {
          card.scenarioSpecific = parent.scenarioSpecific;
          if (role) {
            const draft = nestDraft(parent.title, role);
            card.title = draft.title;
            card.keys = draft.keys;
            card.description = draft.description;
          }
        }
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            cards: [...p.cards, card],
          })),
        }));
        return card;
      },
      removeCard: (projectId, cardId) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            cards: dropCardAndDescendants(p.cards, cardId),
          })),
        })),
      addCover: (projectId, cover) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => {
            const covers = [cover, ...p.covers].slice(0, 8);
            return { ...p, covers, coverId: cover.locked || !p.coverId ? cover.id : p.coverId };
          }),
        })),
      removeCover: (projectId, coverId) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => {
            const covers = p.covers.filter((c) => c.id !== coverId);
            return {
              ...p,
              covers,
              coverId: p.coverId === coverId ? covers[0]?.id : p.coverId,
            };
          }),
        })),
      setCover: (projectId, coverId) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({ ...p, coverId })),
        })),
      lockCover: (projectId, coverId, locked) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            covers: p.covers.map((c) => (c.id === coverId ? { ...c, locked } : c)),
            coverId: locked ? coverId : p.coverId,
          })),
        })),
      appendChat: (projectId, role, content) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            brainstorm: {
              ...p.brainstorm,
              messages: [
                ...p.brainstorm.messages,
                { id: newId(), role, content, createdAt: Date.now() },
              ],
            },
          })),
        })),
      setNotes: (projectId, notes) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            brainstorm: { ...p.brainstorm, notes },
          })),
        })),
      addIdeaItem: (projectId, text, status = "open") =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            brainstorm: {
              ...p.brainstorm,
              items: [
                ...p.brainstorm.items,
                { id: newId(), text, status, createdAt: Date.now() },
              ],
            },
          })),
        })),
      patchIdeaItem: (projectId, itemId, patch) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            brainstorm: {
              ...p.brainstorm,
              items: p.brainstorm.items.map((i) => (i.id === itemId ? { ...i, ...patch } : i)),
            },
          })),
        })),
      removeIdeaItem: (projectId, itemId) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            brainstorm: {
              ...p.brainstorm,
              items: p.brainstorm.items.filter((i) => i.id !== itemId),
            },
          })),
        })),
      addQuestion: (projectId, question) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            brainstorm: {
              ...p.brainstorm,
              questions: [
                ...p.brainstorm.questions,
                { id: newId(), question, notes: "", resolved: false, createdAt: Date.now() },
              ],
            },
          })),
        })),
      patchQuestion: (projectId, qId, patch) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            brainstorm: {
              ...p.brainstorm,
              questions: p.brainstorm.questions.map((q) => (q.id === qId ? { ...q, ...patch } : q)),
            },
          })),
        })),
      removeQuestion: (projectId, qId) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            brainstorm: {
              ...p.brainstorm,
              questions: p.brainstorm.questions.filter((q) => q.id !== qId),
            },
          })),
        })),
      applyForge: (projectId, data) =>
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => {
            const forgedCards: StoryCard[] = (data.cards ?? []).map((c) => ({
              id: newId(),
              title: c.title,
              type: (CARD_TYPES as readonly string[]).includes(c.type ?? "")
                ? (c.type as CardType)
                : "other",
              keys: c.keys || c.title,
              value: c.value,
              description: c.description || "",
              useForCharacterCreation: Boolean(c.useForCharacterCreation),
              scenarioSpecific: true,
              locked: false,
              includeInExport: true,
              npc: c.npc,
            }));
            const genres =
              data.genres?.length ? data.genres : data.genre ? [data.genre] : p.genres;
            const tones = data.tones?.length ? data.tones : data.tone ? [data.tone] : p.tones;
            const choices = data.choices?.length
              ? data.choices.map((c) => ({ id: newId(), label: c.label, prompt: c.prompt }))
              : p.scenario.choices;
            return {
              ...p,
              title: data.title || p.title,
              logline: data.logline ?? p.logline,
              genres,
              tones,
              tags: data.tags ?? p.tags,
              scenario: {
                ...p.scenario,
                publicDescription: data.publicDescription ?? p.scenario.publicDescription,
                prompt: data.prompt ?? p.scenario.prompt,
                plotEssentials: data.plotEssentials ?? p.scenario.plotEssentials,
                authorsNote: data.authorsNote ?? p.scenario.authorsNote,
                aiInstructions: data.aiInstructions ?? p.scenario.aiInstructions,
                storySummary: data.storySummary ?? p.scenario.storySummary,
                choices,
              },
              cards: forgedCards.length ? [...p.cards, ...forgedCards] : p.cards,
            };
          }),
        })),
      addNpcToLibrary: (npc) => {
        const entry: LibraryNpc = {
          selected: false,
          createdAt: Date.now(),
          ...npc,
          id: "id" in npc && npc.id ? npc.id : newId(),
        };
        set((s) => ({ npcLibrary: [entry, ...s.npcLibrary] }));
        return entry;
      },
      updateLibraryNpc: (id, patch) =>
        set((s) => ({
          npcLibrary: s.npcLibrary.map((n) => (n.id === id ? { ...n, ...patch } : n)),
        })),
      removeLibraryNpc: (id) =>
        set((s) => ({ npcLibrary: s.npcLibrary.filter((n) => n.id !== id) })),
      toggleLibrarySelected: (id, selected) =>
        set((s) => ({
          npcLibrary: s.npcLibrary.map((n) =>
            n.id === id ? { ...n, selected: selected ?? !n.selected } : n,
          ),
        })),
      clearLibrarySelection: () =>
        set((s) => ({ npcLibrary: s.npcLibrary.map((n) => ({ ...n, selected: false })) })),
      importLibraryNpcs: (list) => {
        const imported = list.map(normalizeLibraryNpc).map((n) => ({
          ...n,
          id: newId(),
          selected: false,
          createdAt: Date.now(),
        }));
        set((s) => ({ npcLibrary: [...imported, ...s.npcLibrary] }));
        return imported.length;
      },
      saveCardToLibrary: (projectId, cardId) => {
        const project = get().projects.find((p) => p.id === projectId);
        const card = project?.cards.find((c) => c.id === cardId);
        if (!card) return null;
        if (card.type === "character") {
          const entry: LibraryNpc = {
            id: newId(),
            ...cardToLibraryNpc(card),
            selected: false,
            createdAt: Date.now(),
          };
          set((s) => ({
            npcLibrary: [entry, ...s.npcLibrary],
            projects: mapProject(s.projects, projectId, (p) => ({
              ...p,
              cards: p.cards.map((c) => (c.id === cardId ? { ...c, libraryId: entry.id } : c)),
            })),
          }));
          return entry;
        }
        const entry: LibraryElement = {
          id: newId(),
          ...cardToLibraryElement(card),
          selected: false,
          createdAt: Date.now(),
        };
        set((s) => ({
          elementLibrary: [entry, ...s.elementLibrary],
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            cards: p.cards.map((c) => (c.id === cardId ? { ...c, libraryId: entry.id } : c)),
          })),
        }));
        return entry;
      },
      addLibraryNpcToProject: (projectId, libraryId, scenarioSpecific = false) => {
        const npc = get().npcLibrary.find((n) => n.id === libraryId);
        if (!npc) return null;
        const card: StoryCard = {
          id: newId(),
          title: npc.title,
          type: "character",
          keys: npc.keys || npc.title,
          value: npc.value,
          description: npc.description,
          useForCharacterCreation: false,
          scenarioSpecific,
          locked: false,
          includeInExport: true,
          portraitDataUrl: npc.portraitDataUrl,
          libraryId: npc.id,
          npc: npc.npc ?? emptyNpc(),
        };
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            cards: [...p.cards, card],
          })),
        }));
        return card;
      },
      addElementToLibrary: (el) => {
        const entry: LibraryElement = {
          selected: false,
          createdAt: Date.now(),
          ...el,
          id: "id" in el && el.id ? el.id : newId(),
        };
        set((s) => ({ elementLibrary: [entry, ...s.elementLibrary] }));
        return entry;
      },
      updateLibraryElement: (id, patch) =>
        set((s) => ({
          elementLibrary: s.elementLibrary.map((n) => (n.id === id ? { ...n, ...patch } : n)),
        })),
      removeLibraryElement: (id) =>
        set((s) => ({ elementLibrary: s.elementLibrary.filter((n) => n.id !== id) })),
      addLibraryElementToProject: (projectId, libraryId, scenarioSpecific = false) => {
        const el = get().elementLibrary.find((n) => n.id === libraryId);
        if (!el) return null;
        const card: StoryCard = {
          id: newId(),
          title: el.title,
          type: el.type,
          keys: el.keys || el.title,
          value: el.value,
          description: el.description,
          useForCharacterCreation: el.useForCharacterCreation,
          scenarioSpecific,
          locked: false,
          includeInExport: true,
          libraryId: el.id,
        };
        set((s) => ({
          projects: mapProject(s.projects, projectId, (p) => ({
            ...p,
            cards: [...p.cards, card],
          })),
        }));
        return card;
      },
    }),
    {
      name: "loreforge-studio",
      version: 5,
      partialize: (s) => ({
        projects: s.projects,
        npcLibrary: s.npcLibrary,
        elementLibrary: s.elementLibrary,
      }),
      migrate: (persisted, version) => {
        const raw = (persisted ?? {}) as {
          projects?: unknown[];
          npcLibrary?: unknown[];
          elementLibrary?: unknown[];
        };
        const projects = Array.isArray(raw.projects)
          ? raw.projects.map(normalizeProject).map(withDemoNests)
          : [];
        const npcLibrary = Array.isArray(raw.npcLibrary)
          ? raw.npcLibrary.map(normalizeLibraryNpc)
          : version < 2
            ? createDemoLibrary()
            : [];
        const elementLibrary = Array.isArray(raw.elementLibrary)
          ? raw.elementLibrary.map(normalizeLibraryElement)
          : [];
        return { projects, npcLibrary, elementLibrary };
      },
      onRehydrateStorage: () => (state) => {
        if (!state) return;
        state.projects = (state.projects ?? []).map(normalizeProject).map(withDemoNests);
        state.npcLibrary = (state.npcLibrary ?? []).map(normalizeLibraryNpc);
        state.elementLibrary = (state.elementLibrary ?? []).map(normalizeLibraryElement);
        if (!state.projects.length) state.projects = [createDemoProject()];
        if (!state.npcLibrary.length) state.npcLibrary = createDemoLibrary();
        state.hasHydrated = true;
      },
    },
  ),
);
