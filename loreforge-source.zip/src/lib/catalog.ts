export const GENRES = [
  "Fantasy",
  "Sci-fi",
  "Horror",
  "Mystery",
  "Romance",
  "Historical",
  "Cyberpunk",
  "Western",
] as const;

export const TONES = [
  "Grim",
  "Intimate",
  "Epic",
  "Whimsical",
  "Pulp",
  "Tragic",
  "Deadpan",
  "Lush",
] as const;

export const COVER_MEDIUMS = [
  {
    id: "anime",
    label: "Anime",
    featured: true,
    text: "anime key visual, clean cel shading, expressive eyes, cinematic color script",
  },
  {
    id: "comic",
    label: "Comic book",
    featured: true,
    text: "comic book cover, bold inked linework, dramatic halftone, saturated print color",
  },
  {
    id: "playboy",
    label: "Glamour mag",
    featured: true,
    text: "vintage 1970s painted magazine cover illustration, elegant studio lighting, fully clothed glamour portrait, tasteful editorial, no nudity, no text",
  },
  {
    id: "realistic",
    label: "Realistic",
    featured: true,
    text: "photorealistic cinematic still, natural skin, physically based light, fine detail",
  },
  {
    id: "oil",
    label: "Oil painting",
    featured: false,
    text: "classical oil painting, rich impasto, museum lighting",
  },
  {
    id: "pulp",
    label: "Pulp paperback",
    featured: false,
    text: "1950s pulp paperback cover painting, dramatic painted illustration",
  },
  {
    id: "ink",
    label: "Ink wash",
    featured: false,
    text: "ink and watercolor wash, limited palette, atmospheric paper",
  },
  {
    id: "cinema",
    label: "Cinematic still",
    featured: false,
    text: "cinematic film still, anamorphic, naturalistic light",
  },
  {
    id: "woodcut",
    label: "Woodcut",
    featured: false,
    text: "detailed woodcut print, high contrast carved linework",
  },
  {
    id: "concept",
    label: "Concept art",
    featured: false,
    text: "matte painting concept art, wide establishing shot, volumetric light",
  },
  {
    id: "noir",
    label: "Noir grain",
    featured: false,
    text: "noir lithograph, deep shadows, sparse light, film grain",
  },
] as const;

export type CoverMediumId = (typeof COVER_MEDIUMS)[number]["id"];

export const DEFAULT_MEDIUMS: Record<string, number> = {
  anime: 0,
  comic: 0,
  playboy: 0,
  realistic: 55,
  oil: 0,
  pulp: 0,
  ink: 0,
  cinema: 25,
  woodcut: 0,
  concept: 0,
  noir: 0,
};

export const NPC_FIELDS = [
  ["aliases", "Aliases"],
  ["role", "Role"],
  ["appearance", "Appearance"],
  ["personality", "Personality"],
  ["speech", "Speech"],
  ["motivations", "Motivations"],
  ["relationships", "Relationships"],
  ["secrets", "Secrets"],
  ["abilities", "Abilities"],
  ["quirks", "Quirks"],
] as const;

export const NEST_ROLES = [
  {
    id: "backstory",
    label: "Backstory",
    hint: "History that belongs under this card.",
  },
  {
    id: "motivation",
    label: "Motivation",
    hint: "What they want, and what they will pay for it.",
  },
  {
    id: "secret",
    label: "Secret",
    hint: "A fact they hide until a trigger pulls it.",
  },
  {
    id: "relationship",
    label: "Relationship",
    hint: "How they stand toward someone else.",
  },
  {
    id: "history",
    label: "History",
    hint: "A past event this card remembers.",
  },
  {
    id: "note",
    label: "Note",
    hint: "A side note the model should recall with this trigger.",
  },
] as const;

export type NestRoleId = (typeof NEST_ROLES)[number]["id"];

export function nestRoleLabel(id?: string) {
  return NEST_ROLES.find((r) => r.id === id)?.label ?? (id ? "Nested" : "Nested card");
}

export function nestRoleHint(id?: string) {
  return NEST_ROLES.find((r) => r.id === id)?.hint ?? "Nested story card.";
}

export function nestDraft(parentTitle: string, role: string) {
  const label = nestRoleLabel(role);
  const name = parentTitle.trim() || "Untitled";
  return {
    title: `${name} — ${label}`,
    keys: `${name}, ${label.toLowerCase()}`,
    description: nestRoleHint(role),
  };
}
