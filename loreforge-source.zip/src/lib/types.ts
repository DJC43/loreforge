import { DEFAULT_MEDIUMS } from "./catalog";

export const CARD_TYPES = [
  "character",
  "class",
  "race",
  "location",
  "faction",
  "item",
  "creature",
  "other",
] as const;

export type CardType = (typeof CARD_TYPES)[number];

export const OPENING_TYPES = ["story", "characterCreator", "multipleChoice"] as const;
export type OpeningType = (typeof OPENING_TYPES)[number];

export const RATINGS = ["everyone", "teen", "mature"] as const;
export type Rating = (typeof RATINGS)[number];

export type IdeaStatus = "open" | "locked" | "resolved";

export type IdeaItem = {
  id: string;
  text: string;
  status: IdeaStatus;
  createdAt: number;
};

export type OpenQuestion = {
  id: string;
  question: string;
  notes: string;
  resolved: boolean;
  createdAt: number;
};

export type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: number;
};

export type BrainstormState = {
  idea: string;
  ideaLocked: boolean;
  messages: ChatMessage[];
  notes: string;
  items: IdeaItem[];
  questions: OpenQuestion[];
};

export type NpcFields = {
  aliases: string;
  role: string;
  appearance: string;
  personality: string;
  speech: string;
  motivations: string;
  relationships: string;
  secrets: string;
  abilities: string;
  quirks: string;
};

export type StoryCard = {
  id: string;
  title: string;
  type: CardType;
  keys: string;
  value: string;
  description: string;
  useForCharacterCreation: boolean;
  scenarioSpecific: boolean;
  locked: boolean;
  includeInExport: boolean;
  portraitDataUrl?: string;
  libraryId?: string;
  parentId?: string;
  nestRole?: string;
  npc?: NpcFields;
};

export type LibraryNpc = {
  id: string;
  title: string;
  keys: string;
  value: string;
  description: string;
  npc: NpcFields;
  portraitDataUrl?: string;
  selected: boolean;
  createdAt: number;
};

export type LibraryElement = {
  id: string;
  title: string;
  type: CardType;
  keys: string;
  value: string;
  description: string;
  useForCharacterCreation: boolean;
  selected: boolean;
  createdAt: number;
};

export type ScenarioChoice = {
  id: string;
  label: string;
  prompt: string;
};

export type ScenarioDraft = {
  openingType: OpeningType;
  publicDescription: string;
  prompt: string;
  plotEssentials: string;
  authorsNote: string;
  aiInstructions: string;
  storySummary: string;
  thirdPersonName: string;
  choices: ScenarioChoice[];
};

export type CoverFieldKey = "subject" | "lighting" | "composition" | "mood" | "extra";

export type CoverDraft = {
  subject: string;
  lighting: string;
  composition: string;
  mood: string;
  extra: string;
  locked: Partial<Record<CoverFieldKey, boolean>>;
  mediums: Record<string, number>;
};

export type CoverArt = {
  id: string;
  prompt: string;
  styleId: string;
  aspect: "16:9" | "1:1" | "4:3";
  imageDataUrl: string;
  locked: boolean;
  createdAt: number;
};

export type Project = {
  id: string;
  title: string;
  logline: string;
  genres: string[];
  tones: string[];
  rating: Rating;
  tags: string[];
  updatedAt: number;
  createdAt: number;
  coverId?: string;
  scenario: ScenarioDraft;
  cards: StoryCard[];
  covers: CoverArt[];
  brainstorm: BrainstormState;
  coverDraft: CoverDraft;
};

export function emptyNpc(): NpcFields {
  return {
    aliases: "",
    role: "",
    appearance: "",
    personality: "",
    speech: "",
    motivations: "",
    relationships: "",
    secrets: "",
    abilities: "",
    quirks: "",
  };
}

export function emptyBrainstorm(idea = ""): BrainstormState {
  return {
    idea,
    ideaLocked: false,
    messages: [],
    notes: "",
    items: [],
    questions: [],
  };
}

export function emptyCoverDraft(): CoverDraft {
  return {
    subject: "",
    lighting: "",
    composition: "",
    mood: "",
    extra: "",
    locked: {},
    mediums: { ...DEFAULT_MEDIUMS },
  };
}

export function emptyScenario(): ScenarioDraft {
  return {
    openingType: "story",
    publicDescription: "",
    prompt: "",
    plotEssentials: "",
    authorsNote: "",
    aiInstructions: "",
    storySummary: "",
    thirdPersonName: "",
    choices: [],
  };
}

export function emptyCard(type: CardType = "character"): StoryCard {
  return {
    id: crypto.randomUUID(),
    title: "Untitled card",
    type,
    keys: "",
    value: "",
    description: "",
    useForCharacterCreation: type === "class" || type === "race" || type === "faction",
    scenarioSpecific: true,
    locked: false,
    includeInExport: true,
    npc: type === "character" ? emptyNpc() : undefined,
  };
}

export function emptyProject(partial?: Partial<Project>): Project {
  const now = Date.now();
  return {
    id: crypto.randomUUID(),
    title: "Untitled scenario",
    logline: "",
    genres: [],
    tones: [],
    rating: "teen",
    tags: [],
    updatedAt: now,
    createdAt: now,
    scenario: emptyScenario(),
    cards: [],
    covers: [],
    brainstorm: emptyBrainstorm(),
    coverDraft: emptyCoverDraft(),
    ...partial,
  };
}
