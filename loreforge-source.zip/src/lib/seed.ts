import { emptyCoverDraft, emptyNpc, type LibraryNpc, type Project, type StoryCard } from "./types";

export function createDemoLibrary(): LibraryNpc[] {
  const now = 1_725_000_000_000;
  return [
    {
      id: "lib-maud",
      title: "Maud Vesper",
      keys: "Maud Vesper, Maud, the watch-captain, captain",
      value:
        "Maud Vesper is Hollowmere's watch-captain, a broad, grey-eyed woman who smells of pipe smoke and wet wool. She speaks in short orders and never uses the player's first name. She believes the Ledger keeps the town alive and will not tolerate pity for the unrecorded drowned. She once struck a name from the book and has not slept well since. She is loyal to Hollowmere, not to mercy.",
      description: "Stern watch-captain who treats the Ledger as law.",
      selected: false,
      createdAt: now,
      npc: {
        aliases: "Maud, the watch-captain, captain",
        role: "Hollowmere's watch-captain and the player's superior",
        appearance: "Broad, grey-eyed, salt-and-iron hair, smells of pipe smoke and wet wool",
        personality: "Short-tempered, exacting, unsentimental, privately haunted",
        speech: "in clipped orders; never uses first names",
        motivations: "Keep Hollowmere from drowning in its own dead",
        relationships: "Commands the night-clerk; distrusts the Drowned Parish",
        secrets: "Once struck a name from the Ledger and has not slept well since",
        abilities: "Knows every alley, tide mark, and unpaid debt in town",
        quirks: "Taps her pipe twice before delivering bad news",
      },
    },
  ];
}

export const DEMO_NESTED_CARDS: StoryCard[] = [
  {
    id: "card-maud-backstory",
    title: "Maud — the struck name",
    type: "other",
    parentId: "card-maud",
    nestRole: "backstory",
    keys: "struck name, the unwritten name, Maud's brother",
    value:
      "Years ago Maud struck her younger brother from the Ledger after he drowned drunk and walked home asking for the watch. The town does not know. She still keeps his pipe in the night-office drawer and will not say the name.",
    description: "The name Maud cannot say.",
    useForCharacterCreation: false,
    scenarioSpecific: false,
    locked: false,
    includeInExport: true,
  },
  {
    id: "card-maud-motive",
    title: "Maud — why the Ledger holds",
    type: "other",
    parentId: "card-maud",
    nestRole: "motivation",
    keys: "Maud's duty, keep the Ledger, unsentimental law",
    value:
      "Maud keeps the Ledger because she believes forgetting is a civic duty. Mercy, in her mind, is how Hollowmere drowns. She will punish pity in a clerk the way she would punish theft.",
    description: "Why she treats the book as law.",
    useForCharacterCreation: false,
    scenarioSpecific: false,
    locked: false,
    includeInExport: true,
  },
];

/** Idempotent: restore the demo nested cards if a persisted Hollowmere is missing them. */
export function withDemoNests(project: Project): Project {
  if (project.id !== "demo-hollowmere") return project;
  const ids = new Set(project.cards.map((c) => c.id));
  if (!ids.has("card-maud")) return project;
  const extras = DEMO_NESTED_CARDS.filter((c) => !ids.has(c.id)).map((c) => ({ ...c }));
  if (!extras.length) return project;
  const parentIdx = project.cards.findIndex((c) => c.id === "card-maud");
  const cards = [...project.cards];
  cards.splice(parentIdx + 1, 0, ...extras);
  return { ...project, cards };
}

export function createDemoProject(): Project {
  const now = 1_725_000_000_000;
  return {
    id: "demo-hollowmere",
    title: "The Night Ledger of Hollowmere",
    logline:
      "In a river town where the drowned return with the fog, a newly sworn night-clerk must keep the ledger of the dead — and decide which names are allowed to come home.",
    genres: ["Mystery", "Horror"],
    tones: ["Grim", "Intimate"],
    rating: "teen",
    tags: ["mystery", "gothic", "ghosts", "small town"],
    updatedAt: now,
    createdAt: now,
    scenario: {
      openingType: "story",
      publicDescription:
        "Hollowmere keeps a ledger of the drowned who may walk home. You are the night-clerk. One fog, one knock, one name you should not write.",
      prompt:
        "You stand beneath the dripping eaves of Hollowmere's night office, the river loud beyond the fog. The brass key to the Ledger of Returns is cold in your palm. ${What is your name?} — newly sworn clerk of the night watch — you have one duty: record every drowned soul that walks the docks after midnight, and refuse the ones the town cannot afford to remember. A knock sounds at the warped door. Three slow raps. The fog outside is already thick with shapes.",
      plotEssentials:
        "The player is ${What is your name?}, night-clerk of Hollowmere. Hollowmere is a fog-bound river town where the drowned sometimes walk again between midnight and dawn. The Ledger of Returns records who may come home; the clerk's word is law until sunrise. The river is called the Wending. Watch-captain Maud Vesper is the player's superior. Speaking a name written in the Ledger can call that soul. The town survives by forgetting as much as it remembers.",
      authorsNote:
        "Gothic riverside mystery. Second person, present tense, sensory and restrained. Treat the supernatural as bureaucratic and intimate, not spectacular. Short paragraphs. Keep NPC voices distinct. Do not resolve the central mystery in the first scene.",
      aiInstructions:
        "Stay in second person. Do not speak for the player's choices. When a drowned soul appears, give them a specific unfinished errand. Keep the fog, river, and paperwork present. Avoid gore; prefer cold, wet, quiet dread.",
      storySummary:
        "${What is your name?} has just been sworn as Hollowmere's night-clerk and holds the key to the Ledger of Returns on a night of unusually thick fog.",
      thirdPersonName: "",
      choices: [],
    },
    cards: [
      {
        id: "card-maud",
        title: "Maud Vesper",
        type: "character",
        keys: "Maud Vesper, Maud, the watch-captain, captain",
        value:
          "Maud Vesper is Hollowmere's watch-captain, a broad, grey-eyed woman who smells of pipe smoke and wet wool. She speaks in short orders and never uses the player's first name. She believes the Ledger keeps the town alive and will not tolerate pity for the unrecorded drowned. She once struck a name from the book and has not slept well since. She is loyal to Hollowmere, not to mercy.",
        description: "Stern watch-captain who treats the Ledger as law.",
        useForCharacterCreation: false,
        scenarioSpecific: false,
        locked: true,
        includeInExport: true,
        libraryId: "lib-maud",
        npc: {
          aliases: "Maud, the watch-captain, captain",
          role: "Hollowmere's watch-captain and the player's superior",
          appearance: "Broad, grey-eyed, salt-and-iron hair, smells of pipe smoke and wet wool",
          personality: "Short-tempered, exacting, unsentimental, privately haunted",
          speech: "in clipped orders; never uses first names",
          motivations: "Keep Hollowmere from drowning in its own dead",
          relationships: "Commands the night-clerk; distrusts the Drowned Parish",
          secrets: "Once struck a name from the Ledger and has not slept well since",
          abilities: "Knows every alley, tide mark, and unpaid debt in town",
          quirks: "Taps her pipe twice before delivering bad news",
        },
      },
      ...DEMO_NESTED_CARDS.map((c) => ({ ...c })),
      {
        id: "card-wending",
        title: "The Wending",
        type: "location",
        keys: "the Wending, Wending, the river, river",
        value:
          "The Wending is the wide, slow river that feeds Hollowmere. Its water is the color of steeped tea and carries voices on foggy nights. Bodies that go in without rites sometimes walk back out between midnight and dawn. Barges refuse to moor after last bell. The current remembers names better than the town does.",
        description: "The river that returns the drowned.",
        useForCharacterCreation: false,
        scenarioSpecific: true,
        locked: false,
        includeInExport: true,
      },
      {
        id: "card-ledger",
        title: "Ledger of Returns",
        type: "item",
        keys: "Ledger of Returns, the Ledger, ledger, brass key",
        value:
          "The Ledger of Returns is a water-stained bound book kept in the night office. Names written in it may walk Hollowmere until dawn; names refused stay in the fog. The clerk writes in iron-gall ink. Crossing out a name is considered a kind of killing. The brass key opens the desk; the book itself has no lock.",
        description: "The book that decides who may come home.",
        useForCharacterCreation: false,
        scenarioSpecific: true,
        locked: false,
        includeInExport: true,
      },
      {
        id: "card-parish",
        title: "The Drowned Parish",
        type: "faction",
        keys: "Drowned Parish, the Parish, parish, the drowned",
        value:
          "The Drowned Parish is a quiet fellowship of Hollowmere folk who leave candles on the docks and argue that every returned soul deserves a line in the Ledger. They meet in the old boat-chapel. Their speaker is Ivo Cane, a net-mender with river-black fingernails. They are not a cult in their own minds. Maud considers them a civic risk.",
        description: "A fellowship that wants every drowned soul recorded.",
        useForCharacterCreation: false,
        scenarioSpecific: true,
        locked: false,
        includeInExport: true,
      },
      {
        id: "card-town",
        title: "Hollowmere",
        type: "location",
        keys: "Hollowmere, the town, night office, docks",
        value:
          "Hollowmere is a fog-bound river town of wet brick, hanging nets, and a single clock that runs five minutes slow. The night office sits on stilts above the docks. People speak softly after last bell. Everyone has a relative in the river. The town's prosperity depends on barges that will not wait for ghosts.",
        description: "A fog-bound river town that bargains with its dead.",
        useForCharacterCreation: true,
        scenarioSpecific: true,
        locked: true,
        includeInExport: true,
      },
    ],
    covers: [],
    coverDraft: emptyCoverDraft(),
    brainstorm: {
      idea:
        "In a river town where the drowned return with the fog, a newly sworn night-clerk must keep the ledger of the dead — and decide which names are allowed to come home.",
      ideaLocked: true,
      notes:
        "Possible twist: the knock is not a drowned soul — it is someone living who wants a name struck out before dawn.",
      items: [
        {
          id: "idea-1",
          text: "The Ledger is both law and a kind of killing. Crossing out a name is murder by paperwork.",
          status: "locked",
          createdAt: now - 7200000,
        },
        {
          id: "idea-2",
          text: "What if Maud is the one knocking, with a name already written?",
          status: "open",
          createdAt: now - 5400000,
        },
      ],
      questions: [
        {
          id: "q-1",
          question: "Whose name did Maud strike from the Ledger — and why hasn't she slept?",
          notes: "",
          resolved: false,
          createdAt: now - 5000000,
        },
        {
          id: "q-2",
          question: "Does the player know they can refuse a name, or is that learned the hard way?",
          notes: "Probably learned in the first scene.",
          resolved: true,
          createdAt: now - 4800000,
        },
      ],
      messages: [
        {
          id: "m1",
          role: "user",
          content: "Give me three opening knocks that aren't just a generic ghost.",
          createdAt: now - 3600000,
        },
        {
          id: "m2",
          role: "assistant",
          content:
            "1. A child who is still dripping, asking whether the clerk has seen her living brother — she does not know she is the one who drowned.\n2. Maud herself, earlier than expected, with a name already written on a scrap of paper and a look that says do not ask.\n3. A barge-captain who is very much alive, offering a bribe to keep his drowned creditor out of the Ledger until the tide turns.",
          createdAt: now - 3500000,
        },
      ],
    },
  };
}

export function demoNpcFields() {
  return emptyNpc();
}
