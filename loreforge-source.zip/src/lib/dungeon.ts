import { exportableCards, toAidStoryCards } from "./aid";
import type { LibraryElement, LibraryNpc, Project, StoryCard } from "./types";

const DUNGEON_TYPES: Record<string, string> = {
  character: "character",
  location: "location",
  race: "race",
  item: "item",
  faction: "faction",
  class: "race",
  creature: "character",
  other: "event",
};

export type DungeonStoryCard = {
  id: string;
  name: string;
  triggers: string;
  type: string;
  icons: string[];
  iconIndex: number;
  graphics: string[];
  graphicIndex: number;
  useCustomColor: boolean;
  color: string;
  limit: string;
  preset: string;
  audioClips: string[];
};

export type DungeonAdventureFile = {
  version: 1;
  exportedAt: number;
  adventure: {
    id: string;
    name: string;
    createdAt: number;
    storyCards: Record<string, DungeonStoryCard>;
  };
  aid: {
    title: string;
    publicDescription: string;
    prompt: string;
    plotEssentials: string;
    authorsNote: string;
    aiInstructions: string;
    storySummary: string;
    thirdPersonName: string;
    openingType: string;
    storyCards: ReturnType<typeof toAidStoryCards>;
  };
};

function toDungeonCard(card: StoryCard): DungeonStoryCard {
  const art = card.portraitDataUrl ? [card.portraitDataUrl] : [];
  return {
    id: card.id,
    name: card.title,
    triggers: card.keys,
    type: DUNGEON_TYPES[card.type] ?? "event",
    icons: art,
    iconIndex: 0,
    graphics: art,
    graphicIndex: 0,
    useCustomColor: false,
    color: "#f8ae2c",
    limit: "none",
    preset: "default",
    audioClips: [],
  };
}

export function toDungeonAdventure(project: Project): DungeonAdventureFile {
  const included = exportableCards(project.cards);
  const storyCards: Record<string, DungeonStoryCard> = {};
  for (const card of included) {
    storyCards[card.id] = toDungeonCard(card);
  }
  return {
    version: 1,
    exportedAt: Date.now(),
    adventure: {
      id: project.id,
      name: project.title,
      createdAt: project.createdAt,
      storyCards,
    },
    aid: {
      title: project.title,
      publicDescription: project.scenario.publicDescription,
      prompt: project.scenario.prompt,
      plotEssentials: project.scenario.plotEssentials,
      authorsNote: project.scenario.authorsNote,
      aiInstructions: project.scenario.aiInstructions,
      storySummary: project.scenario.storySummary,
      thirdPersonName: project.scenario.thirdPersonName,
      openingType: project.scenario.openingType,
      storyCards: toAidStoryCards(included),
    },
  };
}

export function toAidNpcCards(npcs: LibraryNpc[]) {
  return npcs.map((n) => ({
    keys: n.keys,
    value: n.value,
    type: "character",
    title: n.title,
    description: n.description,
    useForCharacterCreation: false,
  }));
}

export function toNpcExport(npcs: LibraryNpc[]) {
  return {
    format: "loreforge-npc-library",
    version: 1,
    exportedAt: Date.now(),
    aidStoryCards: toAidNpcCards(npcs),
    npcs: npcs.map((n) => ({
      id: n.id,
      title: n.title,
      keys: n.keys,
      value: n.value,
      description: n.description,
      npc: n.npc,
      portraitDataUrl: n.portraitDataUrl ?? "",
      parentId: n.parentId,
      nestRole: n.nestRole,
    })),
  };
}

export function toElementExport(elements: LibraryElement[]) {
  return {
    format: "loreforge-element-library",
    version: 1,
    exportedAt: Date.now(),
    aidStoryCards: elements.map((e) => ({
      keys: e.keys,
      value: e.value,
      type: e.type === "other" ? "" : e.type,
      title: e.title,
      description: e.description,
      useForCharacterCreation: e.useForCharacterCreation,
    })),
    elements,
  };
}

export function cardToLibraryNpc(card: StoryCard): Omit<LibraryNpc, "id" | "selected" | "createdAt"> {
  return {
    title: card.title,
    keys: card.keys,
    value: card.value,
    description: card.description,
    npc: card.npc ?? {
      aliases: "",
      role: "",
      appearance: "",
      personality: "",
      speech: "",
      motivations: "",
      relationships: "",
      secrets: "",
      abilities: "",
      quirks: "",
    },
    portraitDataUrl: card.portraitDataUrl,
    parentId: card.parentId,
    nestRole: card.nestRole,
  };
}

export function cardToLibraryElement(
  card: StoryCard,
): Omit<LibraryElement, "id" | "selected" | "createdAt"> {
  return {
    title: card.title,
    type: card.type,
    keys: card.keys,
    value: card.value,
    description: card.description,
    useForCharacterCreation: card.useForCharacterCreation,
  };
}
