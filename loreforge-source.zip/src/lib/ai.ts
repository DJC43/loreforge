import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const MODEL = "grok-4.5";
const IMAGE_MODEL = "grok-imagine-image";

type ChatMsg = { role: "system" | "user" | "assistant"; content: string };

export type AidCardPayload = {
  title: string;
  type: string;
  keys: string;
  value: string;
  description: string;
  useForCharacterCreation: boolean;
  npc?: {
    aliases: string;
    role: string;
    appearance: string;
    personality: string;
    speech: string;
    motivations: string;
    relationships: string;
    secrets: string;
    abilities: string;
    quirks: string;
  };
};

export type ForgePayload = {
  title: string;
  logline: string;
  genre: string;
  genres: string[];
  tone: string;
  tones: string[];
  tags: string[];
  publicDescription: string;
  prompt: string;
  plotEssentials: string;
  authorsNote: string;
  aiInstructions: string;
  storySummary: string;
  choices: Array<{ label: string; prompt: string }>;
  cards: AidCardPayload[];
};

function extractJson(text: string): unknown {
  const trimmed = text.trim();
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/);
  const raw = fenced?.[1]?.trim() ?? trimmed;
  const start = raw.search(/[{[]/);
  if (start === -1) throw new Error("No JSON in model response");
  return JSON.parse(raw.slice(start));
}

function asRecord(v: unknown): Record<string, unknown> {
  if (!v || typeof v !== "object" || Array.isArray(v)) return {};
  return v as Record<string, unknown>;
}

function str(v: unknown, fallback = "") {
  return typeof v === "string" ? v : fallback;
}

function strArr(v: unknown): string[] {
  if (Array.isArray(v)) return v.filter((t): t is string => typeof t === "string");
  if (typeof v === "string" && v.trim()) return [v];
  return [];
}

function friendlyApiError(status: number, body: string, kind: "text" | "image") {
  const lower = body.toLowerCase();
  if (
    status === 402 ||
    /credit|quota|billing|insufficient|balance|payment required/.test(lower)
  ) {
    return kind === "image"
      ? "No Grok credits left for images. Upload a portrait instead, or add credits in Grok → Settings → Usage."
      : "No Grok credits left. You can still write by hand. Add credits in Grok → Settings → Usage, or wait for the weekly reset.";
  }
  if (status === 429) return "Grok is busy (rate limit). Wait a moment and try again.";
  const snippet = body.replace(/\s+/g, " ").trim().slice(0, 160);
  return `xAI API error ${status}${snippet ? `: ${snippet}` : ""}`;
}

function parseNpc(v: unknown): AidCardPayload["npc"] {
  const o = asRecord(v);
  return {
    aliases: str(o.aliases),
    role: str(o.role),
    appearance: str(o.appearance),
    personality: str(o.personality),
    speech: str(o.speech),
    motivations: str(o.motivations),
    relationships: str(o.relationships),
    secrets: str(o.secrets),
    abilities: str(o.abilities),
    quirks: str(o.quirks),
  };
}

function parseCard(v: unknown): AidCardPayload {
  const o = asRecord(v);
  return {
    title: str(o.title, "Untitled"),
    type: str(o.type, "other"),
    keys: str(o.keys),
    value: str(o.value),
    description: str(o.description),
    useForCharacterCreation: Boolean(o.useForCharacterCreation),
    npc: o.npc ? parseNpc(o.npc) : undefined,
  };
}

function parseForge(v: unknown): ForgePayload {
  const o = asRecord(v);
  const cards = Array.isArray(o.cards) ? o.cards.map(parseCard) : [];
  const genres = strArr(o.genres).length ? strArr(o.genres) : strArr(o.genre);
  const tones = strArr(o.tones).length ? strArr(o.tones) : strArr(o.tone);
  const choices = Array.isArray(o.choices)
    ? o.choices.map((c) => {
        const r = asRecord(c);
        return { label: str(r.label, "Opening"), prompt: str(r.prompt) };
      })
    : [];
  return {
    title: str(o.title),
    logline: str(o.logline),
    genre: genres[0] ?? str(o.genre),
    genres,
    tone: tones[0] ?? str(o.tone),
    tones,
    tags: strArr(o.tags),
    publicDescription: str(o.publicDescription),
    prompt: str(o.prompt),
    plotEssentials: str(o.plotEssentials),
    authorsNote: str(o.authorsNote),
    aiInstructions: str(o.aiInstructions),
    storySummary: str(o.storySummary),
    choices,
    cards,
  };
}

async function chat(
  messages: ChatMsg[],
  maxTokens: number,
): Promise<{ ok: true; text: string } | { ok: false; error: string }> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false, error: "AI is not available in this environment" };

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 60000);
  try {
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      signal: ctrl.signal,
      body: JSON.stringify({
        model: MODEL,
        messages,
        max_tokens: maxTokens,
        temperature: 0.9,
      }),
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      return { ok: false, error: friendlyApiError(res.status, body, "text") };
    }
    const json = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    return { ok: true, text: json.choices?.[0]?.message?.content ?? "" };
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Request failed";
    return { ok: false, error: msg };
  } finally {
    clearTimeout(timer);
  }
}

const AID_WRITER = `You are Loreforge, a specialist editor for AI Dungeon creators.
Write in the AI Dungeon house style:
- Starting prompts: second person, present tense, hook in the first sentence, end on a decision or interruption. Placeholders use \${Question} syntax (example: \${What is your name?}).
- Plot essentials: always-true facts the model must never forget. Plain prose. Include the player identity if known. No empty lines.
- Author's note: 1–4 short sentences on genre, tense, tone, and what to avoid. Not lore.
- AI instructions: behavioral constraints (POV, don't speak for the player, content limits).
- Public description: 1–3 sentences for the scenario listing. Sell the hook, no spoilers of the twist.
- Story card entries: the AI sees the Entry, not the Title. Lead with the subject's name. Brief natural English. No blank lines. Put the most important fact first. Triggers are comma-separated names and aliases.
- Character creator openings: the starting prompt is the scene before the player picks class/race/location/faction. Do not pre-assign those. Mark class, race, location, and faction cards with useForCharacterCreation true.
- Multiple choice openings: several distinct playable starts, each with a short label and a full second-person prompt.
- Do not wrap entries in square brackets unless the user asks.
- Stay within ~800 characters per story card entry.
- Do not generate sexual content involving minors.`;

const forgeSchema = z.object({
  idea: z.string().min(1).max(4000),
  extra: z.string().max(4000).optional(),
});

export const forgeFromIdea = createServerFn({ method: "POST" })
  .validator((input: unknown) => forgeSchema.parse(input))
  .handler(async ({ data }) => {
    const result = await chat(
      [
        { role: "system", content: AID_WRITER },
        {
          role: "user",
          content: `Forge a complete AI Dungeon scenario starter from this idea.

Idea:
${data.idea}
${data.extra ? `\nAdditional direction:\n${data.extra}` : ""}

Return ONLY a JSON object with this shape:
{
  "title": string,
  "logline": string,
  "genres": string[],
  "tones": string[],
  "tags": string[],
  "publicDescription": string,
  "prompt": string,
  "plotEssentials": string,
  "authorsNote": string,
  "aiInstructions": string,
  "storySummary": string,
  "cards": [
    {
      "title": string,
      "type": "character" | "location" | "faction" | "item" | "creature" | "class" | "race" | "other",
      "keys": string,
      "value": string,
      "description": string,
      "useForCharacterCreation": boolean
    }
  ]
}
Create 5–8 story cards covering at least one character, one location, one faction or institution, and one item or rule of the world.
Include \${What is your name?} in the prompt and plot essentials.
Genres and tones may contain more than one value.`,
        },
      ],
      3500,
    );
    if (!result.ok) return result;
    try {
      return { ok: true as const, data: parseForge(extractJson(result.text)) };
    } catch {
      return { ok: false as const, error: "The model returned unreadable JSON. Try again." };
    }
  });

const rewriteSchema = z.object({
  field: z.string().max(64),
  instruction: z.string().min(1).max(2000),
  text: z.string().max(12000),
  context: z.string().max(8000).optional(),
});

export const rewriteField = createServerFn({ method: "POST" })
  .validator((input: unknown) => rewriteSchema.parse(input))
  .handler(async ({ data }) => {
    const result = await chat(
      [
        { role: "system", content: AID_WRITER },
        {
          role: "user",
          content: `Rewrite the AI Dungeon field "${data.field}".
Instruction: ${data.instruction}
${data.context ? `\nProject context:\n${data.context}` : ""}

Current text:
${data.text || "(empty — invent a strong first draft)"}

Return ONLY the rewritten field text. No JSON, no markdown fences, no preamble.`,
        },
      ],
      1200,
    );
    if (!result.ok) return result;
    return { ok: true as const, text: result.text.trim() };
  });

const npcSchema = z.object({
  brief: z.string().min(1).max(4000),
  context: z.string().max(8000).optional(),
});

export const generateNpc = createServerFn({ method: "POST" })
  .validator((input: unknown) => npcSchema.parse(input))
  .handler(async ({ data }) => {
    const result = await chat(
      [
        { role: "system", content: AID_WRITER },
        {
          role: "user",
          content: `Create one AI Dungeon NPC story card.

Brief:
${data.brief}
${data.context ? `\nWorld context:\n${data.context}` : ""}

Return ONLY JSON:
{
  "title": string,
  "type": "character",
  "keys": string,
  "value": string,
  "description": string,
  "useForCharacterCreation": false,
  "npc": {
    "aliases": string,
    "role": string,
    "appearance": string,
    "personality": string,
    "speech": string,
    "motivations": string,
    "relationships": string,
    "secrets": string,
    "abilities": string,
    "quirks": string
  }
}
The value must be a single dense paragraph starting with the name. Keep it under 800 characters.`,
        },
      ],
      1400,
    );
    if (!result.ok) return result;
    try {
      return { ok: true as const, data: parseCard(extractJson(result.text)) };
    } catch {
      return { ok: false as const, error: "The model returned unreadable JSON. Try again." };
    }
  });

const cardsSchema = z.object({
  context: z.string().min(1).max(10000),
  focus: z.string().max(2000).optional(),
  typeHint: z.string().max(40).optional(),
});

export const generateCardBatch = createServerFn({ method: "POST" })
  .validator((input: unknown) => cardsSchema.parse(input))
  .handler(async ({ data }) => {
    const typeLine = data.typeHint
      ? `Prefer type "${data.typeHint}". All cards should be this type unless the brief clearly requires otherwise.`
      : "Mix types.";
    const result = await chat(
      [
        { role: "system", content: AID_WRITER },
        {
          role: "user",
          content: `Propose 5 AI Dungeon story cards for this scenario.

${data.context}
${data.focus ? `\nFocus:\n${data.focus}` : ""}
${typeLine}

Return ONLY JSON: { "cards": [ { "title", "type", "keys", "value", "description", "useForCharacterCreation" } ] }
Each value is one dense paragraph under 800 characters, name first.`,
        },
      ],
      2500,
    );
    if (!result.ok) return result;
    try {
      const parsed = asRecord(extractJson(result.text));
      const list = Array.isArray(parsed.cards) ? parsed.cards : Array.isArray(parsed) ? (parsed as unknown[]) : [];
      return { ok: true as const, cards: list.map(parseCard) };
    } catch {
      return { ok: false as const, error: "The model returned unreadable JSON. Try again." };
    }
  });

const chatSchema = z.object({
  context: z.string().max(10000),
  history: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().max(8000),
      }),
    )
    .max(16),
  message: z.string().min(1).max(4000),
});

export const brainstormChat = createServerFn({ method: "POST" })
  .validator((input: unknown) => chatSchema.parse(input))
  .handler(async ({ data }) => {
    const result = await chat(
      [
        {
          role: "system",
          content: `${AID_WRITER}

You are brainstorming with the creator. Be concrete: names, sensory details, playable hooks, card-ready copy. Offer 2–4 options when asked to ideate. If the user wants copy they can paste into AI Dungeon, format it ready to paste. Keep replies under 350 words unless they ask for a full draft. Help them lock a core idea and surface open questions.

Project context:
${data.context || "(empty project)"}`,
        },
        ...data.history.slice(-12),
        { role: "user", content: data.message },
      ],
      1200,
    );
    if (!result.ok) return result;
    return { ok: true as const, text: result.text.trim() };
  });

const harvestSchema = z.object({
  idea: z.string().max(4000),
  context: z.string().max(10000),
  transcript: z.string().max(12000).optional(),
});

export const harvestBrainstorm = createServerFn({ method: "POST" })
  .validator((input: unknown) => harvestSchema.parse(input))
  .handler(async ({ data }) => {
    const result = await chat(
      [
        { role: "system", content: AID_WRITER },
        {
          role: "user",
          content: `Harvest a brainstorming studio from this core idea. Tighten the idea into a lockable logline, suggest a title, list supporting ideas to pin, and list open questions the creator should still answer.

Core idea:
${data.idea || "(none)"}

Project context:
${data.context}

${data.transcript ? `Recent brainstorm:\n${data.transcript}` : ""}

Return ONLY JSON:
{
  "title": string,
  "idea": string,
  "logline": string,
  "genres": string[],
  "tones": string[],
  "tags": string[],
  "ideas": string[],
  "questions": string[]
}
ideas: 4–8 concrete lockable thoughts (hooks, motifs, NPCs, twists) — short sentences.
questions: 4–7 genuine open questions, not rhetorical.`,
        },
      ],
      1600,
    );
    if (!result.ok) return result;
    try {
      const o = asRecord(extractJson(result.text));
      return {
        ok: true as const,
        data: {
          title: str(o.title),
          idea: str(o.idea),
          logline: str(o.logline),
          genres: strArr(o.genres),
          tones: strArr(o.tones),
          tags: strArr(o.tags),
          ideas: strArr(o.ideas),
          questions: strArr(o.questions),
        },
      };
    } catch {
      return { ok: false as const, error: "The model returned unreadable JSON. Try again." };
    }
  });

const blanksSchema = z.object({
  context: z.string().min(1).max(12000),
  openingType: z.enum(["story", "characterCreator", "multipleChoice"]),
  emptyFields: z.array(z.string()).max(20),
});

export const fillScenarioBlanks = createServerFn({ method: "POST" })
  .validator((input: unknown) => blanksSchema.parse(input))
  .handler(async ({ data }) => {
    const result = await chat(
      [
        { role: "system", content: AID_WRITER },
        {
          role: "user",
          content: `Fill ONLY these empty AI Dungeon plot fields: ${data.emptyFields.join(", ") || "all standard fields"}.
Opening type: ${data.openingType}

Project context:
${data.context}

Rules:
- story: write a single starting prompt.
- characterCreator: starting prompt is the scene before the player picks origin options. Also propose 4–6 class/race/location/faction cards with useForCharacterCreation true if cards are requested.
- multipleChoice: include 3 distinct choices {label, prompt}. Prompt may be a short shared preamble.

Return ONLY JSON with whichever of these you filled:
{
  "publicDescription"?: string,
  "prompt"?: string,
  "plotEssentials"?: string,
  "authorsNote"?: string,
  "aiInstructions"?: string,
  "storySummary"?: string,
  "choices"?: [{ "label": string, "prompt": string }],
  "cards"?: [ { "title", "type", "keys", "value", "description", "useForCharacterCreation" } ]
}
Do not return fields the user did not ask to fill, except cards when openingType is characterCreator and emptyFields includes cards.`,
        },
      ],
      2800,
    );
    if (!result.ok) return result;
    try {
      return { ok: true as const, data: parseForge(extractJson(result.text)) };
    } catch {
      return { ok: false as const, error: "The model returned unreadable JSON. Try again." };
    }
  });

const coverFieldsSchema = z.object({
  context: z.string().max(8000),
  fields: z.array(z.enum(["subject", "lighting", "composition", "mood", "extra"])).min(1).max(5),
  current: z.object({
    subject: z.string().max(800),
    lighting: z.string().max(800),
    composition: z.string().max(800),
    mood: z.string().max(800),
    extra: z.string().max(800),
  }),
  mediums: z.string().max(600),
});

export const fillCoverFields = createServerFn({ method: "POST" })
  .validator((input: unknown) => coverFieldsSchema.parse(input))
  .handler(async ({ data }) => {
    const result = await chat(
      [
        {
          role: "system",
          content:
            "You write visual-only cover-art direction. No letters, titles, watermarks, or artist names. Short phrases, concrete and cinematic.",
        },
        {
          role: "user",
          content: `Fill these cover fields: ${data.fields.join(", ")}.
Medium blend: ${data.mediums}
Project:
${data.context}

Current:
${JSON.stringify(data.current, null, 2)}

Return ONLY JSON with those field keys as short visual phrases.`,
        },
      ],
      700,
    );
    if (!result.ok) return result;
    try {
      const o = asRecord(extractJson(result.text));
      const out: Record<string, string> = {};
      for (const f of data.fields) {
        if (str(o[f])) out[f] = str(o[f]);
      }
      return { ok: true as const, data: out };
    } catch {
      return { ok: false as const, error: "The model returned unreadable JSON. Try again." };
    }
  });

const coverSchema = z.object({
  prompt: z.string().min(1).max(2500),
  aspect: z.enum(["16:9", "1:1", "4:3", "9:16"]),
});

export const generateCover = createServerFn({ method: "POST" })
  .validator((input: unknown) => coverSchema.parse(input))
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "AI is not available in this environment" };

    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 90000);
    try {
      const res = await fetch("https://api.x.ai/v1/images/generations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        signal: ctrl.signal,
        body: JSON.stringify({
          model: IMAGE_MODEL,
          prompt: data.prompt,
          n: 1,
          aspect_ratio: data.aspect,
          resolution: "1k",
        }),
      });
      if (!res.ok) {
        const body = await res.text().catch(() => "");
        return {
          ok: false as const,
          error: friendlyApiError(res.status, body, "image"),
        };
      }
      const json = (await res.json()) as {
        data?: { url?: string; b64_json?: string }[];
      };
      const first = json.data?.[0];
      if (first?.b64_json) {
        return { ok: true as const, dataUrl: `data:image/jpeg;base64,${first.b64_json}` };
      }
      if (first?.url) {
        const img = await fetch(first.url);
        if (!img.ok) return { ok: false as const, error: "Could not download generated image" };
        const buf = Buffer.from(await img.arrayBuffer());
        const mime = img.headers.get("content-type") || "image/jpeg";
        return { ok: true as const, dataUrl: `data:${mime};base64,${buf.toString("base64")}` };
      }
      return { ok: false as const, error: "Image API returned no image" };
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Image request failed";
      return { ok: false as const, error: msg };
    } finally {
      clearTimeout(timer);
    }
  });

const coverPromptSchema = z.object({
  title: z.string().max(200),
  logline: z.string().max(800),
  genre: z.string().max(200),
  style: z.string().max(800),
});

export const writeCoverPrompt = createServerFn({ method: "POST" })
  .validator((input: unknown) => coverPromptSchema.parse(input))
  .handler(async ({ data }) => {
    const result = await chat(
      [
        {
          role: "system",
          content:
            "You write image prompts for AI Dungeon scenario covers. One paragraph, visual only. No quoted text, no letters, no title treatment, no watermark, no artist's name. Center the subject for square cropping. Mention lighting, mood, medium, and composition.",
        },
        {
          role: "user",
          content: `Title: ${data.title}
Logline: ${data.logline}
Genre: ${data.genre}
Style: ${data.style}

Return only the image prompt.`,
        },
      ],
      400,
    );
    if (!result.ok) return result;
    return { ok: true as const, text: result.text.trim().replace(/^"|"$/g, "") };
  });
