/** Tall 9:16 JPEG data URL for NPC portraits. Caps payload so localStorage stays usable. */

export const PORTRAIT_ASPECT = "9:16" as const;
const WIDTH = 576;
const HEIGHT = 1024;
const MAX_BYTES = 8 * 1024 * 1024;

export function fileToPortraitDataUrl(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) {
    return Promise.reject(new Error("Choose an image file."));
  }
  if (file.size > MAX_BYTES) {
    return Promise.reject(new Error("Image is too large (max 8 MB)."));
  }
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = WIDTH;
        canvas.height = HEIGHT;
        const ctx = canvas.getContext("2d");
        if (!ctx) throw new Error("Could not process image.");
        const target = WIDTH / HEIGHT;
        const src = (img.width || 1) / (img.height || 1);
        let sx = 0;
        let sy = 0;
        let sw = img.width;
        let sh = img.height;
        if (src > target) {
          sw = img.height * target;
          sx = (img.width - sw) / 2;
        } else {
          sh = img.width / target;
          sy = Math.max(0, (img.height - sh) * 0.18);
        }
        ctx.fillStyle = "#161412";
        ctx.fillRect(0, 0, WIDTH, HEIGHT);
        ctx.drawImage(img, sx, sy, sw, sh, 0, 0, WIDTH, HEIGHT);
        resolve(canvas.toDataURL("image/jpeg", 0.86));
      } catch (err) {
        reject(err instanceof Error ? err : new Error("Could not process image."));
      } finally {
        URL.revokeObjectURL(url);
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Could not read that image."));
    };
    img.src = url;
  });
}

export function portraitPrompt(name: string, role = "", appearance = "") {
  return [
    `Character portrait of ${name}.`,
    role,
    appearance,
    "Vertical 9:16 phone-portrait crop from mid-thigh to above the head, readable face, dramatic lighting, fully clothed, modest attire, no nudity, no text, no watermark.",
  ]
    .filter(Boolean)
    .join(" ");
}
