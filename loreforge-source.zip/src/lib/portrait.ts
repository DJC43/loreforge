/** Square JPEG data URL for NPC portraits. Caps payload so localStorage stays usable. */

const SIZE = 640;
const MAX_BYTES = 8 * 1024 * 1024;

export function fileToPortraitDataUrl(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) {
    return Promise.reject(new Error("Choose an image file."));
  }
  if (file.size > MAX_BYTES) {
    return Promise.reject(new Error("Image is too large (max 8 MB)."));
  }
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = SIZE;
        canvas.height = SIZE;
        const ctx = canvas.getContext("2d");
        if (!ctx) throw new Error("Could not process image.");
        const side = Math.min(img.width, img.height) || 1;
        const sx = (img.width - side) / 2;
        const sy = (img.height - side) / 2;
        ctx.fillStyle = "#161412";
        ctx.fillRect(0, 0, SIZE, SIZE);
        ctx.drawImage(img, sx, sy, side, side, 0, 0, SIZE, SIZE);
        resolve(canvas.toDataURL("image/jpeg", 0.88));
      } catch (err) {
        reject(err instanceof Error ? err : new Error("Could not process image."));
      } finally {
        URL.revokeObjectURL(url);
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Could not read that image."));
    };
    img.src = url;
  });
}

export function portraitPrompt(name: string, role = "", appearance = "") {
  return [
    `Character portrait of ${name}.`,
    role,
    appearance,
    "Shoulders-up portrait, readable face, dramatic lighting, fully clothed, no text, no watermark, square crop.",
  ]
    .filter(Boolean)
    .join(" ");
}
