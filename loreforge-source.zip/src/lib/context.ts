import type { Project } from "./types";

export function projectContext(project: Project): string {
  const b = project.brainstorm;
  const s = project.scenario;
  const npcs = project.cards.filter((c) => c.type === "character" && !c.parentId);
  const factions = project.cards.filter((c) => c.type === "faction" && !c.parentId);
  const locations = project.cards.filter((c) => c.type === "location" && !c.parentId);
  const other = project.cards.filter(
    (c) => !c.parentId && !["character", "faction", "location"].includes(c.type),
  );
  const nested = project.cards.filter((c) => Boolean(c.parentId));
  const lockedIdeas = b.items.filter((i) => i.status === "locked");
  const openIdeas = b.items.filter((i) => i.status === "open");
  const openQs = b.questions.filter((q) => !q.resolved);
  return [
    `Title: ${project.title}`,
    `Core idea: ${b.idea || project.logline || "(none)"}`,
    b.ideaLocked ? "Idea is locked." : "Idea is still open.",
    `Logline: ${project.logline}`,
    `Genres: ${project.genres.join(", ") || "—"}`,
    `Tones: ${project.tones.join(", ") || "—"}`,
    `Tags: ${project.tags.join(", ") || "—"}`,
    `Rating: ${project.rating}`,
    lockedIdeas.length ? `Locked ideas:\n${lockedIdeas.map((i) => `- ${i.text}`).join("\n")}` : "",
    openIdeas.length ? `Open ideas:\n${openIdeas.map((i) => `- ${i.text}`).join("\n")}` : "",
    openQs.length ? `Open questions:\n${openQs.map((q) => `- ${q.question}`).join("\n")}` : "",
    b.notes ? `Pinned notes: ${b.notes}` : "",
    `Opening type: ${s.openingType}`,
    s.publicDescription ? `Public description: ${s.publicDescription}` : "",
    s.prompt ? `Starting prompt: ${s.prompt}` : "",
    s.plotEssentials ? `Plot essentials: ${s.plotEssentials}` : "",
    s.authorsNote ? `Author's note: ${s.authorsNote}` : "",
    s.aiInstructions ? `AI instructions: ${s.aiInstructions}` : "",
    s.storySummary ? `Story summary: ${s.storySummary}` : "",
    s.choices.length
      ? `Multiple-choice openings:\n${s.choices.map((c) => `- ${c.label}: ${c.prompt}`).join("\n")}`
      : "",
    npcs.length ? `NPCs: ${npcs.map((c) => c.title).join("; ")}` : "NPCs: none",
    factions.length ? `Factions: ${factions.map((c) => c.title).join("; ")}` : "Factions: none",
    locations.length ? `Locations: ${locations.map((c) => c.title).join("; ")}` : "Locations: none",
    other.length ? `Other elements: ${other.map((c) => `${c.title} (${c.type})`).join("; ")}` : "",
    nested.length
      ? `Nested cards:\n${nested
          .map((c) => {
            const parent = project.cards.find((p) => p.id === c.parentId);
            return `- ${c.title} (${c.nestRole || "nested"} under ${parent?.title ?? "unknown"})`;
          })
          .join("\n")}`
      : "",
  ]
    .filter(Boolean)
    .join("\n");
}
