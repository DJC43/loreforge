import { NEST_ROLES } from "./catalog";

const ROLE_ALIASES: Record<string, string> = {
  backstory: "backstory",
  background: "backstory",
  origin: "backstory",
  history: "history",
  past: "history",
  motivation: "motivation",
  motivations: "motivation",
  desire: "desires",
  desires: "desires",
  kink: "desires",
  kinks: "desires",
  preference: "desires",
  preferences: "desires",
  secret: "secret",
  secrets: "secret",
  relationship: "relationship",
  relationships: "relationship",
  note: "note",
  notes: "note",
  talent: "note",
  talents: "note",
};

function normalizeTitle(title: string) {
  return title.trim().toLowerCase().replace(/\s+/g, " ");
}

function remainderAfterPrefix(title: string, parentTitle: string) {
  const t = title.trim();
  const p = parentTitle.trim();
  const nt = normalizeTitle(t);
  const np = normalizeTitle(p);
  if (!p || nt.length <= np.length || !nt.startsWith(np)) return "";
  const rest = t.slice(p.length).replace(/^[\s\-–—:,|/]+/, "").trim();
  return rest;
}

export function guessNestRole(rest: string): string | undefined {
  const raw = rest
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!raw) return undefined;
  if (ROLE_ALIASES[raw]) return ROLE_ALIASES[raw];
  for (const role of NEST_ROLES) {
    const label = role.label.toLowerCase();
    if (raw === role.id || raw === label) return role.id;
    if (raw.startsWith(`${label} `) || raw.startsWith(`${role.id} `)) return role.id;
  }
  const first = raw.split(" ")[0] ?? "";
  return ROLE_ALIASES[first];
}

function wouldCycle<T extends { id: string; parentId?: string }>(
  items: T[],
  childId: string,
  parentId: string,
) {
  const byId = new Map(items.map((i) => [i.id, i]));
  let cur: T | undefined = byId.get(parentId);
  const seen = new Set<string>();
  while (cur) {
    if (cur.id === childId) return true;
    if (seen.has(cur.id)) return true;
    seen.add(cur.id);
    cur = cur.parentId ? byId.get(cur.parentId) : undefined;
  }
  return false;
}

/** Nest "Ava Quinn Backstory" under "Ava Quinn" when the leftover matches a nest role. */
export function inferNestedLinks<T extends { id: string; title: string; parentId?: string; nestRole?: string }>(
  items: T[],
): T[] {
  const byId = new Map(items.map((i) => [i.id, i]));
  return items.map((item) => {
    if (item.parentId && byId.has(item.parentId) && !wouldCycle(items, item.id, item.parentId)) {
      return item;
    }
    let best: { parent: T; rest: string } | null = null;
    for (const other of items) {
      if (other.id === item.id) continue;
      const rest = remainderAfterPrefix(item.title, other.title);
      if (!rest || !guessNestRole(rest)) continue;
      if (!best || other.title.trim().length > best.parent.title.trim().length) {
        best = { parent: other, rest };
      }
    }
    if (!best || wouldCycle(items, item.id, best.parent.id)) {
      return item.parentId && !byId.has(item.parentId) ? { ...item, parentId: undefined } : item;
    }
    return {
      ...item,
      parentId: best.parent.id,
      nestRole: item.nestRole || guessNestRole(best.rest),
    };
  });
}

export function descendantIds<T extends { id: string; parentId?: string }>(items: T[], rootId: string) {
  const drop = new Set<string>([rootId]);
  let grew = true;
  while (grew) {
    grew = false;
    for (const c of items) {
      if (c.parentId && drop.has(c.parentId) && !drop.has(c.id)) {
        drop.add(c.id);
        grew = true;
      }
    }
  }
  return drop;
}

export function nestTreeRows<T extends { id: string; parentId?: string }>(items: T[]) {
  const ids = new Set(items.map((i) => i.id));
  const roots = items.filter((c) => !c.parentId || !ids.has(c.parentId));
  const rows: { item: T; depth: number; childCount: number }[] = [];
  const childCount = (id: string) => items.filter((c) => c.parentId === id).length;
  const walk = (node: T, depth: number) => {
    rows.push({ item: node, depth, childCount: childCount(node.id) });
    for (const c of items) {
      if (c.parentId === node.id) walk(c, depth + 1);
    }
  };
  for (const r of roots) walk(r, 0);
  return rows;
}
