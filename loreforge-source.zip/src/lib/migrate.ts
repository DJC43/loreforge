import {
  emptyBrainstorm,
  emptyCoverDraft,
  emptyNpc,
  emptyProject,
  emptyScenario,
  type BrainstormState,
  type CardType,
  type CoverArt,
  type CoverDraft,
  type LibraryElement,
  type LibraryNpc,
  type Project,
  type StoryCard,
} from "./types";
import { CARD_TYPES } from "./types";
import { DEFAULT_MEDIUMS } from "./catalog";

function asRecord(v: unknown): Record<string, unknown> {
  if (!v || typeof v !== "object" || Array.isArray(v)) return {};
  return v as Record<string, unknown>;
}

function str(v: unknown, fallback = "") {
  return typeof v === "string" ? v : fallback;
}

function num(v: unknown, fallback = 0) {
  return typeof v === "number" && Number.isFinite(v) ? v : fallback;
}

function bool(v: unknown, fallback = false) {
  return typeof v === "boolean" ? v : fallback;
}

function strArr(v: unknown): string[] {
  if (Array.isArray(v)) return v.filter((x): x is string => typeof x === "string" && x.trim().length > 0);
  if (typeof v === "string" && v.trim()) return [v.trim()];
  return [];
}

function asCardType(v: unknown): CardType {
  const s = str(v, "other");
  return (CARD_TYPES as readonly string[]).includes(s) ? (s as CardType) : "other";
}

export function normalizeCard(raw: unknown): StoryCard {
  const o = asRecord(raw);
  const type = asCardType(o.type);
  const npcRaw = o.npc ? asRecord(o.npc) : null;
  return {
    id: str(o.id, crypto.randomUUID()),
    title: str(o.title, "Untitled card"),
    type,
    keys: str(o.keys),
    value: str(o.value),
    description: str(o.description),
    useForCharacterCreation: bool(o.useForCharacterCreation),
    scenarioSpecific: o.scenarioSpecific === undefined ? true : bool(o.scenarioSpecific, true),
    locked: bool(o.locked),
    includeInExport: o.includeInExport === false ? false : true,
    portraitDataUrl: str(o.portraitDataUrl) || undefined,
    libraryId: str(o.libraryId) || undefined,
    parentId: str(o.parentId) || undefined,
    nestRole: str(o.nestRole) || undefined,
    npc:
      type === "character"
        ? {
            ...emptyNpc(),
            ...(npcRaw
              ? {
                  aliases: str(npcRaw.aliases),
                  role: str(npcRaw.role),
                  appearance: str(npcRaw.appearance),
                  personality: str(npcRaw.personality),
                  speech: str(npcRaw.speech),
                  motivations: str(npcRaw.motivations),
                  relationships: str(npcRaw.relationships),
                  secrets: str(npcRaw.secrets),
                  abilities: str(npcRaw.abilities),
                  quirks: str(npcRaw.quirks),
                }
              : {}),
          }
        : npcRaw
          ? {
              aliases: str(npcRaw.aliases),
              role: str(npcRaw.role),
              appearance: str(npcRaw.appearance),
              personality: str(npcRaw.personality),
              speech: str(npcRaw.speech),
              motivations: str(npcRaw.motivations),
              relationships: str(npcRaw.relationships),
              secrets: str(npcRaw.secrets),
              abilities: str(npcRaw.abilities),
              quirks: str(npcRaw.quirks),
            }
          : undefined,
  };
}

function normalizeBrainstorm(raw: unknown, logline = ""): BrainstormState {
  const o = asRecord(raw);
  const base = emptyBrainstorm(str(o.idea, logline));
  const items = Array.isArray(o.items)
    ? o.items.map((it) => {
        const r = asRecord(it);
        const status = str(r.status, "open");
        return {
          id: str(r.id, crypto.randomUUID()),
          text: str(r.text),
          status: (status === "locked" || status === "resolved" ? status : "open") as BrainstormState["items"][number]["status"],
          createdAt: num(r.createdAt, Date.now()),
        };
      })
    : [];
  const questions = Array.isArray(o.questions)
    ? o.questions.map((q) => {
        const r = asRecord(q);
        return {
          id: str(r.id, crypto.randomUUID()),
          question: str(r.question),
          notes: str(r.notes),
          resolved: bool(r.resolved),
          createdAt: num(r.createdAt, Date.now()),
        };
      })
    : [];
  const messages = Array.isArray(o.messages)
    ? o.messages.map((m) => {
        const r = asRecord(m);
        return {
          id: str(r.id, crypto.randomUUID()),
          role: str(r.role) === "assistant" ? ("assistant" as const) : ("user" as const),
          content: str(r.content),
          createdAt: num(r.createdAt, Date.now()),
        };
      })
    : [];
  return {
    ...base,
    idea: str(o.idea, logline),
    ideaLocked: bool(o.ideaLocked),
    notes: str(o.notes),
    items,
    questions,
    messages,
  };
}

function normalizeCoverDraft(raw: unknown): CoverDraft {
  const o = asRecord(raw);
  const lockedRaw = asRecord(o.locked);
  const mediumsRaw = asRecord(o.mediums);
  const mediums = { ...DEFAULT_MEDIUMS };
  for (const [k, v] of Object.entries(mediumsRaw)) {
    if (typeof v === "number") mediums[k] = v;
  }
  return {
    subject: str(o.subject),
    lighting: str(o.lighting),
    composition: str(o.composition),
    mood: str(o.mood),
    extra: str(o.extra),
    locked: {
      subject: bool(lockedRaw.subject),
      lighting: bool(lockedRaw.lighting),
      composition: bool(lockedRaw.composition),
      mood: bool(lockedRaw.mood),
      extra: bool(lockedRaw.extra),
    },
    mediums,
  };
}

function normalizeCover(raw: unknown): CoverArt {
  const o = asRecord(raw);
  const aspect = str(o.aspect, "16:9");
  return {
    id: str(o.id, crypto.randomUUID()),
    prompt: str(o.prompt),
    styleId: str(o.styleId, "realistic"),
    aspect: aspect === "1:1" || aspect === "4:3" ? aspect : "16:9",
    imageDataUrl: str(o.imageDataUrl),
    locked: bool(o.locked),
    createdAt: num(o.createdAt, Date.now()),
  };
}

export function normalizeProject(raw: unknown): Project {
  const o = asRecord(raw);
  const base = emptyProject();
  const scenarioRaw = asRecord(o.scenario);
  const rating = str(o.rating, "teen");
  const opening = str(scenarioRaw.openingType, "story");
  return {
    ...base,
    id: str(o.id, base.id),
    title: str(o.title, base.title),
    logline: str(o.logline),
    genres: strArr(o.genres).length ? strArr(o.genres) : strArr(o.genre),
    tones: strArr(o.tones).length ? strArr(o.tones) : strArr(o.tone),
    rating: rating === "everyone" || rating === "mature" ? rating : "teen",
    tags: strArr(o.tags),
    updatedAt: num(o.updatedAt, Date.now()),
    createdAt: num(o.createdAt, Date.now()),
    coverId: str(o.coverId) || undefined,
    scenario: {
      ...emptyScenario(),
      openingType:
        opening === "characterCreator" || opening === "multipleChoice" ? opening : "story",
      publicDescription: str(scenarioRaw.publicDescription),
      prompt: str(scenarioRaw.prompt),
      plotEssentials: str(scenarioRaw.plotEssentials),
      authorsNote: str(scenarioRaw.authorsNote),
      aiInstructions: str(scenarioRaw.aiInstructions),
      storySummary: str(scenarioRaw.storySummary),
      thirdPersonName: str(scenarioRaw.thirdPersonName),
      choices: Array.isArray(scenarioRaw.choices)
        ? scenarioRaw.choices.map((c) => {
            const r = asRecord(c);
            return {
              id: str(r.id, crypto.randomUUID()),
              label: str(r.label, "Opening"),
              prompt: str(r.prompt),
            };
          })
        : [],
    },
    cards: Array.isArray(o.cards) ? o.cards.map(normalizeCard) : [],
    covers: Array.isArray(o.covers) ? o.covers.map(normalizeCover) : [],
    brainstorm: normalizeBrainstorm(o.brainstorm, str(o.logline)),
    coverDraft: normalizeCoverDraft(o.coverDraft),
  };
}

export function normalizeLibraryNpc(raw: unknown): LibraryNpc {
  const o = asRecord(raw);
  const npcRaw = asRecord(o.npc);
  return {
    id: str(o.id, crypto.randomUUID()),
    title: str(o.title, "Untitled NPC"),
    keys: str(o.keys),
    value: str(o.value),
    description: str(o.description),
    npc: {
      ...emptyNpc(),
      aliases: str(npcRaw.aliases),
      role: str(npcRaw.role),
      appearance: str(npcRaw.appearance),
      personality: str(npcRaw.personality),
      speech: str(npcRaw.speech),
      motivations: str(npcRaw.motivations),
      relationships: str(npcRaw.relationships),
      secrets: str(npcRaw.secrets),
      abilities: str(npcRaw.abilities),
      quirks: str(npcRaw.quirks),
    },
    portraitDataUrl: str(o.portraitDataUrl) || undefined,
    selected: bool(o.selected),
    createdAt: num(o.createdAt, Date.now()),
  };
}

export function normalizeLibraryElement(raw: unknown): LibraryElement {
  const o = asRecord(raw);
  return {
    id: str(o.id, crypto.randomUUID()),
    title: str(o.title, "Untitled element"),
    type: asCardType(o.type),
    keys: str(o.keys),
    value: str(o.value),
    description: str(o.description),
    useForCharacterCreation: bool(o.useForCharacterCreation),
    selected: bool(o.selected),
    createdAt: num(o.createdAt, Date.now()),
  };
}
