import { createFileRoute } from "@tanstack/react-router";
import { ElementStudio } from "@/components/element-studio";

export const Route = createFileRoute("/project/$id/elements")({ component: ElementsPage });

function ElementsPage() {
  const { id } = Route.useParams();
  return (
    <ElementStudio
      projectId={id}
      types={["item", "creature", "class", "race", "other"]}
      kicker="Lore"
      title="Other elements"
      lede="Items, lore, classes, races, creatures, and anything else that wants a story card. Nest notes under a parent, then check which ones go into the export as distinct cards."
      allowLibrary
    />
  );
}
