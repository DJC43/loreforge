import { createFileRoute } from "@tanstack/react-router";
import { ElementStudio } from "@/components/element-studio";

export const Route = createFileRoute("/project/$id/factions")({ component: FactionsPage });

function FactionsPage() {
  const { id } = Route.useParams();
  return (
    <ElementStudio
      projectId={id}
      types={["faction"]}
      kicker="Power"
      title="Factions"
      lede="Institutions, crews, cults, houses. Nest history or secrets under a faction — check Include in export to send each nested card as its own story card. Save them for future use, or mark scenario-specific."
      allowLibrary
    />
  );
}
