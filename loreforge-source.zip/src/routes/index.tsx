import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { FileUp, FolderDown, Trash2 } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { alwaysOnTokens, cardsTokens } from "@/lib/aid";
import { emptyBrainstorm, emptyCoverDraft } from "@/lib/types";
import { useStudio } from "@/lib/store";
import { formatRelative } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Library });

function Library() {
  const navigate = useNavigate();
  const projects = useStudio((s) => s.projects);
  const hasHydrated = useStudio((s) => s.hasHydrated);
  const createProject = useStudio((s) => s.createProject);
  const deleteProject = useStudio((s) => s.deleteProject);
  const importProject = useStudio((s) => s.importProject);
  const fileRef = useRef<HTMLInputElement>(null);

  const [idea, setIdea] = useState("");
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);

  const sorted = useMemo(
    () => [...projects].sort((a, b) => b.updatedAt - a.updatedAt),
    [projects],
  );
  const doomed = sorted.find((p) => p.id === pendingDelete);

  async function openStudio() {
    const text = idea.trim();
    const project = createProject({
      title: text ? titleFromIdea(text) : "Untitled scenario",
      logline: text,
      brainstorm: emptyBrainstorm(text),
      coverDraft: emptyCoverDraft(),
    });
    setIdea("");
    await navigate({ to: "/project/$id/brainstorm", params: { id: project.id } });
  }

  function onImport(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as unknown;
        const p = importProject(parsed);
        toast.success("Project imported");
        void navigate({ to: "/project/$id", params: { id: p.id } });
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Import failed");
      }
    };
    reader.readAsText(file);
  }

  return (
    <main className="mx-auto max-w-6xl px-4 py-10 md:py-16">
      <div className="max-w-2xl">
        <p className="text-[11px] font-medium tracking-[0.18em] text-steel uppercase">
          Idea first · then the world
        </p>
        <h1 className="mt-3 font-display text-4xl font-medium tracking-tight md:text-6xl">
          What is your Idea?
        </h1>
        <p className="mt-4 max-w-xl text-base text-muted-foreground">
          Lock a thought, raise the questions it creates, then shift to NPCs, factions, locations,
          and plot — all of it lands on the overview.
        </p>
        <Textarea
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
              e.preventDefault();
              void openStudio();
            }
          }}
          placeholder="A river town that records which drowned souls may walk home…"
          className="mt-8 min-h-32"
        />
        <div className="mt-4 flex flex-wrap gap-3">
          <Button onClick={() => void openStudio()}>Open studio</Button>
          <Button variant="outline" onClick={() => fileRef.current?.click()}>
            <FileUp />
            Import
          </Button>
          <Button variant="outline" asChild>
            <a href="/loreforge-source.zip" download="loreforge-source.zip">
              <FolderDown />
              Download source
            </a>
          </Button>
          <Link
            to="/library"
            className="inline-flex h-11 items-center rounded-md px-4 text-sm text-muted-foreground hover:text-foreground"
          >
            NPC library
          </Link>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            suppressHydrationWarning
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onImport(f);
              e.target.value = "";
            }}
          />
        </div>
      </div>

      <section className="mt-14">
        <div className="mb-4 flex items-baseline justify-between">
          <h2 className="text-sm font-medium tracking-wide text-muted-foreground">Projects</h2>
          <span className="font-mono text-[11px] tabular-nums text-muted-foreground">
            {hasHydrated ? `${sorted.length} project${sorted.length === 1 ? "" : "s"}` : "…"}
          </span>
        </div>
        {!hasHydrated && sorted.length === 0 ? (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-44 animate-pulse rounded-xl bg-card" />
            ))}
          </div>
        ) : sorted.length === 0 ? (
          <p className="rounded-xl bg-card px-4 py-10 text-center text-sm text-muted-foreground shadow-[var(--shadow-border)]">
            No projects yet. Start from an idea above.
          </p>
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {sorted.map((p) => {
              const cover = p.covers.find((c) => c.id === p.coverId) ?? p.covers[0];
              return (
                <li key={p.id} className="relative">
                  <Link
                    to="/project/$id"
                    params={{ id: p.id }}
                    className="group block overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
                  >
                    <div className="relative aspect-[16/7] bg-muted">
                      {cover ? (
                        <img
                          src={cover.imageDataUrl}
                          alt=""
                          className="size-full object-cover outline outline-1 -outline-offset-1 outline-white/10"
                        />
                      ) : (
                        <div className="flex size-full items-end p-4">
                          <span className="font-display text-2xl leading-none text-foreground/40">
                            {p.title.slice(0, 1)}
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="space-y-2 p-4 pr-12">
                      <h3 className="font-display text-xl leading-snug">{p.title}</h3>
                      <p className="line-clamp-2 text-sm text-muted-foreground">
                        {p.brainstorm.idea || p.logline || p.scenario.publicDescription || "Empty draft"}
                      </p>
                      <p className="font-mono text-[11px] tabular-nums text-muted-foreground" suppressHydrationWarning>
                        {p.cards.length} cards · {alwaysOnTokens(p) + cardsTokens(p)} tok ·{" "}
                        {hasHydrated ? formatRelative(p.updatedAt) : "saved"}
                      </p>
                    </div>
                  </Link>
                  <button
                    type="button"
                    aria-label={`Delete ${p.title}`}
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setPendingDelete(p.id);
                    }}
                    className="absolute top-3 right-3 flex size-11 items-center justify-center rounded-md bg-ink/60 text-foreground/80 backdrop-blur-sm hover:bg-destructive hover:text-destructive-foreground"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      <Dialog open={Boolean(pendingDelete)} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete this project?</DialogTitle>
            <DialogDescription>
              {doomed
                ? `“${doomed.title}” will be removed from this browser. This cannot be undone.`
                : "This project will be removed from this browser."}
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setPendingDelete(null)}>
              Keep it
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                if (pendingDelete) {
                  deleteProject(pendingDelete);
                  toast.success("Project deleted");
                }
                setPendingDelete(null);
              }}
            >
              Delete
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </main>
  );
}

function titleFromIdea(idea: string) {
  const first = idea.split(/[.!?\n]/)[0]?.trim() ?? "";
  if (first.length >= 5 && first.length <= 52) return first;
  const clipped = idea.trim().slice(0, 52);
  const bounded = clipped.replace(/\s+\S*$/, "").trim();
  return bounded.length >= 5 ? bounded : "Untitled scenario";
}
