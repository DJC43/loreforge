import { createFileRoute, Link } from "@tanstack/react-router";
import { Download, Loader2, Lock } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { ChipMulti } from "@/components/chip-select";
import { GrokFill } from "@/components/grok-fill";
import { SectionIntro } from "@/components/project-frame";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { forgeFromIdea } from "@/lib/ai";
import {
  alwaysOnTokens,
  cardsTokens,
  collectPlaceholders,
  downloadText,
  emptyScenarioFields,
  exportableCards,
  projectPastePack,
  slugify,
  storyCardTree,
  toAidStoryCards,
  toggleList,
} from "@/lib/aid";
import { GENRES, TONES, nestRoleLabel } from "@/lib/catalog";
import { projectContext } from "@/lib/context";
import { toDungeonAdventure, toNpcExport } from "@/lib/dungeon";
import { useStudio } from "@/lib/store";
import { cn } from "@/lib/utils";
import type { Rating, StoryCard } from "@/lib/types";

export const Route = createFileRoute("/project/$id/")({ component: Overview });

const RATING_OPTS: { id: Rating; label: string }[] = [
  { id: "everyone", label: "Everyone" },
  { id: "teen", label: "Teen" },
  { id: "mature", label: "Mature" },
];

function Overview() {
  const { id } = Route.useParams();
  const project = useStudio((s) => s.projects.find((p) => p.id === id));
  const update = useStudio((s) => s.updateProject);
  const applyForge = useStudio((s) => s.applyForge);
  const upsert = useStudio((s) => s.upsertCard);
  const npcLibrary = useStudio((s) => s.npcLibrary);
  const [busy, setBusy] = useState(false);

  if (!project) return null;
  const draft = project;
  const cover = draft.covers.find((c) => c.id === draft.coverId) ?? draft.covers[0];
  const always = alwaysOnTokens(draft);
  const cards = cardsTokens(draft);
  const placeholders = collectPlaceholders(draft);
  const npcs = draft.cards.filter((c) => c.type === "character" && !c.parentId);
  const factions = draft.cards.filter((c) => c.type === "faction" && !c.parentId);
  const locations = draft.cards.filter((c) => c.type === "location" && !c.parentId);
  const other = draft.cards.filter(
    (c) => !c.parentId && !["character", "faction", "location"].includes(c.type),
  );
  const openQs = draft.brainstorm.questions.filter((q) => !q.resolved);
  const lockedIdeas = draft.brainstorm.items.filter((i) => i.status === "locked");
  const openIdeas = draft.brainstorm.items.filter((i) => i.status === "open");
  const blanks = emptyScenarioFields(draft);
  const ctx = projectContext(draft);
  const nestedCount = draft.cards.filter((c) => Boolean(c.parentId)).length;
  const includedCards = exportableCards(draft.cards);
  const selectedNpcs = npcLibrary.filter((n) => n.selected);

  const checks = [
    { ok: Boolean(draft.brainstorm.idea), label: "Core idea", to: "/project/$id/brainstorm" as const },
    { ok: draft.brainstorm.ideaLocked, label: "Idea locked", to: "/project/$id/brainstorm" as const },
    { ok: Boolean(draft.title && draft.title !== "Untitled scenario"), label: "Title" },
    { ok: draft.genres.length > 0, label: "Genre" },
    { ok: Boolean(draft.scenario.prompt), label: "Opening prompt", to: "/project/$id/scenario" as const },
    { ok: Boolean(draft.scenario.plotEssentials), label: "Plot essentials", to: "/project/$id/scenario" as const },
    { ok: npcs.length > 0, label: "At least one NPC", to: "/project/$id/npcs" as const },
    { ok: locations.length > 0, label: "A location", to: "/project/$id/locations" as const },
    { ok: Boolean(cover), label: "Cover image", to: "/project/$id/covers" as const },
  ];

  async function forge() {
    const seed = [
      draft.brainstorm.idea,
      draft.logline,
      draft.genres.join(", "),
      draft.tones.join(", "),
      lockedIdeas.map((i) => i.text).join("\n"),
    ]
      .filter(Boolean)
      .join("\n");
    if (!seed.trim()) {
      toast.error("Start from the Idea tab first.");
      return;
    }
    setBusy(true);
    try {
      const res = await forgeFromIdea({
        data: { idea: seed, extra: `Title: ${draft.title}\n${ctx}` },
      });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      applyForge(id, res.data);
      toast.success("Draft forged into this project");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Forge failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <SectionIntro
        kicker="Overview"
        title={project.title || "Untitled"}
        lede="The live spine. Brainstorm, people, places, and plot all land here as you work."
        actions={
          <Button onClick={() => void forge()} disabled={busy}>
            {busy ? <Loader2 className="animate-spin" /> : null}
            Forge from idea
          </Button>
        }
      />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_280px]">
        <div className="space-y-5">
          <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
            <div className="flex items-center justify-between gap-2">
              <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
                Core idea
              </p>
              {draft.brainstorm.ideaLocked ? (
                <Badge variant="steel">
                  <Lock className="mr-1 size-3" />
                  Locked
                </Badge>
              ) : (
                <Badge variant="outline">Open</Badge>
              )}
            </div>
            <p className="mt-2 text-sm leading-relaxed">
              {draft.brainstorm.idea || draft.logline || "No idea yet — start on the Idea tab."}
            </p>
            <Link
              to="/project/$id/brainstorm"
              params={{ id }}
              className="mt-3 inline-block text-xs text-steel underline-offset-4 hover:underline"
            >
              Open brainstorm
            </Link>
          </div>

          {(openQs.length > 0 || lockedIdeas.length > 0 || openIdeas.length > 0) && (
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
                <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
                  Open questions
                </p>
                {openQs.length === 0 ? (
                  <p className="mt-2 text-sm text-muted-foreground">None open.</p>
                ) : (
                  <ul className="mt-2 space-y-1.5 text-sm">
                    {openQs.slice(0, 6).map((q) => (
                      <li key={q.id} className="text-muted-foreground">
                        {q.question}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
              <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
                <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
                  Locked ideas
                </p>
                {lockedIdeas.length === 0 ? (
                  <p className="mt-2 text-sm text-muted-foreground">
                    {openIdeas.length} still open.
                  </p>
                ) : (
                  <ul className="mt-2 space-y-1.5 text-sm">
                    {lockedIdeas.slice(0, 6).map((i) => (
                      <li key={i.id} className="flex gap-2">
                        <Lock className="mt-0.5 size-3 shrink-0 text-steel" />
                        <span>{i.text}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label htmlFor="title">Title</Label>
              <GrokFill
                field="title"
                value={project.title}
                onChange={(title) => update(id, { title })}
                context={ctx}
                instruction="A scenario title. Evocative, short."
              />
            </div>
            <Input
              id="title"
              value={project.title}
              onChange={(e) => update(id, { title: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label htmlFor="logline">Logline</Label>
              <GrokFill
                field="logline"
                value={project.logline}
                onChange={(logline) => update(id, { logline })}
                context={ctx}
                instruction="One sentence the player would want to click."
              />
            </div>
            <Textarea
              id="logline"
              value={project.logline}
              onChange={(e) => update(id, { logline: e.target.value })}
              className="min-h-24"
              placeholder="One sentence the player would want to click."
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label>Genre — select more than one</Label>
              <ChipMulti
                values={GENRES}
                selected={project.genres}
                onToggle={(v) => update(id, { genres: toggleList(project.genres, v) })}
              />
              <p className="text-xs text-muted-foreground">
                {project.genres.length
                  ? project.genres.join(" · ")
                  : "Tap several. Mix is encouraged."}
              </p>
              <Input
                value={project.genres.join(", ")}
                onChange={(e) =>
                  update(id, {
                    genres: e.target.value
                      .split(",")
                      .map((t) => t.trim())
                      .filter(Boolean),
                  })
                }
                placeholder="Custom genres, comma-separated"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Tone — select more than one</Label>
              <ChipMulti
                values={TONES}
                selected={project.tones}
                onToggle={(v) => update(id, { tones: toggleList(project.tones, v) })}
              />
              <p className="text-xs text-muted-foreground">
                {project.tones.length ? project.tones.join(" · ") : "Tap several."}
              </p>
              <Input
                value={project.tones.join(", ")}
                onChange={(e) =>
                  update(id, {
                    tones: e.target.value
                      .split(",")
                      .map((t) => t.trim())
                      .filter(Boolean),
                  })
                }
                placeholder="Custom tones, comma-separated"
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="tags">Tags — comma-separated, as many as you like</Label>
            <Input
              id="tags"
              value={project.tags.join(", ")}
              onChange={(e) =>
                update(id, {
                  tags: e.target.value
                    .split(",")
                    .map((t) => t.trim())
                    .filter(Boolean),
                })
              }
              placeholder="mystery, gothic, ghosts"
            />
          </div>
          <div className="space-y-2">
            <Label>Rating</Label>
            <div className="flex flex-wrap gap-2">
              {RATING_OPTS.map((r) => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => update(id, { rating: r.id })}
                  className={cn(
                    "h-11 rounded-md px-4 text-sm",
                    project.rating === r.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground",
                  )}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <WorldPeek
              label="NPCs"
              to="/project/$id/npcs"
              id={id}
              items={npcs.map((c) => c.title)}
              hint={nestedCount ? `${nestedCount} nested card${nestedCount === 1 ? "" : "s"}` : undefined}
            />
            <WorldPeek
              label="Factions"
              to="/project/$id/factions"
              id={id}
              items={factions.map((c) => c.title)}
            />
            <WorldPeek
              label="Locations"
              to="/project/$id/locations"
              id={id}
              items={locations.map((c) => c.title)}
            />
            <WorldPeek
              label="Other elements"
              to="/project/$id/elements"
              id={id}
              items={other.map((c) => c.title)}
            />
          </div>
        </div>

        <aside className="space-y-4">
          <div className="overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]">
            {cover ? (
              <img
                src={cover.imageDataUrl}
                alt=""
                className="aspect-video w-full object-cover outline outline-1 -outline-offset-1 outline-white/10"
              />
            ) : (
              <div className="flex aspect-video items-center justify-center text-sm text-muted-foreground">
                No cover yet
              </div>
            )}
            <div className="p-4">
              <Link
                to="/project/$id/covers"
                params={{ id }}
                className="text-sm text-steel underline-offset-4 hover:underline"
              >
                Open cover studio
              </Link>
            </div>
          </div>
          <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
            <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
              Plot
            </p>
            <p className="mt-2 text-sm capitalize">
              {draft.scenario.openingType.replace(/([A-Z])/g, " $1")}
            </p>
            <p className="mt-2 line-clamp-4 text-xs leading-relaxed text-muted-foreground">
              {draft.scenario.prompt || "No opening prompt yet."}
            </p>
            <p className="mt-2 text-xs text-muted-foreground">
              {blanks.length
                ? `${blanks.length} empty field${blanks.length === 1 ? "" : "s"}`
                : "All plot fields filled"}
            </p>
            <Link
              to="/project/$id/scenario"
              params={{ id }}
              className="mt-2 inline-block text-sm text-steel underline-offset-4 hover:underline"
            >
              Open plot components
            </Link>
          </div>
          <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
            <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
              Export
            </p>
            <p className="mt-2 text-xs text-muted-foreground">
              Nesting is studio-only. Check a nested backstory or motivation to include it as its
              own AID story card — the JSON stays a flat list.
            </p>
            <ExportCardPicker
              cards={draft.cards}
              onToggle={(card, next) => upsert(id, { ...card, includeInExport: next })}
              onSetAll={(next) =>
                update(id, {
                  cards: draft.cards.map((c) => ({ ...c, includeInExport: next })),
                })
              }
            />
            <div className="mt-3 flex flex-col gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  downloadText(
                    `${slugify(project.title)}-adventure.json`,
                    JSON.stringify(toDungeonAdventure(project), null, 2),
                    "application/json",
                  );
                  toast.success(
                    `Dungeon Extension v2 · ${includedCards.length} card${includedCards.length === 1 ? "" : "s"}`,
                  );
                }}
              >
                <Download />
                Adventure JSON
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const list = selectedNpcs.length
                    ? selectedNpcs
                    : npcs
                        .filter((c) => c.includeInExport !== false)
                        .map((c) => ({
                          id: c.id,
                          title: c.title,
                          keys: c.keys,
                          value: c.value,
                          description: c.description,
                          npc: c.npc ?? {
                            aliases: "",
                            role: "",
                            appearance: "",
                            personality: "",
                            speech: "",
                            motivations: "",
                            relationships: "",
                            secrets: "",
                            abilities: "",
                            quirks: "",
                          },
                          portraitDataUrl: c.portraitDataUrl,
                          selected: true,
                          createdAt: project.updatedAt,
                        }));
                  downloadText(
                    `${slugify(project.title)}-npcs.json`,
                    JSON.stringify(toNpcExport(list), null, 2),
                    "application/json",
                  );
                  toast.success(
                    selectedNpcs.length
                      ? `Exported ${selectedNpcs.length} selected NPC${selectedNpcs.length === 1 ? "" : "s"}`
                      : "Exported this scenario's NPCs",
                  );
                }}
              >
                <Download />
                NPC JSON
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  downloadText(
                    `${slugify(project.title)}-cards.json`,
                    JSON.stringify(toAidStoryCards(project.cards), null, 2),
                    "application/json",
                  );
                  toast.success(
                    `AID story cards · ${includedCards.length} included`,
                  );
                }}
              >
                <Download />
                AID story cards
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  downloadText(`${slugify(project.title)}-aid.txt`, projectPastePack(project));
                  toast.success("Paste pack downloaded");
                }}
              >
                <Download />
                Paste pack
              </Button>
            </div>
          </div>
          <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
            <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
              Context budget
            </p>
            <dl className="mt-3 space-y-1 font-mono text-xs tabular-nums">
              <Row k="Always-on" v={`${always} tok`} />
              <Row k="Story cards" v={`${cards} tok`} />
              <Row k="Total (est.)" v={`${always + cards} tok`} />
              <Row k="Cards" v={`${includedCards.length}/${project.cards.length}`} />
            </dl>
          </div>
          <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
            <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
              Completeness
            </p>
            <ul className="mt-3 space-y-1.5 text-sm">
              {checks.map((c) => (
                <li key={c.label} className="flex items-center gap-2">
                  <span className={cn("size-1.5 rounded-full", c.ok ? "bg-steel" : "bg-muted-foreground/40")} />
                  {c.to ? (
                    <Link
                      to={c.to}
                      params={{ id }}
                      className={cn(
                        "underline-offset-4 hover:underline",
                        c.ok ? "text-foreground" : "text-muted-foreground",
                      )}
                    >
                      {c.label}
                    </Link>
                  ) : (
                    <span className={c.ok ? "text-foreground" : "text-muted-foreground"}>{c.label}</span>
                  )}
                </li>
              ))}
            </ul>
          </div>
          {placeholders.length ? (
            <div className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
              <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
                Placeholders
              </p>
              <ul className="mt-2 space-y-1 font-mono text-xs text-steel">
                {placeholders.map((p) => (
                  <li key={p}>{`\${${p}}`}</li>
                ))}
              </ul>
            </div>
          ) : null}
        </aside>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-muted-foreground">{k}</dt>
      <dd>{v}</dd>
    </div>
  );
}

function ExportCardPicker({
  cards,
  onToggle,
  onSetAll,
}: {
  cards: StoryCard[];
  onToggle: (card: StoryCard, next: boolean) => void;
  onSetAll: (next: boolean) => void;
}) {
  const rows = storyCardTree(cards);
  const included = cards.filter((c) => c.includeInExport !== false).length;
  const nested = cards.filter((c) => Boolean(c.parentId)).length;
  if (cards.length === 0) {
    return <p className="mt-3 text-xs text-muted-foreground">No story cards yet.</p>;
  }
  return (
    <div className="mt-3 space-y-2">
      <div className="flex items-center justify-between gap-2">
        <p className="font-mono text-[11px] tabular-nums text-muted-foreground">
          {included}/{cards.length} included
          {nested ? ` · ${nested} nested` : ""}
        </p>
        <div className="flex gap-1">
          <button
            type="button"
            className="h-11 rounded-md px-3 text-xs text-muted-foreground hover:bg-muted hover:text-foreground"
            onClick={() => onSetAll(true)}
          >
            All
          </button>
          <button
            type="button"
            className="h-11 rounded-md px-3 text-xs text-muted-foreground hover:bg-muted hover:text-foreground"
            onClick={() => onSetAll(false)}
          >
            None
          </button>
        </div>
      </div>
      <ul className="max-h-64 space-y-0.5 overflow-auto rounded-lg bg-secondary p-1.5">
        {rows.map((row) => (
          <li key={row.card.id}>
            <label
              className="flex min-h-11 cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-muted"
              style={{ paddingLeft: 8 + row.depth * 14 }}
            >
              <input
                type="checkbox"
                checked={row.card.includeInExport !== false}
                onChange={(e) => onToggle(row.card, e.target.checked)}
                className="size-4 shrink-0 accent-steel"
              />
              <span className="min-w-0 flex-1 truncate">{row.card.title}</span>
              <span className="shrink-0 text-[11px] text-muted-foreground capitalize">
                {row.depth > 0 ? nestRoleLabel(row.card.nestRole) : row.card.type}
              </span>
            </label>
          </li>
        ))}
      </ul>
    </div>
  );
}

function WorldPeek({
  label,
  items,
  to,
  id,
  hint,
}: {
  label: string;
  items: string[];
  to: "/project/$id/npcs" | "/project/$id/factions" | "/project/$id/locations" | "/project/$id/elements";
  id: string;
  hint?: string;
}) {
  return (
    <Link
      to={to}
      params={{ id }}
      className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)] transition-[box-shadow] hover:shadow-[var(--shadow-border-hover)]"
    >
      <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
        {label}
      </p>
      <p className="mt-1 font-mono text-xs tabular-nums text-muted-foreground">
        {items.length}
        {hint ? ` · ${hint}` : ""}
      </p>
      <p className="mt-2 line-clamp-2 text-sm">
        {items.length ? items.join(" · ") : "None yet"}
      </p>
    </Link>
  );
}
