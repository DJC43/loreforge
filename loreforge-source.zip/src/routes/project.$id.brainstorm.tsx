import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUp, Check, Loader2, Lock, LockOpen, Plus, Trash2 } from "lucide-react";
import { useRef, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { GrokFill } from "@/components/grok-fill";
import { SectionIntro } from "@/components/project-frame";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { brainstormChat, harvestBrainstorm } from "@/lib/ai";
import { projectContext } from "@/lib/context";
import { useStudio } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/project/$id/brainstorm")({ component: IdeaPage });

const STARTERS = [
  "What is the playable hook in this idea?",
  "List the questions this idea still needs answered.",
  "Name three factions and what they want.",
  "What secret would make the logline sting?",
  "Give me five sensory motifs to keep the tone honest.",
  "Propose two twists that don't break the premise.",
];

function IdeaPage() {
  const { id } = Route.useParams();
  const project = useStudio((s) => s.projects.find((p) => p.id === id));
  const patchBrainstorm = useStudio((s) => s.patchBrainstorm);
  const update = useStudio((s) => s.updateProject);
  const appendChat = useStudio((s) => s.appendChat);
  const addIdeaItem = useStudio((s) => s.addIdeaItem);
  const patchIdeaItem = useStudio((s) => s.patchIdeaItem);
  const removeIdeaItem = useStudio((s) => s.removeIdeaItem);
  const addQuestion = useStudio((s) => s.addQuestion);
  const patchQuestion = useStudio((s) => s.patchQuestion);
  const removeQuestion = useStudio((s) => s.removeQuestion);
  const [draft, setDraft] = useState("");
  const [newIdea, setNewIdea] = useState("");
  const [newQ, setNewQ] = useState("");
  const [busy, setBusy] = useState<"chat" | "harvest" | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  if (!project) return null;
  const b = project.brainstorm;
  const context = projectContext(project);

  async function send(text: string) {
    const message = text.trim();
    if (!message || busy) return;
    appendChat(id, "user", message);
    setDraft("");
    setBusy("chat");
    try {
      const history = [
        ...b.messages.map((m) => ({ role: m.role, content: m.content })),
        { role: "user" as const, content: message },
      ];
      const res = await brainstormChat({
        data: { context, history: history.slice(-12), message },
      });
      if (!res.ok) {
        toast.error(res.error);
        appendChat(id, "assistant", `Could not reply: ${res.error}`);
        return;
      }
      appendChat(id, "assistant", res.text);
      endRef.current?.scrollIntoView({ behavior: "smooth" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Chat failed");
    } finally {
      setBusy(null);
    }
  }

  async function develop() {
    if (!b.idea.trim()) {
      toast.error("Write the idea first.");
      return;
    }
    setBusy("harvest");
    try {
      const transcript = b.messages
        .slice(-8)
        .map((m) => `${m.role}: ${m.content}`)
        .join("\n");
      const res = await harvestBrainstorm({
        data: { idea: b.idea, context, transcript },
      });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      const d = res.data;
      if (d.title) update(id, { title: d.title });
      if (d.logline) update(id, { logline: d.logline });
      if (d.genres.length) update(id, { genres: d.genres });
      if (d.tones.length) update(id, { tones: d.tones });
      if (d.tags.length) update(id, { tags: d.tags });
      if (d.idea) {
        patchBrainstorm(id, { idea: d.idea, ideaLocked: true });
        update(id, { logline: d.logline || d.idea });
      } else {
        patchBrainstorm(id, { ideaLocked: true });
      }
      for (const idea of d.ideas) addIdeaItem(id, idea, "open");
      for (const q of d.questions) addQuestion(id, q);
      toast.success("Harvested ideas and questions");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Harvest failed");
    } finally {
      setBusy(null);
    }
  }

  const openIdeas = b.items.filter((i) => i.status === "open");
  const lockedIdeas = b.items.filter((i) => i.status === "locked");
  const resolvedIdeas = b.items.filter((i) => i.status === "resolved");
  const openQs = b.questions.filter((q) => !q.resolved);
  const closedQs = b.questions.filter((q) => q.resolved);

  return (
    <div>
      <SectionIntro
        kicker="Idea"
        title="What is your Idea?"
        lede="Lock the premise when it is ready. Open questions stay visible. Everything you pin here writes onto the overview."
        actions={
          <Button onClick={() => void develop()} disabled={busy !== null}>
            {busy === "harvest" ? <Loader2 className="animate-spin" /> : null}
            Develop with Grok
          </Button>
        }
      />

      <div className="mb-6 rounded-xl bg-card p-4 shadow-[var(--shadow-border)] md:p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <Label htmlFor="core-idea">Core idea</Label>
          <div className="flex items-center gap-1">
            <GrokFill
              field="core idea"
              value={b.idea}
              onChange={(idea) => {
                patchBrainstorm(id, { idea });
                if (!project.logline) update(id, { logline: idea });
              }}
              context={context}
              instruction="One vivid playable premise. One or two sentences."
              label="Fill"
            />
            <Button
              variant={b.ideaLocked ? "secondary" : "outline"}
              size="sm"
              onClick={() => {
                const next = !b.ideaLocked;
                patchBrainstorm(id, { ideaLocked: next });
                if (next && b.idea.trim()) update(id, { logline: b.idea.trim() });
              }}
            >
              {b.ideaLocked ? <Lock /> : <LockOpen />}
              {b.ideaLocked ? "Locked" : "Lock idea"}
            </Button>
          </div>
        </div>
        <Textarea
          id="core-idea"
          value={b.idea}
          disabled={b.ideaLocked}
          onChange={(e) => patchBrainstorm(id, { idea: e.target.value })}
          className="mt-2 min-h-28"
          placeholder="The thought everything else has to serve."
        />
        {b.ideaLocked ? (
          <p className="mt-2 text-xs text-steel">
            Locked ideas funnel to the{" "}
            <Link to="/project/$id" params={{ id }} className="underline-offset-4 hover:underline">
              overview
            </Link>
            . Unlock to keep editing.
          </p>
        ) : null}
      </div>

      <div className="mb-8 grid gap-4 lg:grid-cols-2">
        <TrackerCard
          title="Open ideas"
          hint="Thoughts still in play."
          count={openIdeas.length}
        >
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (!newIdea.trim()) return;
              addIdeaItem(id, newIdea.trim(), "open");
              setNewIdea("");
            }}
          >
            <Input
              value={newIdea}
              onChange={(e) => setNewIdea(e.target.value)}
              placeholder="Add an idea to track"
            />
            <Button type="submit" size="icon" aria-label="Add idea">
              <Plus />
            </Button>
          </form>
          <ul className="space-y-2">
            {openIdeas.map((item) => (
              <IdeaRow
                key={item.id}
                text={item.text}
                onLock={() => patchIdeaItem(id, item.id, { status: "locked" })}
                onResolve={() => patchIdeaItem(id, item.id, { status: "resolved" })}
                onDelete={() => removeIdeaItem(id, item.id)}
              />
            ))}
          </ul>
          {lockedIdeas.length ? (
            <div className="pt-2">
              <p className="mb-2 text-[11px] font-medium tracking-wide text-muted-foreground uppercase">
                Locked
              </p>
              <ul className="space-y-2">
                {lockedIdeas.map((item) => (
                  <li key={item.id} className="flex items-start gap-2 rounded-lg bg-secondary px-3 py-2 text-sm">
                    <Lock className="mt-0.5 size-3.5 shrink-0 text-steel" />
                    <span className="flex-1">{item.text}</span>
                    <button
                      type="button"
                      className="text-muted-foreground hover:text-foreground"
                      aria-label="Unlock"
                      onClick={() => patchIdeaItem(id, item.id, { status: "open" })}
                    >
                      <LockOpen className="size-3.5" />
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
          {resolvedIdeas.length ? (
            <p className="text-xs text-muted-foreground">{resolvedIdeas.length} resolved</p>
          ) : null}
        </TrackerCard>

        <TrackerCard
          title="Open questions"
          hint="What still has to be decided."
          count={openQs.length}
        >
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (!newQ.trim()) return;
              addQuestion(id, newQ.trim());
              setNewQ("");
            }}
          >
            <Input
              value={newQ}
              onChange={(e) => setNewQ(e.target.value)}
              placeholder="Add a question"
            />
            <Button type="submit" size="icon" aria-label="Add question">
              <Plus />
            </Button>
          </form>
          <ul className="space-y-2">
            {openQs.map((q) => (
              <li key={q.id} className="rounded-lg bg-secondary px-3 py-2">
                <div className="flex items-start gap-2">
                  <p className="flex-1 text-sm">{q.question}</p>
                  <button
                    type="button"
                    aria-label="Resolve"
                    className="text-muted-foreground hover:text-foreground"
                    onClick={() => patchQuestion(id, q.id, { resolved: true })}
                  >
                    <Check className="size-3.5" />
                  </button>
                  <button
                    type="button"
                    aria-label="Delete question"
                    className="text-muted-foreground hover:text-destructive"
                    onClick={() => removeQuestion(id, q.id)}
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
                <Input
                  value={q.notes}
                  onChange={(e) => patchQuestion(id, q.id, { notes: e.target.value })}
                  placeholder="Notes"
                  className="mt-2 h-9 text-xs"
                />
              </li>
            ))}
          </ul>
          {closedQs.length ? (
            <p className="text-xs text-muted-foreground">{closedQs.length} resolved</p>
          ) : null}
        </TrackerCard>
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_280px]">
        <div className="flex min-h-[50vh] flex-col rounded-xl bg-card shadow-[var(--shadow-border)]">
          <div className="flex-1 space-y-4 overflow-auto p-4 md:p-5">
            {b.messages.length === 0 ? (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">Talk the idea open, or start here:</p>
                <div className="flex flex-col gap-2">
                  {STARTERS.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => void send(s)}
                      className="rounded-lg bg-secondary px-3 py-2.5 text-left text-sm hover:bg-muted"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              b.messages.map((m) => (
                <div
                  key={m.id}
                  className={cn(
                    "max-w-[42rem] rounded-lg px-3 py-2.5 text-sm leading-relaxed whitespace-pre-wrap",
                    m.role === "user" ? "ml-auto bg-secondary" : "bg-muted",
                  )}
                >
                  {m.content}
                  {m.role === "assistant" ? (
                    <button
                      type="button"
                      className="mt-2 block text-[11px] text-steel underline-offset-4 hover:underline"
                      onClick={() => {
                        addIdeaItem(id, m.content.split("\n")[0]?.replace(/^\d+\.\s*/, "") || m.content, "open");
                        toast.success("Pinned as an open idea");
                      }}
                    >
                      Pin first line as idea
                    </button>
                  ) : null}
                </div>
              ))
            )}
            <div ref={endRef} />
          </div>
          <form
            className="flex items-end gap-2 border-t border-border p-3"
            onSubmit={(e) => {
              e.preventDefault();
              void send(draft);
            }}
          >
            <Textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void send(draft);
                }
              }}
              placeholder="Ask, argue, or split the idea…"
              className="min-h-14 flex-1"
            />
            <Button type="submit" size="icon" disabled={busy !== null || !draft.trim()} aria-label="Send">
              {busy === "chat" ? <Loader2 className="animate-spin" /> : <ArrowUp />}
            </Button>
          </form>
        </div>
        <aside className="space-y-2">
          <Label htmlFor="notes">Pinned notes</Label>
          <Textarea
            id="notes"
            value={b.notes}
            onChange={(e) => patchBrainstorm(id, { notes: e.target.value })}
            className="min-h-64"
            placeholder="Must-not-forget details."
          />
        </aside>
      </div>
    </div>
  );
}

function TrackerCard({
  title,
  hint,
  count,
  children,
}: {
  title: string;
  hint: string;
  count: number;
  children: ReactNode;
}) {
  return (
    <div className="space-y-3 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
      <div className="flex items-baseline justify-between gap-2">
        <div>
          <h2 className="text-sm font-medium">{title}</h2>
          <p className="text-xs text-muted-foreground">{hint}</p>
        </div>
        <Badge variant="outline">{count}</Badge>
      </div>
      {children}
    </div>
  );
}

function IdeaRow({
  text,
  onLock,
  onResolve,
  onDelete,
}: {
  text: string;
  onLock: () => void;
  onResolve: () => void;
  onDelete: () => void;
}) {
  return (
    <li className="flex items-start gap-2 rounded-lg bg-muted px-3 py-2 text-sm">
      <span className="flex-1">{text}</span>
      <button type="button" aria-label="Lock idea" className="text-muted-foreground hover:text-foreground" onClick={onLock}>
        <Lock className="size-3.5" />
      </button>
      <button type="button" aria-label="Resolve idea" className="text-muted-foreground hover:text-foreground" onClick={onResolve}>
        <Check className="size-3.5" />
      </button>
      <button type="button" aria-label="Delete idea" className="text-muted-foreground hover:text-destructive" onClick={onDelete}>
        <Trash2 className="size-3.5" />
      </button>
    </li>
  );
}
