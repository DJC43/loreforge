import { createFileRoute } from "@tanstack/react-router";
import { ProjectFrame } from "@/components/project-frame";

export const Route = createFileRoute("/project/$id")({
  component: ProjectFrame,
});
