import { createFileRoute } from "@tanstack/react-router";
import { ElementStudio } from "@/components/element-studio";

export const Route = createFileRoute("/project/$id/npcs")({ component: NpcsPage });

function NpcsPage() {
  const { id } = Route.useParams();
  return (
    <ElementStudio
      projectId={id}
      types={["character"]}
      kicker="People"
      title="NPCs"
      lede="Portraits can be uploaded or painted — large, square, and tied to the person. Nest backstory, motivation, secrets under them. Nesting stays in the studio; check Include in export to send each nested card as its own AID story card."
      allowLibrary
      allowPortrait
    />
  );
}
