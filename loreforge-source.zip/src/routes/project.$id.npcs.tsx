import { createFileRoute } from "@tanstack/react-router";
import { ElementStudio } from "@/components/element-studio";

export const Route = createFileRoute("/project/$id/npcs")({ component: NpcsPage });

function NpcsPage() {
  const { id } = Route.useParams();
  return (
    <ElementStudio
      projectId={id}
      types={["character"]}
      kicker="People"
      title="NPCs"
      lede="Portraits sit on the primary person. Backstory, desires, secrets nest under them — use the Backstory / Desires chips, or Group by name to tuck 'Ava Quinn Backstory' under Ava Quinn. Nesting is studio-only; check Include in export to send each nested card as its own AID story card."
      allowLibrary
      allowPortrait
    />
  );
}
