import { createFileRoute, Link } from "@tanstack/react-router";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { FieldBlock } from "@/components/field-block";
import { GrokFill } from "@/components/grok-fill";
import { SectionIntro } from "@/components/project-frame";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { fillScenarioBlanks } from "@/lib/ai";
import { alwaysOnTokens, emptyScenarioFields } from "@/lib/aid";
import { projectContext } from "@/lib/context";
import { useStudio } from "@/lib/store";
import { newId, cn } from "@/lib/utils";
import type { OpeningType, StoryCard } from "@/lib/types";

export const Route = createFileRoute("/project/$id/scenario")({ component: ScenarioPage });

const OPENINGS: { id: OpeningType; label: string; hint: string }[] = [
  { id: "story", label: "Story", hint: "A fixed opening prompt. Same start every play." },
  {
    id: "characterCreator",
    label: "Character creator",
    hint: "Players pick class, race, location, faction from story cards.",
  },
  { id: "multipleChoice", label: "Multiple choice", hint: "Several opening prompts, player picks one." },
];

function ScenarioPage() {
  const { id } = Route.useParams();
  const project = useStudio((s) => s.projects.find((p) => p.id === id));
  const patch = useStudio((s) => s.patchScenario);
  const applyForge = useStudio((s) => s.applyForge);
  const upsert = useStudio((s) => s.upsertCard);
  const [busy, setBusy] = useState(false);

  if (!project) return null;
  const s = project.scenario;
  const ctx = projectContext(project);
  const blanks = emptyScenarioFields(project);
  const ccCards = project.cards.filter((c) => c.useForCharacterCreation);

  async function fillBlanks() {
    const fields = blanks.length ? blanks : [
      "publicDescription",
      "prompt",
      "plotEssentials",
      "authorsNote",
      "aiInstructions",
      "storySummary",
      ...(s.openingType === "multipleChoice" ? ["choices"] : []),
      ...(s.openingType === "characterCreator" ? ["cards"] : []),
    ];
    setBusy(true);
    try {
      const res = await fillScenarioBlanks({
        data: { context: ctx, openingType: s.openingType, emptyFields: fields },
      });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      const d = res.data;
      applyForge(id, {
        publicDescription: s.publicDescription.trim() ? undefined : d.publicDescription || undefined,
        prompt: s.prompt.trim() ? undefined : d.prompt || undefined,
        plotEssentials: s.plotEssentials.trim() ? undefined : d.plotEssentials || undefined,
        authorsNote: s.authorsNote.trim() ? undefined : d.authorsNote || undefined,
        aiInstructions: s.aiInstructions.trim() ? undefined : d.aiInstructions || undefined,
        storySummary: s.storySummary.trim() ? undefined : d.storySummary || undefined,
        choices: s.openingType === "multipleChoice" && !s.choices.some((c) => c.prompt.trim())
          ? d.choices
          : undefined,
        cards: s.openingType === "characterCreator" ? d.cards : undefined,
      });
      toast.success("Empty fields filled — edit or regenerate any of them.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Fill failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <SectionIntro
        kicker="Plot"
        title="Plot components"
        lede="The UI follows the opening type. Fill empty fields with Grok, then edit or regenerate each one."
        actions={
          <Button onClick={() => void fillBlanks()} disabled={busy}>
            {busy ? <Loader2 className="animate-spin" /> : null}
            Fill empty fields
          </Button>
        }
      />

      <div className="mb-8 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
        <p className="text-xs font-medium text-muted-foreground">Opening type</p>
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          {OPENINGS.map((o) => (
            <button
              key={o.id}
              type="button"
              onClick={() => patch(id, { openingType: o.id })}
              className={cn(
                "rounded-lg p-3 text-left",
                s.openingType === o.id ? "bg-primary text-primary-foreground" : "bg-secondary",
              )}
            >
              <span className="block text-sm font-medium">{o.label}</span>
              <span
                className={cn(
                  "mt-1 block text-xs",
                  s.openingType === o.id ? "text-primary-foreground/70" : "text-muted-foreground",
                )}
              >
                {o.hint}
              </span>
            </button>
          ))}
        </div>
        <p className="mt-3 font-mono text-[11px] tabular-nums text-muted-foreground">
          Always-on estimate {alwaysOnTokens(project)} tokens
          {blanks.length ? ` · ${blanks.length} empty` : " · complete"}
        </p>
      </div>

      <div className="space-y-8">
        <FieldBlock
          label="Public description"
          hint="Listing copy on AI Dungeon. Sell the hook; don't spoil the turn."
          field="publicDescription"
          value={s.publicDescription}
          onChange={(v) => patch(id, { publicDescription: v })}
          context={ctx}
          minH="min-h-24"
        />

        {s.openingType === "story" ? (
          <FieldBlock
            label="Starting prompt"
            hint="Second person, present tense. Hook first. End on a knock, a choice, or a problem. Use ${Question} for player input."
            field="prompt"
            value={s.prompt}
            onChange={(v) => patch(id, { prompt: v })}
            context={ctx}
            minH="min-h-40"
          />
        ) : null}

        {s.openingType === "characterCreator" ? (
          <CharacterCreatorPanel
            id={id}
            prompt={s.prompt}
            onPrompt={(v) => patch(id, { prompt: v })}
            ctx={ctx}
            cards={ccCards}
            onToggle={(card, next) => upsert(id, { ...card, useForCharacterCreation: next })}
          />
        ) : null}

        {s.openingType === "multipleChoice" ? (
          <MultipleChoicePanel
            id={id}
            preamble={s.prompt}
            onPreamble={(v) => patch(id, { prompt: v })}
            choices={s.choices}
            onChoices={(choices) => patch(id, { choices })}
            ctx={ctx}
          />
        ) : null}

        <FieldBlock
          label="Plot essentials"
          hint="Always in context. Player identity, immutable setting rules, names the model must never drop."
          field="plotEssentials"
          value={s.plotEssentials}
          onChange={(v) => patch(id, { plotEssentials: v })}
          context={ctx}
          minH="min-h-36"
        />
        <FieldBlock
          label="Author's note"
          hint="Short. Genre, tense, tone, what to avoid. Not lore — that's plot essentials and cards."
          field="authorsNote"
          value={s.authorsNote}
          onChange={(v) => patch(id, { authorsNote: v })}
          context={ctx}
          minH="min-h-24"
        />
        <FieldBlock
          label="AI instructions"
          hint="Behavioral rules: POV, don't speak for the player, content limits."
          field="aiInstructions"
          value={s.aiInstructions}
          onChange={(v) => patch(id, { aiInstructions: v })}
          context={ctx}
          minH="min-h-24"
        />
        <FieldBlock
          label="Story summary (seed)"
          hint="Optional backstory the Memory System can start from. Keep it short."
          field="storySummary"
          value={s.storySummary}
          onChange={(v) => patch(id, { storySummary: v })}
          context={ctx}
          minH="min-h-24"
        />
        <div className="space-y-1.5">
          <Label htmlFor="tp">Third-person name (optional)</Label>
          <Input
            id="tp"
            value={s.thirdPersonName}
            onChange={(e) => patch(id, { thirdPersonName: e.target.value })}
            placeholder="Used if you enable Third Person in AID"
          />
        </div>
      </div>
    </div>
  );
}

function CharacterCreatorPanel({
  id,
  prompt,
  onPrompt,
  ctx,
  cards,
  onToggle,
}: {
  id: string;
  prompt: string;
  onPrompt: (v: string) => void;
  ctx: string;
  cards: StoryCard[];
  onToggle: (card: StoryCard, next: boolean) => void;
}) {
  const grouped = {
    class: cards.filter((c) => c.type === "class"),
    race: cards.filter((c) => c.type === "race"),
    location: cards.filter((c) => c.type === "location"),
    faction: cards.filter((c) => c.type === "faction"),
    other: cards.filter((c) => !["class", "race", "location", "faction"].includes(c.type)),
  };

  return (
    <div className="space-y-4 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
      <div>
        <h2 className="text-sm font-medium">Character creator opening</h2>
        <p className="mt-1 text-xs text-muted-foreground">
          The prompt is the scene before the player picks origin options. Flag class, race, location,
          and faction cards on their tabs — they appear here.
        </p>
      </div>
      <FieldBlock
        label="Scene before creation"
        hint="Do not pre-assign class or origin. End as they step into the choice."
        field="prompt"
        value={prompt}
        onChange={onPrompt}
        context={ctx}
        minH="min-h-32"
      />
      <div className="grid gap-3 sm:grid-cols-2">
        {(["class", "race", "location", "faction"] as const).map((type) => (
          <div key={type} className="rounded-lg bg-secondary p-3">
            <p className="text-[11px] font-medium tracking-wide text-muted-foreground uppercase">{type}</p>
            {grouped[type].length === 0 ? (
              <p className="mt-2 text-xs text-muted-foreground">None flagged yet.</p>
            ) : (
              <ul className="mt-2 space-y-1">
                {grouped[type].map((c) => (
                  <li key={c.id} className="flex items-center justify-between gap-2 text-sm">
                    <span>{c.title}</span>
                    <button
                      type="button"
                      className="text-[11px] text-muted-foreground hover:text-foreground"
                      onClick={() => onToggle(c, false)}
                    >
                      Remove
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </div>
      {grouped.other.length ? (
        <div className="flex flex-wrap gap-1.5">
          {grouped.other.map((c) => (
            <Badge key={c.id} variant="outline">
              {c.title}
            </Badge>
          ))}
        </div>
      ) : null}
      <p className="text-xs text-muted-foreground">
        Flag cards from{" "}
        <Link to="/project/$id/elements" params={{ id }} className="text-steel underline-offset-4 hover:underline">
          Other
        </Link>
        ,{" "}
        <Link to="/project/$id/locations" params={{ id }} className="text-steel underline-offset-4 hover:underline">
          Locations
        </Link>
        , or{" "}
        <Link to="/project/$id/factions" params={{ id }} className="text-steel underline-offset-4 hover:underline">
          Factions
        </Link>
        .
      </p>
    </div>
  );
}

function MultipleChoicePanel({
  id,
  preamble,
  onPreamble,
  choices,
  onChoices,
  ctx,
}: {
  id: string;
  preamble: string;
  onPreamble: (v: string) => void;
  choices: { id: string; label: string; prompt: string }[];
  onChoices: (c: { id: string; label: string; prompt: string }[]) => void;
  ctx: string;
}) {
  void id;
  return (
    <div className="space-y-4">
      <FieldBlock
        label="Shared preamble (optional)"
        hint="A sentence or two that sits before every choice. Leave empty if each opening is self-contained."
        field="prompt"
        value={preamble}
        onChange={onPreamble}
        context={ctx}
        minH="min-h-24"
      />
      <div className="flex items-center justify-between">
        <Label>Opening choices</Label>
        <Button
          variant="outline"
          size="sm"
          onClick={() =>
            onChoices([...choices, { id: newId(), label: `Opening ${choices.length + 1}`, prompt: "" }])
          }
        >
          <Plus />
          Add choice
        </Button>
      </div>
      {choices.length === 0 ? (
        <p className="rounded-lg bg-secondary px-4 py-3 text-sm text-muted-foreground">
          Add at least two openings, or press Fill empty fields and Grok will draft three.
        </p>
      ) : null}
      <ul className="space-y-3">
        {choices.map((c, i) => (
          <li key={c.id} className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
            <div className="mb-2 flex items-center justify-between gap-2">
              <Input
                value={c.label}
                onChange={(e) =>
                  onChoices(choices.map((x) => (x.id === c.id ? { ...x, label: e.target.value } : x)))
                }
              />
              <GrokFill
                field={`multiple-choice opening ${i + 1}`}
                value={c.prompt}
                onChange={(prompt) =>
                  onChoices(choices.map((x) => (x.id === c.id ? { ...x, prompt } : x)))
                }
                context={`${ctx}\nChoice label: ${c.label}\nPreamble: ${preamble}`}
                instruction="A complete second-person starting prompt for this opening. Distinct from the other choices."
              />
              <Button
                variant="ghost"
                size="icon-sm"
                aria-label="Remove choice"
                onClick={() => onChoices(choices.filter((x) => x.id !== c.id))}
              >
                <Trash2 />
              </Button>
            </div>
            <Textarea
              value={c.prompt}
              onChange={(e) =>
                onChoices(choices.map((x) => (x.id === c.id ? { ...x, prompt: e.target.value } : x)))
              }
              placeholder={`Opening ${i + 1}`}
              className="min-h-24"
            />
          </li>
        ))}
      </ul>
    </div>
  );
}
