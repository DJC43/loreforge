import { createFileRoute, Link } from "@tanstack/react-router";
import { Download, Loader2, Plus, Trash2 } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { GrokFill } from "@/components/grok-fill";
import { PortraitField } from "@/components/portrait-field";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { generateCover, generateNpc } from "@/lib/ai";
import { composeNpcEntry, downloadText, keysFromName, slugify } from "@/lib/aid";
import { NPC_FIELDS } from "@/lib/catalog";
import { toAidNpcCards, toNpcExport } from "@/lib/dungeon";
import { portraitPrompt } from "@/lib/portrait";
import { emptyNpc, type LibraryNpc, type NpcFields } from "@/lib/types";
import { useStudio } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/library")({ component: NpcLibraryPage });

function NpcLibraryPage() {
  const library = useStudio((s) => s.npcLibrary);
  const add = useStudio((s) => s.addNpcToLibrary);
  const update = useStudio((s) => s.updateLibraryNpc);
  const remove = useStudio((s) => s.removeLibraryNpc);
  const toggle = useStudio((s) => s.toggleLibrarySelected);
  const importNpcs = useStudio((s) => s.importLibraryNpcs);
  const fileRef = useRef<HTMLInputElement>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [brief, setBrief] = useState("");
  const [busy, setBusy] = useState<"npc" | "portrait" | null>(null);

  const selected = useMemo(
    () => library.find((n) => n.id === (selectedId ?? library[0]?.id)) ?? null,
    [library, selectedId],
  );
  const checked = library.filter((n) => n.selected);

  async function writeNpc() {
    if (!brief.trim()) {
      toast.error("Describe the NPC first.");
      return;
    }
    setBusy("npc");
    try {
      const res = await generateNpc({ data: { brief: brief.trim() } });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      const d = res.data;
      const entry = add({
        title: d.title,
        keys: d.keys || d.title,
        value: d.value,
        description: d.description || "",
        npc: { ...emptyNpc(), ...d.npc },
      });
      setSelectedId(entry.id);
      setBrief("");
      toast.success(`Added ${entry.title}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "NPC generation failed");
    } finally {
      setBusy(null);
    }
  }

  function exportSelected() {
    const list = checked.length ? checked : selected ? [selected] : [];
    if (!list.length) {
      toast.error("Select at least one NPC.");
      return;
    }
    downloadText(
      `loreforge-npcs.json`,
      JSON.stringify(toNpcExport(list), null, 2),
      "application/json",
    );
    toast.success(`Exported ${list.length} NPC${list.length === 1 ? "" : "s"}`);
  }

  function exportAid() {
    const list = checked.length ? checked : selected ? [selected] : [];
    if (!list.length) {
      toast.error("Select at least one NPC.");
      return;
    }
    downloadText(
      `aid-story-cards.json`,
      JSON.stringify(toAidNpcCards(list), null, 2),
      "application/json",
    );
    toast.success("AID story cards downloaded");
  }

  function onImport(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as { npcs?: unknown[] } | unknown[];
        const list = Array.isArray(parsed) ? parsed : parsed.npcs;
        if (!Array.isArray(list)) throw new Error("No NPCs in file");
        const n = importNpcs(list);
        toast.success(`Imported ${n} NPC${n === 1 ? "" : "s"}`);
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Import failed");
      }
    };
    reader.readAsText(file);
  }

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 md:py-12">
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-[11px] font-medium tracking-[0.16em] text-steel uppercase">Catalogue</p>
          <h1 className="font-display text-3xl font-medium tracking-tight md:text-4xl">NPC library</h1>
          <p className="mt-1 max-w-xl text-sm text-muted-foreground">
            Reusable people with story-card copy and portraits. Check any of them, then export a JSON
            file — or pull them into a scenario from the NPC tab.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => {
              const entry = add({
                title: "Untitled NPC",
                keys: "",
                value: "",
                description: "",
                npc: emptyNpc(),
              });
              setSelectedId(entry.id);
            }}
          >
            <Plus />
            Blank NPC
          </Button>
          <Button variant="outline" onClick={() => fileRef.current?.click()}>
            Import JSON
          </Button>
          <Button variant="outline" onClick={exportAid}>
            AID cards
          </Button>
          <Button onClick={exportSelected}>
            <Download />
            Export selected
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onImport(f);
              e.target.value = "";
            }}
          />
        </div>
      </div>

      <div className="mb-6 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
        <Label htmlFor="lib-brief">Write with Grok</Label>
        <Textarea
          id="lib-brief"
          value={brief}
          onChange={(e) => setBrief(e.target.value)}
          placeholder="A barge-captain who bribes clerks to keep drowned creditors out of the book…"
          className="mt-2 min-h-20"
        />
        <Button className="mt-3" onClick={() => void writeNpc()} disabled={busy !== null}>
          {busy === "npc" ? <Loader2 className="animate-spin" /> : null}
          Write NPC
        </Button>
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,280px)_minmax(0,1fr)]">
        <ul className="max-h-[70vh] space-y-1 overflow-auto rounded-xl bg-card p-2 shadow-[var(--shadow-border)]">
          {library.length === 0 ? (
            <li className="px-3 py-8 text-center text-sm text-muted-foreground">Library is empty.</li>
          ) : (
            library.map((n) => (
              <li key={n.id}>
                <div
                  className={cn(
                    "flex items-center gap-2 rounded-lg px-2 py-2",
                    selected?.id === n.id ? "bg-secondary" : "hover:bg-muted",
                  )}
                >
                  <input
                    type="checkbox"
                    checked={n.selected}
                    onChange={() => toggle(n.id)}
                    className="size-4 accent-steel"
                    aria-label={`Select ${n.title}`}
                  />
                  <button
                    type="button"
                    onClick={() => setSelectedId(n.id)}
                    className="flex min-w-0 flex-1 items-center gap-2 text-left"
                  >
                    <div className="size-16 shrink-0 overflow-hidden rounded-md bg-muted">
                      {n.portraitDataUrl ? (
                        <img src={n.portraitDataUrl} alt="" className="size-full object-cover" />
                      ) : null}
                    </div>
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-medium">{n.title}</span>
                      <span className="block truncate text-[11px] text-muted-foreground">
                        {n.description || n.npc.role || "No description"}
                      </span>
                    </span>
                  </button>
                </div>
              </li>
            ))
          )}
        </ul>
        {selected ? (
          <LibraryEditor
            npc={selected}
            busyPortrait={busy === "portrait"}
            onChange={(patch) => update(selected.id, patch)}
            onDelete={() => {
              remove(selected.id);
              setSelectedId(null);
            }}
            onPortrait={async () => {
              setBusy("portrait");
              try {
                const res = await generateCover({
                  data: {
                    prompt: portraitPrompt(selected.title, selected.npc.role, selected.npc.appearance),
                    aspect: "1:1",
                  },
                });
                if (!res.ok) {
                  toast.error(res.error);
                  return;
                }
                update(selected.id, { portraitDataUrl: res.dataUrl });
                toast.success("Portrait painted");
              } catch (err) {
                toast.error(err instanceof Error ? err.message : "Portrait failed");
              } finally {
                setBusy(null);
              }
            }}
          />
        ) : (
          <div className="rounded-xl bg-card p-8 text-sm text-muted-foreground shadow-[var(--shadow-border)]">
            Add an NPC to get started.{" "}
            <Link to="/" className="text-steel underline-offset-4 hover:underline">
              Back to ideas
            </Link>
          </div>
        )}
      </div>
    </main>
  );
}

function LibraryEditor({
  npc,
  onChange,
  onDelete,
  onPortrait,
  busyPortrait,
}: {
  npc: LibraryNpc;
  onChange: (patch: Partial<LibraryNpc>) => void;
  onDelete: () => void;
  onPortrait: () => void;
  busyPortrait: boolean;
}) {
  const fields = npc.npc;

  function setNpc(patch: Partial<NpcFields>) {
    const next = { ...fields, ...patch };
    onChange({
      npc: next,
      value: composeNpcEntry(npc.title, next),
      keys: npc.keys.trim() ? npc.keys : keysFromName(npc.title, next.aliases),
    });
  }

  return (
    <div className="space-y-4 rounded-xl bg-card p-4 shadow-[var(--shadow-border)] md:p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1 space-y-1.5">
          <div className="flex items-center justify-between">
            <Label htmlFor="lib-title">Name</Label>
            <GrokFill
              field="NPC name"
              value={npc.title}
              onChange={(title) => onChange({ title })}
            />
          </div>
          <Input
            id="lib-title"
            value={npc.title}
            onChange={(e) => {
              const title = e.target.value;
              onChange({
                title,
                value: composeNpcEntry(title, fields),
                keys: npc.keys.trim() ? npc.keys : keysFromName(title, fields.aliases),
              });
            }}
          />
        </div>
        <Button variant="ghost" size="icon-sm" aria-label="Delete NPC" onClick={onDelete}>
          <Trash2 />
        </Button>
      </div>
      <PortraitField
        src={npc.portraitDataUrl}
        name={npc.title}
        busy={busyPortrait}
        onGenerate={onPortrait}
        onChange={(portraitDataUrl) => onChange({ portraitDataUrl })}
      />
      <div className="space-y-1.5">
        <Label htmlFor="lib-keys">Triggers</Label>
        <Input
          id="lib-keys"
          value={npc.keys}
          onChange={(e) => onChange({ keys: e.target.value })}
        />
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        {NPC_FIELDS.map(([key, label]) => (
          <div key={key} className={cn("space-y-1.5", key === "appearance" && "sm:col-span-2")}>
            <div className="flex items-center justify-between">
              <Label htmlFor={`lib-${key}`}>{label}</Label>
              <GrokFill
                field={`NPC ${label.toLowerCase()}`}
                value={fields[key]}
                onChange={(v) => setNpc({ [key]: v })}
                context={`NPC: ${npc.title}`}
              />
            </div>
            <Textarea
              id={`lib-${key}`}
              value={fields[key]}
              onChange={(e) => setNpc({ [key]: e.target.value })}
              className="min-h-16"
            />
          </div>
        ))}
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="lib-value">Story card entry</Label>
        <Textarea
          id="lib-value"
          value={npc.value}
          onChange={(e) => onChange({ value: e.target.value })}
          className="min-h-32"
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="lib-desc">Description</Label>
        <Textarea
          id="lib-desc"
          value={npc.description}
          onChange={(e) => onChange({ description: e.target.value })}
          className="min-h-20"
        />
      </div>
      <Button
        variant="outline"
        size="sm"
        onClick={() => {
          downloadText(
            `${slugify(npc.title)}.npc.json`,
            JSON.stringify(toNpcExport([npc]), null, 2),
            "application/json",
          );
        }}
      >
        <Download />
        Download this NPC
      </Button>
    </div>
  );
}
