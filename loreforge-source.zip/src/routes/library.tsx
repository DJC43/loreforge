import { createFileRoute, Link } from "@tanstack/react-router";
import { Download, GitBranch, Loader2, Plus, Trash2 } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { GrokFill } from "@/components/grok-fill";
import { PortraitField } from "@/components/portrait-field";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { generateCover, generateNpc } from "@/lib/ai";
import { composeNpcEntry, downloadText, keysFromName, slugify } from "@/lib/aid";
import { NEST_ROLES, NPC_FIELDS, nestDraft, nestRoleLabel } from "@/lib/catalog";
import { toAidNpcCards, toNpcExport } from "@/lib/dungeon";
import { descendantIds, nestTreeRows } from "@/lib/nest";
import { portraitPrompt } from "@/lib/portrait";
import { emptyNpc, type LibraryNpc, type NpcFields } from "@/lib/types";
import { useStudio } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/library")({ component: NpcLibraryPage });

function NpcLibraryPage() {
  const library = useStudio((s) => s.npcLibrary);
  const add = useStudio((s) => s.addNpcToLibrary);
  const update = useStudio((s) => s.updateLibraryNpc);
  const remove = useStudio((s) => s.removeLibraryNpc);
  const toggle = useStudio((s) => s.toggleLibrarySelected);
  const importNpcs = useStudio((s) => s.importLibraryNpcs);
  const groupLibrary = useStudio((s) => s.groupLibraryNpcs);
  const fileRef = useRef<HTMLInputElement>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [brief, setBrief] = useState("");
  const [busy, setBusy] = useState<"npc" | "portrait" | null>(null);

  const selected = useMemo(
    () => library.find((n) => n.id === (selectedId ?? library[0]?.id)) ?? null,
    [library, selectedId],
  );
  const checked = library.filter((n) => n.selected);

  async function writeNpc() {
    if (!brief.trim()) {
      toast.error("Describe the NPC first.");
      return;
    }
    setBusy("npc");
    try {
      const res = await generateNpc({ data: { brief: brief.trim() } });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      const d = res.data;
      const entry = add({
        title: d.title,
        keys: d.keys || d.title,
        value: d.value,
        description: d.description || "",
        npc: { ...emptyNpc(), ...d.npc },
      });
      setSelectedId(entry.id);
      setBrief("");
      toast.success(`Added ${entry.title}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "NPC generation failed");
    } finally {
      setBusy(null);
    }
  }

  function exportSelected() {
    const list = checked.length ? checked : selected ? [selected] : [];
    if (!list.length) {
      toast.error("Select at least one NPC.");
      return;
    }
    downloadText(
      `loreforge-npcs.json`,
      JSON.stringify(toNpcExport(list), null, 2),
      "application/json",
    );
    toast.success(`Exported ${list.length} NPC${list.length === 1 ? "" : "s"}`);
  }

  function exportAid() {
    const list = checked.length ? checked : selected ? [selected] : [];
    if (!list.length) {
      toast.error("Select at least one NPC.");
      return;
    }
    downloadText(
      `aid-story-cards.json`,
      JSON.stringify(toAidNpcCards(list), null, 2),
      "application/json",
    );
    toast.success("AID story cards downloaded");
  }

  function onImport(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as { npcs?: unknown[] } | unknown[];
        const list = Array.isArray(parsed) ? parsed : parsed.npcs;
        if (!Array.isArray(list)) throw new Error("No NPCs in file");
        const n = importNpcs(list);
        toast.success(`Imported ${n} NPC${n === 1 ? "" : "s"}`);
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Import failed");
      }
    };
    reader.readAsText(file);
  }

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 md:py-12">
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-[11px] font-medium tracking-[0.16em] text-steel uppercase">Catalogue</p>
          <h1 className="font-display text-3xl font-medium tracking-tight md:text-4xl">NPC library</h1>
          <p className="mt-1 max-w-xl text-sm text-muted-foreground">
            Reusable people with portraits. Backstory, desires, and other suffix cards nest under
            the primary — check the person, and the group travels together.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => {
              const entry = add({
                title: "Untitled NPC",
                keys: "",
                value: "",
                description: "",
                npc: emptyNpc(),
              });
              setSelectedId(entry.id);
            }}
          >
            <Plus />
            Blank NPC
          </Button>
          <Button variant="outline" onClick={() => fileRef.current?.click()}>
            Import JSON
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              groupLibrary();
              toast.success("Grouped suffix cards under matching names");
            }}
          >
            Group by name
          </Button>
          <Button variant="outline" onClick={exportAid}>
            AID cards
          </Button>
          <Button onClick={exportSelected}>
            <Download />
            Export selected
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onImport(f);
              e.target.value = "";
            }}
          />
        </div>
      </div>

      <div className="mb-6 rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
        <Label htmlFor="lib-brief">Write with Grok</Label>
        <Textarea
          id="lib-brief"
          value={brief}
          onChange={(e) => setBrief(e.target.value)}
          placeholder="A barge-captain who bribes clerks to keep drowned creditors out of the book…"
          className="mt-2 min-h-20"
        />
        <Button className="mt-3" onClick={() => void writeNpc()} disabled={busy !== null}>
          {busy === "npc" ? <Loader2 className="animate-spin" /> : null}
          Write NPC
        </Button>
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,280px)_minmax(0,1fr)]">
        <ul className="max-h-[70vh] space-y-0.5 overflow-auto rounded-xl bg-card p-2 shadow-[var(--shadow-border)]">
          {library.length === 0 ? (
            <li className="px-3 py-8 text-center text-sm text-muted-foreground">Library is empty.</li>
          ) : (
            nestTreeRows(library).map((row) => {
              const n = row.item;
              return (
                <li
                  key={n.id}
                  className={cn(row.depth > 0 && "border-l border-border")}
                  style={{ marginLeft: row.depth * 16, paddingLeft: row.depth ? 10 : 0 }}
                >
                  <div
                    className={cn(
                      "flex items-center gap-2 rounded-lg px-2 py-2",
                      selected?.id === n.id ? "bg-secondary" : "hover:bg-muted",
                    )}
                  >
                    <input
                      type="checkbox"
                      checked={n.selected}
                      onChange={() => toggle(n.id)}
                      className="size-4 accent-steel"
                      aria-label={`Select ${n.title}`}
                    />
                    <button
                      type="button"
                      onClick={() => setSelectedId(n.id)}
                      className="flex min-w-0 flex-1 items-center gap-2 text-left"
                    >
                      {row.depth > 0 ? (
                        <GitBranch className="size-4 shrink-0 text-steel" />
                      ) : (
                        <div className="aspect-[9/16] w-16 shrink-0 overflow-hidden rounded-md bg-muted">
                          {n.portraitDataUrl ? (
                            <img
                              src={n.portraitDataUrl}
                              alt=""
                              className="size-full object-cover object-top"
                            />
                          ) : null}
                        </div>
                      )}
                      <span className="min-w-0">
                        <span className="block truncate text-sm font-medium">{n.title}</span>
                        <span className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
                          {row.depth > 0 ? (
                            <Badge variant="steel">{nestRoleLabel(n.nestRole)}</Badge>
                          ) : row.childCount ? (
                            <span>{row.childCount} nested</span>
                          ) : null}
                          <span className="truncate">
                            {n.description || n.npc.role || "No description"}
                          </span>
                        </span>
                      </span>
                    </button>
                  </div>
                </li>
              );
            })
          )}
        </ul>
        {selected ? (
          <LibraryEditor
            npc={selected}
            all={library}
            busyPortrait={busy === "portrait"}
            onChange={(patch) => update(selected.id, patch)}
            onOpen={(id) => setSelectedId(id)}
            onAddNested={(role) => {
              const draft = nestDraft(selected.title, role);
              const entry = add({
                title: draft.title,
                keys: draft.keys,
                value: "",
                description: draft.description,
                npc: emptyNpc(),
                parentId: selected.id,
                nestRole: role,
              });
              setSelectedId(entry.id);
              toast.success(`Nested ${nestRoleLabel(role).toLowerCase()} under ${selected.title}`);
            }}
            onDelete={() => {
              remove(selected.id);
              setSelectedId(null);
            }}
            onPortrait={async () => {
              setBusy("portrait");
              try {
                const res = await generateCover({
                  data: {
                    prompt: portraitPrompt(selected.title, selected.npc.role, selected.npc.appearance),
                    aspect: "9:16",
                  },
                });
                if (!res.ok) {
                  toast.error(res.error);
                  return;
                }
                update(selected.id, { portraitDataUrl: res.dataUrl });
                toast.success("Portrait painted");
              } catch (err) {
                toast.error(err instanceof Error ? err.message : "Portrait failed");
              } finally {
                setBusy(null);
              }
            }}
          />
        ) : (
          <div className="rounded-xl bg-card p-8 text-sm text-muted-foreground shadow-[var(--shadow-border)]">
            Add an NPC to get started.{" "}
            <Link to="/" className="text-steel underline-offset-4 hover:underline">
              Back to ideas
            </Link>
          </div>
        )}
      </div>
    </main>
  );
}

function LibraryEditor({
  npc,
  all,
  onChange,
  onDelete,
  onPortrait,
  onAddNested,
  onOpen,
  busyPortrait,
}: {
  npc: LibraryNpc;
  all: LibraryNpc[];
  onChange: (patch: Partial<LibraryNpc>) => void;
  onDelete: () => void;
  onPortrait: () => void;
  onAddNested: (role: string) => void;
  onOpen: (id: string) => void;
  busyPortrait: boolean;
}) {
  const fields = npc.npc;
  const blocked = descendantIds(all, npc.id);
  const parentOptions = all.filter((n) => !blocked.has(n.id));
  const parent = all.find((n) => n.id === npc.parentId);
  const children = all.filter((n) => n.parentId === npc.id);

  function setNpc(patch: Partial<NpcFields>) {
    const next = { ...fields, ...patch };
    onChange({
      npc: next,
      value: composeNpcEntry(npc.title, next),
      keys: npc.keys.trim() ? npc.keys : keysFromName(npc.title, next.aliases),
    });
  }

  return (
    <div className="space-y-4 rounded-xl bg-card p-4 shadow-[var(--shadow-border)] md:p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1 space-y-1.5">
          <div className="flex items-center justify-between">
            <Label htmlFor="lib-title">Name</Label>
            <GrokFill
              field="NPC name"
              value={npc.title}
              onChange={(title) => onChange({ title })}
            />
          </div>
          <Input
            id="lib-title"
            value={npc.title}
            onChange={(e) => {
              const title = e.target.value;
              onChange({
                title,
                value: composeNpcEntry(title, fields),
                keys: npc.keys.trim() ? npc.keys : keysFromName(title, fields.aliases),
              });
            }}
          />
        </div>
        <Button variant="ghost" size="icon-sm" aria-label="Delete NPC" onClick={onDelete}>
          <Trash2 />
        </Button>
      </div>
      <PortraitField
        src={npc.portraitDataUrl}
        name={npc.title}
        busy={busyPortrait}
        onGenerate={onPortrait}
        onChange={(portraitDataUrl) => onChange({ portraitDataUrl })}
      />
      <div className="space-y-3 rounded-lg bg-secondary p-3">
        <div>
          <p className="text-sm font-medium">Nested cards</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Backstory, desires, secrets live under this person. Export stays a flat list of distinct
            cards.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {NEST_ROLES.map((r) => (
            <Button key={r.id} type="button" variant="outline" size="sm" onClick={() => onAddNested(r.id)}>
              <Plus />
              {r.label}
            </Button>
          ))}
        </div>
        {children.length ? (
          <ul className="space-y-1">
            {children.map((child) => (
              <li key={child.id}>
                <button
                  type="button"
                  onClick={() => onOpen(child.id)}
                  className="flex w-full items-center gap-2 rounded-md bg-card px-3 py-2 text-left text-sm hover:bg-muted"
                >
                  <GitBranch className="size-3.5 shrink-0 text-steel" />
                  <span className="min-w-0 flex-1 truncate">{child.title}</span>
                  <Badge variant="steel">{nestRoleLabel(child.nestRole)}</Badge>
                </button>
              </li>
            ))}
          </ul>
        ) : null}
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label htmlFor="lib-parent">Nest under</Label>
            <select
              id="lib-parent"
              value={npc.parentId ?? ""}
              onChange={(e) =>
                onChange({
                  parentId: e.target.value || undefined,
                  nestRole: e.target.value ? npc.nestRole || "backstory" : undefined,
                })
              }
              className="flex h-11 w-full rounded-md border border-input bg-card px-3 text-sm"
            >
              <option value="">Top level (primary)</option>
              {parentOptions.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="lib-nest-role">Nested as</Label>
            <select
              id="lib-nest-role"
              value={npc.nestRole || "backstory"}
              disabled={!npc.parentId}
              onChange={(e) => onChange({ nestRole: e.target.value })}
              className="flex h-11 w-full rounded-md border border-input bg-card px-3 text-sm"
            >
              {NEST_ROLES.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.label}
                </option>
              ))}
            </select>
          </div>
        </div>
        {parent ? (
          <p className="text-xs text-muted-foreground">
            Nested under{" "}
            <button
              type="button"
              className="text-steel underline-offset-4 hover:underline"
              onClick={() => onOpen(parent.id)}
            >
              {parent.title}
            </button>{" "}
            as {nestRoleLabel(npc.nestRole).toLowerCase()}.
          </p>
        ) : null}
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="lib-keys">Triggers</Label>
        <Input
          id="lib-keys"
          value={npc.keys}
          onChange={(e) => onChange({ keys: e.target.value })}
        />
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        {NPC_FIELDS.map(([key, label]) => (
          <div key={key} className={cn("space-y-1.5", key === "appearance" && "sm:col-span-2")}>
            <div className="flex items-center justify-between">
              <Label htmlFor={`lib-${key}`}>{label}</Label>
              <GrokFill
                field={`NPC ${label.toLowerCase()}`}
                value={fields[key]}
                onChange={(v) => setNpc({ [key]: v })}
                context={`NPC: ${npc.title}`}
              />
            </div>
            <Textarea
              id={`lib-${key}`}
              value={fields[key]}
              onChange={(e) => setNpc({ [key]: e.target.value })}
              className="min-h-16"
            />
          </div>
        ))}
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="lib-value">Story card entry</Label>
        <Textarea
          id="lib-value"
          value={npc.value}
          onChange={(e) => onChange({ value: e.target.value })}
          className="min-h-32"
        />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="lib-desc">Description</Label>
        <Textarea
          id="lib-desc"
          value={npc.description}
          onChange={(e) => onChange({ description: e.target.value })}
          className="min-h-20"
        />
      </div>
      <Button
        variant="outline"
        size="sm"
        onClick={() => {
          downloadText(
            `${slugify(npc.title)}.npc.json`,
            JSON.stringify(toNpcExport([npc]), null, 2),
            "application/json",
          );
        }}
      >
        <Download />
        Download this NPC
      </Button>
    </div>
  );
}
