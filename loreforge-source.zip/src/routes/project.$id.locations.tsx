import { createFileRoute } from "@tanstack/react-router";
import { ElementStudio } from "@/components/element-studio";

export const Route = createFileRoute("/project/$id/locations")({ component: LocationsPage });

function LocationsPage() {
  const { id } = Route.useParams();
  return (
    <ElementStudio
      projectId={id}
      types={["location"]}
      kicker="Place"
      title="Locations"
      lede="Rooms, towns, ships, planes. Nest history under a place. Check Include in export to send a nested card as its own story card — nesting never appears in the JSON."
      allowLibrary
    />
  );
}
