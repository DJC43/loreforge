import { createFileRoute } from "@tanstack/react-router";
import { Download, Loader2, Lock, LockOpen, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { GrokFill } from "@/components/grok-fill";
import { SectionIntro } from "@/components/project-frame";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { fillCoverFields, generateCover } from "@/lib/ai";
import { composeCoverPrompt, downloadDataUrl, mediumBlend, slugify } from "@/lib/aid";
import { COVER_MEDIUMS } from "@/lib/catalog";
import { projectContext } from "@/lib/context";
import { useStudio } from "@/lib/store";
import { cn, newId } from "@/lib/utils";
import type { CoverArt, CoverFieldKey } from "@/lib/types";

export const Route = createFileRoute("/project/$id/covers")({ component: CoversPage });

const ASPECTS: CoverArt["aspect"][] = ["16:9", "1:1", "4:3"];

const FIELDS: { key: CoverFieldKey; label: string; hint: string }[] = [
  { key: "subject", label: "Subject", hint: "Who or what occupies the frame." },
  { key: "composition", label: "Composition", hint: "Camera, crop, staging." },
  { key: "lighting", label: "Lighting", hint: "Time of day, source, temperature." },
  { key: "mood", label: "Mood", hint: "Emotional weather." },
  { key: "extra", label: "Notes", hint: "Anything else the image must include — or refuse." },
];

function CoversPage() {
  const { id } = Route.useParams();
  const project = useStudio((s) => s.projects.find((p) => p.id === id));
  const addCover = useStudio((s) => s.addCover);
  const removeCover = useStudio((s) => s.removeCover);
  const setCover = useStudio((s) => s.setCover);
  const lockCover = useStudio((s) => s.lockCover);
  const patchDraft = useStudio((s) => s.patchCoverDraft);
  const [aspect, setAspect] = useState<CoverArt["aspect"]>("16:9");
  const [busy, setBusy] = useState<"fields" | "image" | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [moreMediums, setMoreMediums] = useState(false);

  const selected = useMemo(() => {
    if (!project) return null;
    return (
      project.covers.find((c) => c.id === (selectedId ?? project.coverId ?? project.covers[0]?.id)) ??
      null
    );
  }, [project, selectedId]);

  if (!project) return null;
  const current = project;
  const draft = current.coverDraft;
  const ctx = projectContext(current);
  const blend = mediumBlend(draft);
  const featured = COVER_MEDIUMS.filter((m) => m.featured);
  const extra = COVER_MEDIUMS.filter((m) => !m.featured);

  async function fillUnlocked() {
    const fields = FIELDS.map((f) => f.key).filter((k) => !draft.locked[k] && !draft[k].trim());
    const targets = fields.length ? fields : FIELDS.map((f) => f.key).filter((k) => !draft.locked[k]);
    if (!targets.length) {
      toast.error("Unlock a field first.");
      return;
    }
    setBusy("fields");
    try {
      const res = await fillCoverFields({
        data: {
          context: ctx,
          fields: targets,
          current: {
            subject: draft.subject,
            lighting: draft.lighting,
            composition: draft.composition,
            mood: draft.mood,
            extra: draft.extra,
          },
          mediums: blend.summary,
        },
      });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      const next: Partial<typeof draft> = {};
      for (const k of targets) {
        const v = res.data[k];
        if (v) (next as Record<string, string>)[k] = v;
      }
      patchDraft(id, next);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Fill failed");
    } finally {
      setBusy(null);
    }
  }

  async function paint() {
    const prompt = composeCoverPrompt(current);
    setBusy("image");
    try {
      const res = await generateCover({ data: { prompt, aspect } });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      const cover: CoverArt = {
        id: newId(),
        prompt,
        styleId: blend.parts.map((p) => p.id).join("+") || "mix",
        aspect,
        imageDataUrl: res.dataUrl,
        locked: false,
        createdAt: Date.now(),
      };
      addCover(id, cover);
      setSelectedId(cover.id);
      toast.success("Cover painted");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Image generation failed");
    } finally {
      setBusy(null);
    }
  }

  function mediumRow(m: (typeof COVER_MEDIUMS)[number]) {
    const weight = draft.mediums[m.id] ?? 0;
    return (
      <li key={m.id} className="grid grid-cols-[7.5rem_minmax(0,1fr)_2.5rem] items-center gap-2">
        <span className="truncate text-xs">{m.label}</span>
        <Slider
          value={weight}
          aria-label={m.label}
          onValueChange={(n) => patchDraft(id, { mediums: { ...draft.mediums, [m.id]: n } })}
        />
        <span className="font-mono text-[11px] tabular-nums text-muted-foreground">{weight}</span>
      </li>
    );
  }

  return (
    <div>
      <SectionIntro
        kicker="Covers"
        title="Paint the listing"
        lede="Blend mediums with sliders — anime, comic, glamour mag, realistic, and more. Lock any field. Generate, lock the keeper, or change it."
        actions={
          <Button variant="outline" onClick={() => void fillUnlocked()} disabled={busy !== null}>
            {busy === "fields" ? <Loader2 className="animate-spin" /> : null}
            Fill unlocked fields
          </Button>
        }
      />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <div className="space-y-5">
          <div className="space-y-2">
            <Label>Medium blend</Label>
            <p className="text-xs text-muted-foreground">
              Raise more than one. Zero weight drops a medium out of the mix.
            </p>
            <ul className="space-y-2">{featured.map(mediumRow)}</ul>
            <button
              type="button"
              className="text-xs text-steel underline-offset-4 hover:underline"
              onClick={() => setMoreMediums((v) => !v)}
            >
              {moreMediums ? "Hide more mediums" : "More mediums"}
            </button>
            {moreMediums ? <ul className="space-y-2">{extra.map(mediumRow)}</ul> : null}
          </div>

          <div className="space-y-2">
            <Label>Frame</Label>
            <div className="flex gap-2">
              {ASPECTS.map((a) => (
                <button
                  key={a}
                  type="button"
                  onClick={() => setAspect(a)}
                  className={cn(
                    "h-11 rounded-md px-4 text-sm",
                    aspect === a ? "bg-primary text-primary-foreground" : "bg-secondary",
                  )}
                >
                  {a}
                </button>
              ))}
            </div>
          </div>

          {FIELDS.map((f) => {
            const locked = Boolean(draft.locked[f.key]);
            return (
              <div key={f.key} className="space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <Label htmlFor={f.key}>{f.label}</Label>
                  <div className="flex items-center gap-1">
                    <GrokFill
                      field={`cover ${f.label.toLowerCase()}`}
                      value={draft[f.key]}
                      onChange={(v) => patchDraft(id, { [f.key]: v })}
                      context={`${ctx}\nMedium: ${blend.summary}`}
                      instruction={f.hint}
                    />
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      aria-label={locked ? "Unlock field" : "Lock field"}
                      onClick={() =>
                        patchDraft(id, { locked: { ...draft.locked, [f.key]: !locked } })
                      }
                    >
                      {locked ? <Lock /> : <LockOpen />}
                    </Button>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">{f.hint}</p>
                <Textarea
                  id={f.key}
                  value={draft[f.key]}
                  disabled={locked}
                  onChange={(e) => patchDraft(id, { [f.key]: e.target.value })}
                  className="min-h-20"
                />
              </div>
            );
          })}

          <Button onClick={() => void paint()} disabled={busy !== null} className="w-full sm:w-auto">
            {busy === "image" ? <Loader2 className="animate-spin" /> : null}
            {selected ? "Change — generate another" : "Generate cover"}
          </Button>
        </div>

        <div className="space-y-3">
          <div className="relative overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]">
            {selected ? (
              <>
                <img
                  src={selected.imageDataUrl}
                  alt=""
                  className="w-full outline outline-1 -outline-offset-1 outline-white/10"
                />
                {selected.aspect === "16:9" ? (
                  <div
                    aria-hidden
                    className="pointer-events-none absolute inset-y-0 left-1/2 w-[56.25%] -translate-x-1/2 border border-steel/40"
                    title="Center-safe square"
                  />
                ) : null}
                {selected.locked ? (
                  <span className="absolute top-3 left-3 inline-flex items-center gap-1 rounded-full bg-ink/70 px-2 py-1 text-[11px] text-foreground">
                    <Lock className="size-3" />
                    Locked
                  </span>
                ) : null}
              </>
            ) : (
              <div className="flex aspect-video items-center justify-center px-6 text-center text-sm text-muted-foreground">
                Generated covers land here. Lock the one that holds. Change generates a new take.
              </div>
            )}
          </div>
          {selected ? (
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selected.locked ? "secondary" : "outline"}
                size="sm"
                onClick={() => {
                  const next = !selected.locked;
                  lockCover(id, selected.id, next);
                  if (next) setCover(id, selected.id);
                }}
              >
                {selected.locked ? <Lock /> : <LockOpen />}
                {selected.locked ? "Locked as cover" : "Lock this cover"}
              </Button>
              <Button
                variant={current.coverId === selected.id ? "secondary" : "outline"}
                size="sm"
                onClick={() => setCover(id, selected.id)}
              >
                {current.coverId === selected.id ? "Project cover" : "Set as project cover"}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  downloadDataUrl(`${slugify(current.title)}-cover.jpg`, selected.imageDataUrl)
                }
              >
                <Download />
                Download
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  removeCover(id, selected.id);
                  setSelectedId(null);
                }}
              >
                <Trash2 />
                Remove
              </Button>
            </div>
          ) : null}
        </div>
      </div>

      {current.covers.length > 0 ? (
        <ul className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
          {current.covers.map((c) => (
            <li key={c.id}>
              <button
                type="button"
                onClick={() => setSelectedId(c.id)}
                className={cn(
                  "relative overflow-hidden rounded-lg",
                  selected?.id === c.id ? "ring-2 ring-ring" : "shadow-[var(--shadow-border)]",
                )}
              >
                <img
                  src={c.imageDataUrl}
                  alt=""
                  className="aspect-video w-full object-cover outline outline-1 -outline-offset-1 outline-white/10"
                />
                {c.locked ? (
                  <Lock className="absolute top-2 right-2 size-3.5 text-primary" />
                ) : null}
              </button>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}
