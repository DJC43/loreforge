# Loreforge

Worldbuilding studio for [AI Dungeon](https://aidungeon.com) and Dungeon Extension v2.

Start from an idea, lock it, then forge NPCs (with portraits), factions, locations, nested cards, plot, and covers. Export AID story cards and Dungeon Extension v2 adventure JSON. Worlds stay in the browser — they are not in this repo.

## Rebuild under your own Grok

This is a Grok Build app. AI features (Grok fill, generated portraits, covers) use **the key of whoever is running it**.

### Option A — Grok Build (uses your Grok subscription)

1. Clone this repo, or download the ZIP.
2. Open a new Grok chat with **Build**.
3. Ask it to rebuild Loreforge from this project (paste the repo URL, or drop the folder in).
4. Publish to **your** `*.grok.me` address. Grok fill / portraits / covers then spend **your** quota.

### Option B — run it yourself (uses your xAI API key)

Needs **Node 22+** and an API key from [console.x.ai](https://console.x.ai). SuperGrok chat access is not the same thing as this key.

```bash
npm install
export XAI_API_KEY=your_key
npm run dev
```

Open the local URL Vite prints (port **8080**). Without `XAI_API_KEY`, writing and JSON export still work; Grok fill, portrait generation, and covers stay unavailable.

```bash
npm run build
```

Auth is off. No database. No accounts.

## What to share with players

Send the **exported JSON / paste pack**, not this repo. This repo is the studio. A world’s story cards live in that person’s browser until they export.
