import { writeFileSync } from "node:fs";
import { chromium } from "playwright";

const SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <rect width="100" height="100" fill="#0c0b0a"/>
  <g transform="translate(18 16) scale(2)">
    <path fill="#efece6" d="M16 3c2.2 2.8 1.7 5 0 7.2C13.8 8 13.3 5.8 16 3z"/>
    <path fill="#b8c4ce" d="M4 13.2h18.2c1.6 0 4.2.6 6.3 2.1H5.8C4.9 14.4 4.4 13.8 4 13.2z"/>
    <rect x="13" y="15.2" width="6.2" height="7.2" fill="#b8c4ce"/>
    <path fill="#b8c4ce" d="M8.2 22.2h15.6l2.1 5.6H6.1z"/>
  </g>
</svg>`;

async function raster(browser, size, dest) {
  const page = await browser.newPage({
    viewport: { width: size, height: size },
    deviceScaleFactor: 1,
  });
  await page.setContent(
    `<!doctype html><html><head><style>
      html,body{margin:0;padding:0;width:${size}px;height:${size}px;background:#0c0b0a;overflow:hidden}
      svg{display:block;width:${size}px;height:${size}px}
    </style></head><body>${SVG}</body></html>`,
    { waitUntil: "load" },
  );
  const buf = await page.screenshot({
    type: "png",
    omitBackground: false,
    clip: { x: 0, y: 0, width: size, height: size },
  });
  writeFileSync(dest, buf);
  await page.close();
}

const browser = await chromium.launch({ args: ["--no-sandbox"] });
await raster(browser, 192, "public/icon-192.png");
await raster(browser, 512, "public/icon-512.png");
await raster(browser, 180, "public/apple-touch-icon.png");
await browser.close();
console.log("wrote public/icon-192.png public/icon-512.png public/apple-touch-icon.png");
